# BUGFIX REPORT — Stockfish 19-Pro Ultimate V3

Báo cáo này trình bày chi tiết nguyên nhân gốc rễ, vị trí mã nguồn sửa đổi và bằng chứng kiểm nghiệm thực tế cho toàn bộ 4 phát hiện kiểm toán từ V2 (`FINDING-01` đến `FINDING-04`) cùng các tinh chỉnh bảo toàn sức cờ trong `src/search.cpp`.

## 1. FINDING-01 — Binary Android Trong V2 Là Binary Stockfish 19 Gốc

### 1.1 Xác Minh Độc Lập
- Trong gói `Stockfish-19-Pro-Ultimate-V2.tar.gz`, file `stockfish-19-pro-ultimate-v2-arm64` có dung lượng `100,695,968` bytes và mã băm SHA-256:
  `ffd8fc2004d3d19f9fdab95d84c92709aea92e8d3af405eda0b281b23cf1daf8`
- Đối chiếu nhị phân (`cmp -l` và `sha256sum`) với binary gốc trong `stockfish-android-arm64-universal.tar.gz` cho thấy hai file **giống hệt nhau từng byte (0 byte khác biệt)**.
- Quét bảng chuỗi (`strings`) trên `stockfish-19-pro-ultimate-v2-arm64` xác nhận **không tồn tại** bất kỳ tùy chọn UCI Pro nào (`Fortress Detection`, `Deep Scaler Mode`, `Experience Enabled`, `Experience File`, `Experience Book`, `Experience Learning Rate`, `Adaptive Opponent Mode`).

### 1.2 Sửa Chữa Trong V3
1. **Xóa bỏ hoàn toàn binary Android giả mạo** khỏi cây thư mục dự án V3.
2. **Xây dựng pipeline biên dịch và kiểm định Fail-Closed cho Android ARM64**:
   - `android/build_android_v3.sh`: Biên dịch trực tiếp từ `src/` cho hai đích `stockfish-19-pro-ultimate-v3-arm64` (`ARCH=armv8`) và `stockfish-19-pro-ultimate-v3-arm64-dotprod` (`ARCH=armv8-dotprod`) bằng `aarch64-linux-android29-clang++`, kèm cờ `-fPIE -pie -static-libstdc++ -Wl,-z,max-page-size=16384`.
   - `android/verify_android_v3.py`: Kiểm tra cấu trúc header ELF64 AArch64 (`e_machine == 0xB7`), chặn cứng mã băm SHA-256 của binary gốc (`ffd8fc20...`), và yêu cầu có mặt đầy đủ toàn bộ chuỗi UCI Pro trong `.rodata`.
3. **Bằng chứng kiểm thử chống giả mạo**:
   - Chạy `python3 android/verify_android_v3.py` trên binary gốc `ffd8fc20...` trả về **`FAIL (exit code 1)`** với thông báo:
     `SPOOF DETECTED: Binary SHA-256 matches vanilla Stockfish 19 Android baseline`.

## 2. FINDING-02 — Benchmark Sử Dụng Sai Đối Thủ (`base_bin = pro_bin`)

### 2.1 Xác Minh Độc Lập
- Trong V2, `benchmark/run_benchmark.py` cho phép `base_bin` mặc định trỏ về chính `pro_bin` khi không truyền `--baseline-bin`, dẫn đến việc cả hai phía trong trận đấu dùng chung một file thực thi (`SHA-256: 3a6f835551cf...77df9`).

### 2.2 Sửa Chữa Trong V3
1. **Tách biệt mã nguồn và binary đối thủ chuẩn (`baseline_src/`)**:
   - Đóng gói mã nguồn Stockfish 19 gốc (không có bất kỳ bản vá Pro nào) trong thư mục `baseline_src/`.
   - `build.sh` tự động biên dịch `baseline_src/` thành `benchmark/stockfish_19_baseline_x86` (`790,744` bytes, SHA-256 `e8b3e5d6a5f6c340b5ea2026abaf383d1f2883eba8b271312b4a0ff4b0de6b0e`), hoàn toàn độc lập với `src/stockfish` (`841,912` bytes, SHA-256 `c24cb011b2884abaaff6a4f1b1380c43b54a2ea2bc9cc7fb80961f261390efdb`).
2. **Thiết lập chốt chặn Fail-Closed (`verify_opponent_separation`) trong `benchmark/run_benchmark.py`**:
   - Tuyệt đối không có fallback `base_bin = pro_bin`.
   - Kiểm tra trước trận đấu: nếu `pro_bin` và `baseline_bin` trùng đường dẫn, hoặc trùng mã băm SHA-256 (`candidate_sha256 == baseline_sha256`), hoặc `baseline_bin` chứa bất kỳ tùy chọn UCI Pro nào, chương trình dừng ngay lập tức với **exit code `2`**.
3. **Bằng chứng kiểm thử**:
   - Truyền cùng đường dẫn `--pro-bin src/stockfish --baseline-bin src/stockfish` -> dừng ngay với `exit code 2` (`FINDING-02 FAIL-CLOSED ABORT: Candidate and Baseline paths are identical`).
   - Truyền file copy ở đường dẫn khác nhưng có cùng SHA-256 -> dừng ngay với `exit code 2` (`FINDING-02 FAIL-CLOSED ABORT: Candidate and Baseline have identical SHA-256`).

## 3. FINDING-03 — `Dynamic Aggression` Bị Áp Dụng Hai Lần (Double-Scaling)

### 3.1 Xác Minh Độc Lập
- Trong V2, `Dynamic Aggression` bị nhân hai lần liên tiếp:
  1. Lần 1 tại `src/search.cpp:441`: `optimism[us] = (baseOpt + optimismBias + adaptOpt) * dynamicAggression / 100;`
  2. Lần 2 tại `src/evaluate.cpp:81`: `optimism = int(i64(optimism) * std::clamp(aggressionPct, 50, 150) / 100);`
- Hệ quả: Ở mức `50%`, optimism thực tế bị giảm còn `25%` (`0.5 * 0.5`); ở mức `150%`, optimism bị phóng đại lên `225%` (`1.5 * 1.5`).

### 3.2 Sửa Chữa Trong V3
1. **Tại `src/search.cpp:441-443`**: Bỏ phép nhân `dynamicAggression / 100`, chỉ tính giá trị optimism gốc chưa nhân:
   ```cpp
   int baseOpt   = 114 * avg / (std::abs(avg) + 85);
   optimism[us]  = baseOpt + optimismBias + adaptOpt;
   optimism[~us] = -(baseOpt - optimismBias - adaptOpt);
   ```
2. **Tại `src/evaluate.cpp:57-63` & `99-100`**: Thực hiện nhân **một lần duy nhất** bằng hàm `Eval::scale_optimism_by_aggression(int optimism, int aggressionPct)` với phép kẹp biên 64-bit `std::clamp<i64>(aggressionPct, 50, 150)`:
   ```cpp
   int Eval::scale_optimism_by_aggression(int optimism, int aggressionPct) noexcept {
       const i64 clampedAgg = std::clamp<i64>(aggressionPct, 50, 150);
       if (clampedAgg == 100)
           return optimism;
       const i64 scaled = (i64(optimism) * clampedAgg) / 100;
       return static_cast<int>(std::clamp<i64>(scaled, -30000, 30000));
   }
   ```
3. **Tại `src/evaluate.cpp:143-147` và `src/engine.cpp:193-198`**: Tích hợp `Dynamic Aggression` và `Optimism Bias` vào lệnh UCI `eval` (`Eval::trace()`) để có thể kiểm tra trực tiếp từ giao diện dòng lệnh.

### 3.3 Bảng Kết Quả Kiểm Nghiệm Thực Tế (`Dynamic Aggression` = 50, 75, 100, 125, 150 & Biên Ngoài 25, 49, 151, 200)

Thử nghiệm trực tiếp trên vị trí chiến thuật Kiwipete (`r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1`) với `Optimism Bias = 40` (base optimism = `+40`) và tìm kiếm ở `Depth 10`:

| Cấu Hình `Dynamic Aggression` | Hệ Số Hiệu Lực Sau Kẹp Biên `[50, 150]` | Tác Động Trong V2 Cũ (Lỗi Nhân Đôi) | Tác Động Trong V3 (Nhân 1 Lần Duy Nhất) | Base Evaluation (Internal Units) | Base Optimism | Adjusted Optimism (`Eval::trace`) | Final Static Evaluation (cp) | Nước Đi Được Chọn (`Depth 10`) | Điểm Số Tìm Kiếm (`Depth 10` cp) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- | ---: |
| **25% (Ngoài biên dưới)** | **50%** | 12.5% | **50.0%** | `-560` | `+40` | **`+20`** | `-2.47` | `e2a6` | `-193` |
| **49% (Ngoài biên dưới)** | **50%** | 24.5% | **50.0%** | `-560` | `+40` | **`+20`** | `-2.47` | `e2a6` | `-193` |
| **50%** | **50%** | 25.0% (`+10`) | **50.0% (`+20`)** | `-560` | `+40` | **`+20`** | `-2.47` | `e2a6` | `-193` |
| **75%** | **75%** | 56.25% (`+22`) | **75.0% (`+30`)** | `-560` | `+40` | **`+30`** | `-2.47` | `e2a6` | `-212` |
| **100% (Mặc định)** | **100%** | 100.0% (`+40`) | **100.0% (`+40`)** | `-560` | `+40` | **`+40`** | `-2.47` | `e2a6` | `-166` |
| **125%** | **125%** | 156.25% (`+62`) | **125.0% (`+50`)** | `-560` | `+40` | **`+50`** | `-2.46` | `e2a6` | `-176` |
| **150%** | **150%** | 225.0% (`+90`) | **150.0% (`+60`)** | `-560` | `+40` | **`+60`** | `-2.46` | `e2a6` | `-201` |
| **151% (Ngoài biên trên)** | **150%** | 226.5% | **150.0% (`+60`)** | `-560` | `+40` | **`+60`** | `-2.46` | `e2a6` | `-201` |
| **200% (Ngoài biên trên)** | **150%** | 300.0% (`+120`) | **150.0% (`+60`)** | `-560` | `+40` | **`+60`** | `-2.46` | `e2a6` | `-201` |

## 4. FINDING-04 — Script Nuốt Exit Code Khi Chạy Qua `| tee`

### 4.1 Xác Minh Độc Lập
- Trong V2, `build.sh`, `test.sh`, `benchmark.sh` đều chạy lệnh chính bên trái đường ống `| tee <logfile>` dưới `/bin/sh`. Do chuẩn POSIX `/bin/sh` không có `set -o pipefail`, mã thoát của toàn bộ pipeline luôn là mã thoát của `tee` (`0`), khiến lỗi biên dịch hoặc kiểm thử bị nuốt mất.

### 4.2 Sửa Chữa Trong V3 & Kết Quả Kiểm Thử Tiêm Lỗi (Fault Injection)
- Toàn bộ `build.sh`, `test.sh`, `benchmark.sh` trong V3 đã loại bỏ `| tee` và chuyển sang mẫu subshell bảo toàn mã thoát:
  ```sh
  set +e
  (
      set -eu
      run_main_task
  ) > "${LOG_FILE}" 2>&1
  EXIT_CODE="$?"
  set -e
  cat "${LOG_FILE}"
  exit "${EXIT_CODE}"
  ```
- Kết quả tiêm lỗi thực tế:
  - `./build.sh --inject-fault` -> trả về exit code **`42`** (`!= 0`).
  - `./test.sh --inject-fault` -> trả về exit code **`43`** (`!= 0`).
  - `./benchmark.sh --inject-fault` -> trả về exit code **`44`** (`!= 0`).

## 5. Tinh Chỉnh Bổ Sung Bảo Toàn Sức Cờ Trong `src/search.cpp`

Khi đối chiếu `baseline_src/search.cpp` và `src/search.cpp`, chúng tôi phát hiện và khắc phục thêm 3 điểm gây suy giảm chất lượng tìm kiếm trong V2:
1. **Khôi phục điều kiện IIR & Futility tại nút gốc (`src/search.cpp:1069, 1124`)**: Trong V2, việc sửa `!ttData.move` thành `!(ss->ttHit && ttData.move)` khiến nút gốc (`rootNode`, nơi `ttData.move = rootMoves[pvIdx].pv[0]` nhưng `ss->ttHit` có thể bằng `false`) bị giảm độ sâu `depth--` bởi Internal Iterative Reductions. V3 khôi phục chính xác `!ttData.move` của Stockfish 19.
2. **Bảo vệ nút PV trong `Deep Scaler Mode` (`src/search.cpp:1394`)**: Chỉ áp dụng lượng giảm LMR phụ trợ trên các nhánh không phải PV ở độ sâu lớn (`!PvNode && depth >= 16 && moveCount >= 12`), không làm biến dạng bảng LMR đã tinh chỉnh SPSA ở các nước đi chiến thuật trung cuộc.
3. **Chốt chặn độ sâu TT cho `Experience Book` (`src/search.cpp:360-369`)**: Chỉ đôn nước đi từ `experience.bin` lên `rootMoves[0]` trước Iterative Deepening khi độ sâu lưu trong `experience.bin` lớn hơn hẳn độ sâu hiện có trong Transposition Table (`std::max(Depth(12), Depth(ttData.depth + 1))`), ngăn việc ghi đè nước đi TT sâu bằng nước đi Experience nông.
