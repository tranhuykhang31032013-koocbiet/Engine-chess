# ANDROID NATIVE BUILD & VERIFICATION REPORT — Stockfish 19-Pro Ultimate V3

## 1. Phân Biệt Rạch Ròi Trạng Thái Kiểm Chứng (Verification Classification)

Theo đúng yêu cầu kỹ thuật của V3 (`FINDING-01`, Phần II và Phần VI), báo cáo này phân biệt tuyệt đối giữa:
1. **`ANDROID BUILD SYSTEM RECONSTRUCTED & ANTI-SPOOF VERIFIED`**: Đã hoàn thiện hệ thống script cross-compile, cấu hình cờ biên dịch/liên kết trong `src/Makefile`, và trình kiểm định nhị phân chống giả mạo (`PASS`).
2. **`ANDROID NDK CROSS-COMPILATION EXECUTION`**: Việc thực thi trình biên dịch chéo `aarch64-linux-android29-clang++` để sinh file ELF64 AArch64 (`NOT AVAILABLE` trên máy chủ `x86_64` offline hiện tại vì không có bộ công cụ Android NDK hoặc linker `aarch64`).
3. **`ANDROID DEVICE RUNTIME EXECUTION`**: Việc chạy trực tiếp binary ARM64 trên thiết bị Android thực tế hoặc trình giả lập Bionic ARM64 (`NOT AVAILABLE` trên máy chủ `x86_64` offline hiện tại).

**Nguyên tắc bất khả xâm phạm trong V3**:
- **Tuyệt đối không** copy lại binary `stockfish-19-pro-ultimate-v2-arm64` / `stockfish-android-arm64-universal` (`SHA-256: ffd8fc2004d3d19f9fdab95d84c92709aea92e8d3af405eda0b281b23cf1daf8`) rồi đổi tên thành V3.
- **Tuyệt đối không** chỉnh sửa hex trên binary gốc hoặc tạo file binary giả.
- Khi môi trường máy chủ thiếu Android NDK, `./build.sh android-arm64` phải dừng với mã lỗi khác 0 (`exit code 2`) và `./test.sh` phải ghi nhận trạng thái **`NOT AVAILABLE`**.

## 2. Kết Quả Kiểm Toán Toolchain Trên Máy Chủ Hiện Tại

Quá trình kiểm tra toàn diện hệ thống (`/` và `/usr`) trên máy chủ thực thi cho thấy:
- Kiến trúc CPU: `x86_64` (`Intel Xeon Platinum 8481C`).
- Trình biên dịch hiện có: `gcc-12` / `g++-12` (`x86_64-linux-gnu`).
- Trình liên kết (`ld.bfd` / `ld.gold`): Chỉ hỗ trợ các đích `elf_x86_64`, `elf32_x86_64`, `elf_i386`, `elf_iamcu` (không có `aarch64linux` hay `aarch64_elf64_le_vec`).
- Không có thư mục Android SDK/NDK (`aarch64-linux-android*-clang++`), không có `qemu-aarch64`, và không có kết nối mạng ra ngoài từ container sandbox để tải NDK.

## 3. Cấu Trúc Hệ Thống Build Android ARM64 Trong V3 (`android/build_android_v3.sh` & `src/Makefile`)

Để bất kỳ kỹ sư hoặc hệ thống CI/CD nào có cài đặt **Android NDK r26+** đều có thể biên dịch tái lập ngay lập tức từ mã nguồn V3, dự án đã cấu hình sẵn hai đích biên dịch trong `src/Makefile` và `android/build_android_v3.sh`:

### 3.1 Hai Đích Binary Android Được Hỗ Trợ
1. **Baseline ARM64 (`android/stockfish-19-pro-ultimate-v3-arm64`)**:
   - Đích Makefile: `ARCH=armv8 COMP=ndk`
   - Tập lệnh yêu cầu: `ARMv8.0-A + AdvSIMD (NEON)` (`-march=armv8-a -DUSE_NEON=8`) — tương thích với mọi thiết bị Android 64-bit.
2. **Optimized ARM64 DotProd (`android/stockfish-19-pro-ultimate-v3-arm64-dotprod`)**:
   - Đích Makefile: `ARCH=armv8-dotprod COMP=ndk`
   - Tập lệnh yêu cầu: `ARMv8.2-A + DotProd` (`-march=armv8.2-a+dotprod -DUSE_NEON=8 -DUSE_NEON_DOTPROD`) — tối ưu hóa phép nhân tích vô hướng 8-bit (`SDOT` / `UDOT`) trong các lớp tuyến tính của mạng NNUE trên các CPU ARMv8.2+ (Cortex-A75/A76/A77/A78/X1/X2/X3/X4).

### 3.2 Các Cờ Biên Dịch & Liên Kết Bắt Buộc Cho Android 10–15+
Trong `src/Makefile` (khối `ifeq ($(COMP),ndk)`) và `android/build_android_v3.sh`:
- **Position Independent Executable (PIE)**: `-fPIE` khi biên dịch và `-pie` khi liên kết (bắt buộc từ Android 5.0+ trở lên).
- **Liên kết tĩnh thư viện C++ (`libc++_static.a`)**: `-static-libstdc++` giúp binary chạy độc lập trên thiết bị Android mà không phụ thuộc vào `libc++_shared.so` bên ngoài.
- **Căn chỉnh trang bộ nhớ 16 KB cho Android 15+**: `-Wl,-z,max-page-size=16384` đảm bảo các segment `PT_LOAD` tương thích với nhân Android 15 sử dụng trang bộ nhớ 16 KB.
- **Nhúng mạng NNUE (`incbin`)**: Nhúng trực tiếp `nn-1a298aa575a0.nnue` vào vùng `.rodata` của binary thông qua `incbin.h` (không dùng `-fno-integrated-as` trên Clang NDK để trình hợp ngữ tích hợp của LLVM xử lý `.incbin` nhanh và chuẩn xác).

## 4. Quy Trình Kiểm Định Nhị Phân Tự Động (`android/verify_android_v3.py`)

Ngay sau khi `android/build_android_v3.sh` biên dịch xong mỗi binary Android, script sẽ tự động gọi `android/verify_android_v3.py` để kiểm tra 4 cổng bảo vệ (Fail-Closed):
1. **Cổng 1 — Chống Giả Mạo SHA-256 (`Anti-Spoofing Gate`)**: Tính SHA-256 của binary vừa tạo và so sánh với danh sách đen (`ffd8fc2004d3d19f9fdab95d84c92709aea92e8d3af405eda0b281b23cf1daf8`). Nếu trùng khớp, trả về `exit code 1`.
2. **Cổng 2 — Kiểm Định Cấu Trúc ELF64 AArch64 PIE**: Đọc trực tiếp header ELF để xác nhận:
   - Magic `\x7fELF`, 64-bit (`EI_CLASS == 2`), Little-Endian (`EI_DATA == 1`)
   - Kiến trúc máy: `EM_AARCH64` (`e_machine == 0xB7 / 183`)
   - Kiểu file: `ET_DYN` (`e_type == 3`, tương ứng PIE executable).
3. **Cổng 3 — Kiểm Định Bảng Chuỗi Tính Năng Pro (`.rodata` Signature Verification)**:
   Xác nhận sự hiện diện đầy đủ của tất cả các chuỗi định danh và UCI option Pro:
   - `Stockfish 19-Pro`
   - `Optimism Bias`
   - `Dynamic Aggression`
   - `Fortress Detection`
   - `Deep Scaler Mode`
   - `Experience Enabled`
   - `Experience File`
   - `Experience Book`
   - `Experience Learning Rate`
   - `Adaptive Opponent Mode`
   - `SF19EXP2`
   - `nn-1a298aa575a0.nnue`
4. **Cổng 4 — Thực Thi Động (Khi Có Runtime ARM64)**: Nếu phát hiện chạy trên kiến trúc `aarch64` hoặc có `qemu-aarch64`, tự động khởi chạy tiến trình và gửi chuỗi lệnh `uci`, `isready`, `eval`, `go depth 8`, `quit` để xác minh đầu ra thực tế.

## 5. Hướng Dẫn Biên Dịch & Kiểm Định Trên Máy Có Android NDK

```sh
# Đặt đường dẫn tới Android NDK (ví dụ r26d hoặc r27)
export ANDROID_NDK_HOME=/opt/android-ndk-r26d

# Biên dịch cả 2 biến thể (armv8 và armv8-dotprod) và chạy kiểm định tự động
JOBS=4 ./build.sh android-all

# Hoặc kiểm định thủ công từng file binary sau khi build:
python3 android/verify_android_v3.py android/stockfish-19-pro-ultimate-v3-arm64
python3 android/verify_android_v3.py android/stockfish-19-pro-ultimate-v3-arm64-dotprod
```
