# BUILD REPORT — Stockfish 19-Pro Ultimate V3

## 1. Môi Trường Biên Dịch Thực Tế (Host Build Environment)

| Thông Số | Giá Trị Xác Thực |
| :--- | :--- |
| **Hệ điều hành & Kernel** | GNU/Linux `x86_64`, Kernel `6.12.105+` |
| **CPU** | Intel(R) Xeon(R) Platinum 8481C CPU @ 2.70GHz (2 vCPUs, AVX2, BMI2, POPCNT, SSE4.1) |
| **Trình biên dịch Native C++** | `g++` (Debian `12.2.0-14+deb12u1`) `12.2.0`, chuẩn `-std=c++17` |
| **Trình liên kết (Linker)** | GNU `ld.bfd` / `ld.gold` `2.40` (Targets hỗ trợ: `elf_x86_64`, `elf32_x86_64`, `elf_i386`, `elf_iamcu`) |
| **Android NDK (`aarch64-linux-android29-clang++`)** | **Không được cài đặt trên máy chủ `x86_64` offline này** (`NOT AVAILABLE`) |
| **QEMU User-Mode (`qemu-aarch64`) / Thiết bị ADB** | **Không được cài đặt trên máy chủ `x86_64` offline này** (`NOT AVAILABLE`) |

## 2. Kết Quả Biên Dịch Các Binary Native (`x86-64-avx2`)

Lệnh thực thi:

```sh
JOBS=2 ./build.sh
```

Mã thoát (`exit code`): **`0`** (`BUILD SUCCESS` cho `x86-64-avx2`).

| Thành Phần Binary | Đường Dẫn | Kích Thước (Bytes) | Mã Băm SHA-256 | Số Node `bench` (`16 1 10`) | Trạng Thái |
| :--- | :--- | ---: | :--- | ---: | :--- |
| **V3 Candidate Release** (`Stockfish 19-Pro`) | `src/stockfish` | `841,912` | `c24cb011b2884abaaff6a4f1b1380c43b54a2ea2bc9cc7fb80961f261390efdb` | `453,169` | **BUILD SUCCESS & RUNTIME VERIFIED** |
| **V3 Candidate ASan+UBSan** (`Stockfish 19-Pro`) | `src/stockfish_asan` | `147,727,792` | `96a0eee67b04f45557751d2cca6a2afce73f80d8a3c605585989e19549645611` | `453,169` | **BUILD SUCCESS & ASAN VERIFIED** |
| **Independent Upstream Stockfish 19 Baseline** | `benchmark/stockfish_19_baseline_x86` | `790,744` | `e8b3e5d6a5f6c340b5ea2026abaf383d1f2883eba8b271312b4a0ff4b0de6b0e` | `453,169` | **BUILD SUCCESS & BASELINE VERIFIED** |
| **Embedded NNUE Network** | `nnue/nn-1a298aa575a0.nnue` | `95,050,608` | `1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2` | N/A | **SHA-256 VERIFIED** |

> **Lưu ý về đóng gói dung lượng (< 100 MB)**: Để gói phân phối `Stockfish-19-Pro-Ultimate-V3.tar.gz` gọn nhẹ và có thể tải xuống trực tiếp trong một file duy nhất, mạng `nn-1a298aa575a0.nnue` (95 MB) được hardlink giữa `nnue/`, `src/` và `baseline_src/`, còn các file thực thi `x86-64` được tái tạo tự động thông qua `JOBS=2 ./build.sh` từ mã nguồn `src/` và `baseline_src/`. Toàn bộ thông số kích thước và SHA-256 ở bảng trên được ghi nhận trực tiếp từ quá trình chạy `JOBS=2 ./build.sh` và lưu trong `tests/build_x86_64.log` và `benchmark/benchmark_results.json`.

## 3. Trạng Thái Biên Dịch Chéo Android ARM64 (`FINDING-01`)

Lệnh kiểm tra trên máy chủ hiện tại:

```sh
./build.sh android-arm64
```

Mã thoát (`exit code`): **`2`** (`NOT AVAILABLE` — Fail-Closed).

| Mục Tiêu (Target) | Kiến Trúc (`ARCH`) | Cờ Biên Dịch & Liên Kết Chuẩn Trong `src/Makefile` | Trạng Thái Trên Máy Chủ Offline Hiện Tại |
| :--- | :--- | :--- | :--- |
| `android/stockfish-19-pro-ultimate-v3-arm64` | `armv8` (`ARMv8.0-A + NEON`) | `-march=armv8-a -DUSE_NEON=8 -fPIE -pie -static-libstdc++ -Wl,-z,max-page-size=16384` | **`NOT AVAILABLE`** (Thiếu Android NDK `aarch64-linux-android29-clang++`) |
| `android/stockfish-19-pro-ultimate-v3-arm64-dotprod` | `armv8-dotprod` (`ARMv8.2-A + DotProd`) | `-march=armv8.2-a+dotprod -DUSE_NEON=8 -DUSE_NEON_DOTPROD -fPIE -pie -static-libstdc++ -Wl,-z,max-page-size=16384` | **`NOT AVAILABLE`** (Thiếu Android NDK `aarch64-linux-android29-clang++`) |

## 4. Kiểm Chứng Bảo Toàn Exit Code Của `build.sh` (`FINDING-04`)

- Trong V2, `build.sh` sử dụng `(...) 2>&1 | tee build_test.log` trên `/bin/sh` khiến mọi lỗi biên dịch bên trái dấu pipe bị `tee` che giấu và trả về exit code `0`.
- Trong V3, `build.sh` sử dụng subshell POSIX tường minh:
  ```sh
  (
      set -eu
      run_build
  ) > "${LOG_FILE}" 2>&1
  EXIT_CODE="$?"
  cat "${LOG_FILE}"
  exit "${EXIT_CODE}"
  ```
- **Kiểm chứng thực nghiệm (`--inject-fault`)**:
  - Lệnh `./build.sh --inject-fault` trả về exit code **`42`** (`!= 0`).
  - Lệnh `./build.sh android-arm64` (khi thiếu NDK) trả về exit code **`2`** (`!= 0`).
