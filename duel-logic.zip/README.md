# STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS EDITION

Hệ thống tổ chức giải đấu cờ vua tự động (Automated Chess Engine Tournament) trên **GitHub Actions (`ubuntu-24.04-arm`)** giữa hai engine:

1. **Engine A — `Stockfish 19 Pro Ultimate V3`** (`stockfish-19-pro-ultimate-v3-arm64-dotprod`)
   * Link Google Drive đã tích hợp sẵn: [stockfish-19-pro-ultimate-v3-arm64-dotprod](https://drive.google.com/file/d/19qHQjKmot41xaAZKz0LXqnqhAgtdjjXx/view?usp=drivesdk) (`ID: 19qHQjKmot41xaAZKz0LXqnqhAgtdjjXx`, `99.263.104` bytes)
2. **Engine B — `Stockfish Android ARM64 Universal`** (`stockfish-android-arm64-universal.tar.gz`)
   * Link Google Drive đã tích hợp sẵn: [stockfish-android-arm64-universal.tar.gz](https://drive.google.com/file/d/1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l/view?usp=drivesdk) (`ID: 1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l`, `80.233.187` bytes)

## 1. Giải Quyết Triệt Để Giới Hạn Upload 25 MB Của GitHub Web

Vì giao diện web của GitHub giới hạn chỉ cho phép tải lên tệp **dưới 25 MB**, hệ thống đã được thiết kế để bạn **chỉ cần upload đúng 2 tệp siêu nhẹ (tổng dung lượng ~1 MB)** lên GitHub Repository:

```text
ten-repository-cua-ban/
├── .github/
│   └── workflows/
│       └── stockfish-ultimate-duel.yml    <-- 1. File cấu hình GitHub Actions (~7 KB)
└── duel-logic.zip                         <-- 2. Gói nén chứa toàn bộ logic & scripts (~1 MB)
```

Bạn **không cần** tải 2 tệp engine nặng (>80 MB) lên GitHub nữa. Khi nhấn **Run workflow**, GitHub Actions sẽ tự động thực hiện toàn bộ quy trình:

1. **Bước 1 — Tự động giải nén `duel-logic.zip`**: Bung bộ điều phối giải đấu (`scripts/build_engines.sh`, `scripts/tournament.py`, `tests/test_tournament.py`, `requirements.txt`, `experience.bin` và cây mã nguồn C++ đối chứng) ngay tại thư mục gốc.
2. **Bước 2 — Tự động tải 2 tệp Engine từ Google Drive về Runner**:
   * Tải tự động [stockfish-19-pro-ultimate-v3-arm64-dotprod](https://drive.google.com/file/d/19qHQjKmot41xaAZKz0LXqnqhAgtdjjXx/view?usp=drivesdk) (`ID: 19qHQjKmot41xaAZKz0LXqnqhAgtdjjXx`) và kiểm tra khớp `SHA-256: 6ea6746074e5860f78f7aae43532bc1ec9491c1e7055f328c0aeec5990ee62e9`.
   * Tải tự động [stockfish-android-arm64-universal.tar.gz](https://drive.google.com/file/d/1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l/view?usp=drivesdk) (`ID: 1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l`) và kiểm tra khớp `SHA-256: ebb24051aa4a222b4daaf049b882ecf1163d370c128fe02316602643f4d5e426`.
   * Cơ chế tải 3 lớp (`gdown` → endpoint `drive.usercontent.google.com` → trình xử lý token xác nhận virus-scan bằng Python `urllib`) đảm bảo vượt qua trang cảnh báo tệp lớn (>25 MB) của Google Drive.
3. **Bước 3 — Kiểm định ELF/ABI, trích xuất NNUE và biên dịch đối xứng**:
   * Xác thực đầy đủ chữ ký nhị phân của `Stockfish 19-Pro` (`LearnManager`, `GlobalLearn`, `Optimism Bias`, `Dynamic Aggression`, `Fortress Detection`, `Deep Scaler Mode`, `Experience Enabled`, `Adaptive Opponent Mode`) và trích xuất mạng `nn-1a298aa575a0.nnue` (`SHA-256: 1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2`) nhúng tại offset `33344`.
   * Giải nén `stockfish-android-arm64-universal.tar.gz`, đối chiếu `stockfish/src/` khớp 100% (`76/76` tệp) với `baseline_src/`, và biên dịch cả hai engine sang chuẩn Linux ARM64 native trên runner `ubuntu-24.04-arm` (`ARCH=armv8-dotprod` hoặc `ARCH=armv8`) với cùng trình biên dịch (`g++`) và mức tối ưu hóa (`-O3`).
4. **Bước 4 — Chạy Solo & Xuất Artifact**:
   * Đấu đối xứng theo cặp khai cuộc (30 khai cuộc Standard Chess, đổi màu quân luân phiên), in log tiếng Việt trực tiếp sau từng ván và phát heartbeat 5 phút/lần.
   * Tự động chia 2 chặng nếu chọn 4–6 giờ (Chặng 1 chạy 3 giờ + Chặng 2 resume từ checkpoint chạy phần thời gian còn lại) và đóng gói toàn bộ kết quả vào artifact **`Stockfish-Ultimate-Duel-Results`** (lưu trữ 30 ngày).
