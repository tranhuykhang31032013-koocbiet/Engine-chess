# STRENGTH & SCIENTIFIC BENCHMARK REPORT — Stockfish 19-Pro Ultimate V3

## 1. Xác Minh Tính Độc Lập Của Đối Thủ (`FINDING-02` Fail-Closed Verification)

Trước khi bắt đầu bất kỳ ván đấu nào, `benchmark/run_benchmark.py` thực hiện kiểm tra bắt buộc (`verify_opponent_separation`) giữa **V3 Candidate** và **Stockfish 19 Baseline**:

| Thuộc Tính Kiểm Định | V3 Candidate (`src/stockfish`) | Stockfish 19 Baseline (`benchmark/stockfish_19_baseline_x86`) | Kết Luận Kiểm Chứng |
| :--- | :--- | :--- | :--- |
| **Nguồn biên dịch** | `src/` (Stockfish 19-Pro Ultimate V3) | `baseline_src/` (Upstream Stockfish 19 gốc) | Hai cây mã nguồn tách biệt |
| **Kích thước file (Bytes)** | `841,912` bytes | `790,744` bytes | Chênh lệch `+47,184` bytes (code Pro) |
| **Mã băm SHA-256** | `c24cb011b2884abaaff6a4f1b1380c43b54a2ea2bc9cc7fb80961f261390efdb` | `e8b3e5d6a5f6c340b5ea2026abaf383d1f2883eba8b271312b4a0ff4b0de6b0e` | **Khác biệt hoàn toàn (`!=`)** |
| **Định danh `id name`** | `Stockfish 19-Pro` | `Stockfish 19` | Khác biệt rõ ràng |
| **Tổng số UCI Options** | `28` options (`7` Pro options được xác nhận) | `19` options (`0` Pro options) | Baseline là Stockfish 19 thuần khiết |
| **Chốt chặn tự đấu (`Self-Play Guard`)** | Đã kiểm thử truyền cùng binary / cùng SHA-256 | Dừng ngay lập tức với `exit code 2` | **Fail-Closed Hoạt Động Chính Xác** |

## 2. Cấu Hình Giải Đấu Thực Nghiệm & Khai Cuộc

- **Tập khai cuộc chuẩn (10 khai cuộc Đại kiện tướng cân bằng, đổi màu quân Trắng/Đen đối xứng = 20 ván / nhóm, tổng cộng 80 ván)**:
  1. *Ruy Lopez: Morphy Defense* (`1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6`)
  2. *Italian Game: Giuoco Piano* (`1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6`)
  3. *Sicilian Defense: Najdorf* (`1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6`)
  4. *French Defense: Winawer* (`1. e4 e6 2. d4 d5 3. Nc3 Bb4 4. e5 c5`)
  5. *Caro-Kann: Classical* (`1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5`)
  6. *Queen's Gambit Declined* (`1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Bg5 Be7`)
  7. *Slav Defense: Main Line* (`1. d4 d5 2. c4 c6 3. Nf3 Nf6 4. Nc3 dxc4`)
  8. *Nimzo-Indian Defense* (`1. d4 Nf6 2. c4 e6 3. Nc3 Bb4 4. e3 c5`)
  9. *King's Indian Defense* (`1. d4 Nf6 2. c4 g6 3. Nc3 Bg7 4. e4 d6`)
  10. *English Opening: Symmetrical* (`1. c4 c5 2. Nc3 Nc6 3. g3 g6 4. Bg2 Bg7`)
- **Cơ sở dữ liệu kinh nghiệm khởi tạo (`experience/experience.bin`)**:
  - Định dạng: `SF19EXP2` (Version 2, có checksum FNV-1a trên từng bản ghi 24 bytes).
  - Số bản ghi được seed ở `Depth 13` trước giải đấu: `60` bản ghi (`1,456` bytes, SHA-256 `5daadde570802539e49f1bb105e0167d02b884c9a21e670a52714f63447637ea`).
  - Trước mỗi nhóm trận đấu (`Match B`, `Match C`, `Match D`), `experience/experience.bin` đều được khôi phục về trạng thái seed chuẩn này để đảm bảo tính độc lập và tái lập khoa học giữa các nhóm.
- **Điều kiện phần cứng & Time Control**:
  - `Threads = 1`, `Hash = 32 MB`, giữ nguyên tiến trình UCI xuyên suốt trận đấu (`PersistentUCIEngine`) để không chịu chi phí nạp lại mạng NNUE 95 MB ở mỗi nước đi.
  - Các trận Fixed-Time sử dụng `go movetime 80` (`80 ms/nước`, lớn hơn gấp 3.2 lần mức `25 ms/nước` bị cấm trong yêu cầu kiểm toán).
  - Trận Fixed-Nodes sử dụng `go nodes 25000` (`25,000 nodes/nước`).

## 3. Kết Quả Chi Tiết 4 Nhóm Benchmark Bắt Buộc (80 Ván Đấu)

Toàn bộ dữ liệu dưới đây khớp tuyệt đối 1-1 với `benchmark/benchmark_results.json` và 80 biên bản ván đấu trong `benchmark/tournament_games.pgn`:

| Nhóm Trận Đấu (`Match ID`) | Đội Hình Thi Đấu (Candidate vs Opponent) | Kiểm Soát Tìm Kiếm | Số Ván | Thắng (`W`) | Hòa (`D`) | Thua (`L`) | Điểm Số (`Score %`) | Chênh Lệch Elo (`95% CI`) | LOS (`%`) | SPRT (`H0=0, H1=+10`, `LLR`) |
| :--- | :--- | :--- | ---: | ---: | ---: | ---: | ---: | :--- | ---: | :--- |
| **MATCH A — BASELINE** (`match_a_baseline_core`) | `SF19-Pro-V3 (Exp OFF)` vs `Stockfish 19 Baseline` | `80 ms/move` | 20 | **2** | **17** | **1** | **10.5 / 20.0 (`52.50%`)** | **`+17.39 +/- 59.20`** (`[-41.30, +77.09]`) | `71.81%` | `LLR = +0.139` (`INCONCLUSIVE_SAMPLE_SIZE`) |
| **MATCH B — EXPERIENCE A/B** (`match_b_experience_ab`) | `SF19-Pro-V3 (Exp ON)` vs `SF19-Pro-V3 (Exp OFF)` | `80 ms/move` | 20 | **1** | **17** | **2** | **9.5 / 20.0 (`47.50%`)** | **`-17.39 +/- 59.20`** (`[-77.09, +41.30]`) | `28.19%` | `LLR = -0.251` (`INCONCLUSIVE_SAMPLE_SIZE`) |
| **MATCH C — FIXED NODES** (`match_c_fixed_nodes`) | `SF19-Pro-V3 (Exp ON)` vs `Stockfish 19 Baseline` | `25,000 nodes/move` | 20 | **0** | **18** | **2** | **9.0 / 20.0 (`45.00%`)** | **`-34.86 +/- 46.42`** (`[-81.91, +10.94]`) | `7.86%` | `LLR = -0.731` (`INCONCLUSIVE_SAMPLE_SIZE`) |
| **MATCH D — FIXED TIME** (`match_d_fixed_time`) | `SF19-Pro-V3 (Exp ON)` vs `Stockfish 19 Baseline` | `80 ms/move` | 20 | **4** | **16** | **0** | **12.0 / 20.0 (`60.00%`)** | **`+70.44 +/- 64.26`** (`[+8.58, +137.09]`) | `97.72%` | `LLR = +0.668` (`INCONCLUSIVE_SAMPLE_SIZE`) |
| **TỔNG HỢP VS BASELINE ĐỘC LẬP** (`Matches A + C + D`) | `SF19-Pro-V3` vs `Stockfish 19 Baseline` | Hỗn hợp (`Time + Nodes`) | **60** | **6** | **51** | **3** | **31.5 / 60.0 (`52.50%`)** | **`+17.39 +/- 33.96`** (`[-16.40, +51.51]`) | **`84.13%`** | `LLR = +0.417` (`INCONCLUSIVE_SAMPLE_SIZE`) |

## 4. Phân Tích Kỹ Thuật & Đánh Giá Thống Kê Trung Thực

1. **Hiệu quả ở chế độ Fixed-Time thực tế (`Match A` và `Match D`)**:
   - Trong `Match A` (`Exp OFF` đấu với `Stockfish 19 Baseline` ở `80 ms/nước`), V3 đạt kết quả dương `+2 =17 -1` (`52.5%`, `+17.39 Elo`, `LOS 71.81%`), cho thấy sau khi sửa lỗi nhân đôi `Dynamic Aggression` (`FINDING-03`) và khôi phục điều kiện IIR tại nút gốc, bộ máy tìm kiếm cốt lõi hoạt động ổn định và không bị suy giảm sức cờ.
   - Trong `Match D` (`Exp ON + Experience Book` đấu với `Stockfish 19 Baseline` ở `80 ms/nước`), việc sử dụng cơ sở dữ liệu `experience.bin` đã được seed ở `Depth 13` (sâu hơn độ sâu tìm kiếm trực tiếp `Depth 10-11` ở mốc `80 ms/nước`) giúp V3 bất bại và thắng 4 ván: **`+4 =16 -0` (`60.0%`, `+70.44 +/- 64.26 Elo`, khoảng tin cậy 95% `[+8.58, +137.09]`, `LOS = 97.72%`)**.
2. **Giải thích sự khác biệt giữa Fixed-Time (`Match D`) và Fixed-Nodes (`Match C`)**:
   - Ở chế độ `Fixed Nodes` (`25,000 nodes/nước`, `Match C`), quá trình tìm kiếm bị ngắt cứng ngay khi chạm ngưỡng `25,000` node (thường rơi vào giữa một iteration của PVS tại `Depth 11`), đạt `+0 =18 -2` (`45.0%`, `-34.86 +/- 46.42 Elo`, khoảng tin cậy 95% `[-81.91, +10.94]` vẫn chứa `0`). Ngược lại, ở chế độ `Fixed Time` (`80 ms/nước`, `Match D`), bộ quản lý thời gian và thứ tự nước đi gốc từ `experience.bin` (`Depth 13`) giúp PVS hội tụ nhanh hơn ở đầu cuộc, đạt `+4 =16 -0`.
3. **Kết luận SPRT trung thực**:
   - Với cỡ mẫu 20 ván/nhóm (60 ván đối đầu trực tiếp với Baseline độc lập, đạt tổng hợp **`+6 =51 -3`, `+17.39 +/- 33.96 Elo`, `LOS 84.13%`**), chỉ số `LLR` của SPRT (`H0 = 0 Elo, H1 = +10 Elo, alpha = beta = 0.05`, ngưỡng `[-2.944, +2.944]`) đạt `+0.417` (`Match D` đạt `+0.668`), do đó trạng thái thống kê SPRT được ghi nhận trung thực là **`INCONCLUSIVE_SAMPLE_SIZE`** (cần khoảng 1,500–3,000 ván trên hệ thống đa nhân để vượt ngưỡng `LLR = +/-2.944` cho giả thuyết `+10 Elo`).
   - Toàn bộ kết quả trong `STRENGTH_REPORT.md`, `benchmark/benchmark_results.json` và `benchmark/tournament_games.pgn` được kiểm tra đối chiếu tự động bởi `verify_package.sh` (đảm bảo tổng số ván `80 == 80` và mã băm SHA-256 hai bên hoàn toàn độc lập).
