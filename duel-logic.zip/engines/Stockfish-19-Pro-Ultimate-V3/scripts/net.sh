#!/bin/sh

# Stockfish 19-Pro Ultimate V3 — Reproducible NNUE Provisioning & Verification Script
# Supports offline provisioning from ../nnue/nn-1a298aa575a0.nnue before attempting network download.

if command -v sha256sum >/dev/null 2>&1; then
  sha256sum="sha256sum"
elif command -v shasum >/dev/null 2>&1; then
  sha256sum="shasum -a 256"
else
  >&2 echo "sha256sum or shasum has to be installed to verify net files."
  exit 1
fi

validate_network() {
  _nnue_file_name="$1"
  _expected_short_hash="$(echo "$_nnue_file_name" | sed 's/^nn-\([a-z0-9]\{12\}\)\.nnue$/\1/')"

  if [ ! -f "$_nnue_file_name" ]; then
    return 1
  fi

  if [ "$_nnue_file_name" = "$_expected_short_hash" ]; then
    return 1
  fi

  _hash="$($sha256sum "$_nnue_file_name" | cut -c 1-12)"

  if [ "$_hash" != "$_expected_short_hash" ]; then
    rm -f "$_nnue_file_name"
    return 1
  fi

  return 0
}

provision_local_network() {
  _nnue_file_name="$1"
  if validate_network "$_nnue_file_name"; then
    echo "Existing $_nnue_file_name validated, skipping download"
    return 0
  fi

  for _cand in "../nnue/$_nnue_file_name" "./nnue/$_nnue_file_name" "../src/$_nnue_file_name"; do
    if [ -f "$_cand" ]; then
      ln "$_cand" "$_nnue_file_name" 2>/dev/null || cp "$_cand" "$_nnue_file_name"
      if validate_network "$_nnue_file_name"; then
        echo "Provisioned and validated $_nnue_file_name from local $_cand"
        return 0
      fi
    fi
  done

  return 1
}

fetch_network() {
  _filename="$1"

  if provision_local_network "$_filename"; then
    return 0
  fi

  for url in \
    "https://tests.stockfishchess.org/api/nn/$_filename" \
    "https://github.com/official-stockfish/networks/raw/master/$_filename"; do
    echo "Downloading from $url ..."
    if command -v wget >/dev/null 2>&1; then
      wget -qO "$_filename" "$url"
    elif command -v curl >/dev/null 2>&1; then
      curl -skL "$url" -o "$_filename"
    fi

    if validate_network "$_filename"; then
      echo "Successfully validated $_filename"
      return 0
    fi
  done

  >&2 echo "Failed to provision or download $_filename"
  return 1
}

evaluate_hdr="${1:-evaluate.h}"
if [ ! -f "$evaluate_hdr" ] && [ -f "src/$evaluate_hdr" ]; then
  evaluate_hdr="src/$evaluate_hdr"
fi

for nnue_macro in EvalFileDefaultNameBig EvalFileDefaultNameSmall EvalFileDefaultName; do
  nnue_file_name="$(grep "$nnue_macro" "$evaluate_hdr" 2>/dev/null | grep "#define" | sed 's/.*\(nn-[a-z0-9]\{12\}.nnue\).*/\1/')"
  if [ -n "$nnue_file_name" ]; then
    fetch_network "$nnue_file_name" || exit 1
  fi
done
