#!/bin/sh
set -eu
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 4)}"
MODE="${1:-auto}"

if [ "${MODE}" = "android-arm64" ] || [ "${MODE}" = "arm64" ] || [ "${MODE}" = "dotprod" ]; then
    exec sh "${ROOT_DIR}/android/build_android_v3.sh" "${MODE}"
fi

UNAME_M="$(uname -m 2>/dev/null || echo x86_64)"
if [ "${UNAME_M}" = "aarch64" ] || [ "${UNAME_M}" = "arm64" ]; then
    sh "${ROOT_DIR}/android/build_android_v3.sh" dotprod
else
    make -C "${ROOT_DIR}/src" clean
    make -C "${ROOT_DIR}/src" -j"${JOBS}" build ARCH=x86-64-avx2
    cp -f "${ROOT_DIR}/experience/experience.bin" "${ROOT_DIR}/src/experience.bin"
fi
