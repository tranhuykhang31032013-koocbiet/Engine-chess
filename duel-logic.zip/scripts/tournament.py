#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS TOURNAMENT ARBITER & ENGINE VERIFIER
=============================================================================
Hệ thống điều phối giải đấu đối kháng tự động giữa hai engine:
  - Engine A: Stockfish 19 Pro Ultimate V3
  - Engine B: Stockfish Android ARM64 Universal

Tính năng cốt lõi:
  1. Kiểm định hậu biên dịch (Binary, SHA256, UCI handshake, uciok, readyok,
     NNUE load, nước đi hợp lệ, trạng thái Experience) và tạo build-manifest.json.
  2. Tổ chức giải đấu đối xứng theo cặp khai cuộc (2 ván/khai cuộc, đổi màu quân
     Trắng/Đen luân phiên) với bộ 30 khai cuộc Standard Chess đa dạng.
  3. Trọng tài cờ vua thực tế bằng python-chess: Checkmate, Stalemate,
     Threefold repetition, Fivefold repetition, 50-move rule, 75-move rule,
     Insufficient material, giới hạn ply an toàn (Technical Stop) và xử lý
     forfeiture khi crash/timeout/nước đi bất hợp lệ.
  4. In log trực tiếp ra GitHub Actions Console sau từng ván và phát heartbeat
     định kỳ.
  5. Ghi dữ liệu an toàn (atomic write qua file tạm + fsync + os.replace) và hỗ trợ
     chia 2 chặng (1-3 giờ: 1 chặng; 4-6 giờ: chặng 1 chạy 3 giờ + chặng 2 resume
     chạy phần thời gian còn lại từ checkpoint mà không mất hay trùng ván).
  6. Đối chiếu kết quả từ PGN thực tế và xuất đầy đủ: matches.log, matches.pgn,
     matches.csv, matches.jsonl, summary.json, summary.md, build-manifest.json.
"""

from __future__ import annotations

import argparse
import csv
import datetime
import hashlib
import io
import json
import math
import os
import platform
import random
import re
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

import chess
import chess.engine
import chess.pgn

ENGINE_PRO_NAME = "Stockfish 19 Pro Ultimate V3"
ENGINE_UNI_NAME = "Stockfish Android ARM64 Universal"

ENGINE_PRO_SHORT = "Pro"
ENGINE_UNI_SHORT = "Universal"

PRO_SPECIFIC_OPTION_NAMES = [
    "Optimism Bias",
    "Dynamic Aggression",
    "Fortress Detection",
    "Deep Scaler Mode",
    "Experience Enabled",
    "Experience File",
    "Experience Book",
    "Experience Learning Rate",
    "Adaptive Opponent Mode",
]

# Danh sách 30 khai cuộc Standard Chess hợp lệ, đa dạng
STANDARD_OPENINGS: List[Tuple[str, List[str]]] = [
    ("Italian Game: Giuoco Piano", ["e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "f8c5", "c2c3", "g8f6"]),
    ("Italian Game: Two Knights Defense", ["e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "g8f6", "d2d3", "f8e7"]),
    ("Ruy Lopez: Morphy Defense", ["e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "a7a6", "b5a4", "g8f6", "e1g1", "f8e7"]),
    ("Ruy Lopez: Berlin Defense", ["e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "g8f6", "e1g1", "f6e4"]),
    ("Sicilian Defense: Najdorf Variation", ["e2e4", "c7c5", "g1f3", "d7d6", "d2d4", "c5d4", "f3d4", "g8f6", "b1c3", "a7a6"]),
    ("Sicilian Defense: Dragon Variation", ["e2e4", "c7c5", "g1f3", "d7d6", "d2d4", "c5d4", "f3d4", "g8f6", "b1c3", "g7g6"]),
    ("Sicilian Defense: Classical Variation", ["e2e4", "c7c5", "g1f3", "d7d6", "d2d4", "c5d4", "f3d4", "g8f6", "b1c3", "b8c6"]),
    ("Sicilian Defense: Taimanov Variation", ["e2e4", "c7c5", "g1f3", "e7e6", "d2d4", "c5d4", "f3d4", "b8c6"]),
    ("French Defense: Winawer Variation", ["e2e4", "e7e6", "d2d4", "d7d5", "b1c3", "f8b4", "e4e5", "c7c5"]),
    ("French Defense: Tarrasch Variation", ["e2e4", "e7e6", "d2d4", "d7d5", "b1d2", "g8f6", "e4e5", "f6d7"]),
    ("French Defense: Classical Variation", ["e2e4", "e7e6", "d2d4", "d7d5", "b1c3", "g8f6", "c1g5", "f8e7"]),
    ("Caro-Kann Defense: Classical Variation", ["e2e4", "c7c6", "d2d4", "d7d5", "b1c3", "d5e4", "c3e4", "c8f5"]),
    ("Caro-Kann Defense: Advance Variation", ["e2e4", "c7c6", "d2d4", "d7d5", "e4e5", "c8f5", "g1f3", "e7e6"]),
    ("Queen's Gambit Declined: Orthodox", ["d2d4", "d7d5", "c2c4", "e7e6", "b1c3", "g8f6", "c1g5", "f8e7"]),
    ("Queen's Gambit Accepted", ["d2d4", "d7d5", "c2c4", "d5c4", "g1f3", "g8f6", "e2e3", "e7e6"]),
    ("Slav Defense: Main Line", ["d2d4", "d7d5", "c2c4", "c7c6", "g1f3", "g8f6", "b1c3", "d5c4"]),
    ("Semi-Slav Defense", ["d2d4", "d7d5", "c2c4", "c7c6", "g1f3", "g8f6", "b1c3", "e7e6"]),
    ("King's Indian Defense: Classical", ["d2d4", "g8f6", "c2c4", "g7g6", "b1c3", "f8g7", "e2e4", "d7d6", "g1f3", "e8g8"]),
    ("King's Indian Defense: Fianchetto", ["d2d4", "g8f6", "c2c4", "g7g6", "g1f3", "f8g7", "g2g3", "e8g8", "f1g2", "d7d6"]),
    ("Nimzo-Indian Defense: Rubinstein", ["d2d4", "g8f6", "c2c4", "e7e6", "b1c3", "f8b4", "e2e3", "e8g8"]),
    ("Grunfeld Defense: Exchange Variation", ["d2d4", "g8f6", "c2c4", "g7g6", "b1c3", "d7d5", "c4d5", "f6d5", "e2e4", "d5c3", "b2c3", "f8g7"]),
    ("English Opening: Symmetrical", ["c2c4", "c7c5", "b1c3", "b8c6", "g2g3", "g7g6", "f1g2", "f8g7"]),
    ("English Opening: Reversed Sicilian", ["c2c4", "e7e5", "b1c3", "g8f6", "g1f3", "b8c6"]),
    ("Catalan Opening: Closed", ["d2d4", "g8f6", "c2c4", "e7e6", "g2g3", "d7d5", "f1g2", "f8e7", "g1f3", "e8g8"]),
    ("Scotch Game: Classical", ["e2e4", "e7e5", "g1f3", "b8c6", "d2d4", "e5d4", "f3d4", "f8c5"]),
    ("Petrov's Defense: Classical", ["e2e4", "e7e5", "g1f3", "g8f6", "f3e5", "d7d6", "e5f3", "f6e4", "d2d4", "d6d5"]),
    ("Vienna Game: Falkbeer Variation", ["e2e4", "e7e5", "b1c3", "g8f6", "f2f4", "d7d5"]),
    ("Pirc Defense: Austrian Attack", ["e2e4", "d7d6", "d2d4", "g8f6", "b1c3", "g7g6", "f2f4", "f8g7"]),
    ("London System", ["d2d4", "d7d5", "g1f3", "g8f6", "c1f4", "e7e6", "e2e3", "c7c5"]),
    ("Reti Opening", ["g1f3", "d7d5", "c2c4", "e7e6", "g2g3", "g8f6", "f1g2", "f8e7"]),
]


def atomic_write_text(filepath: str, content: str) -> None:
    """Ghi file an toàn qua file tạm + fsync + os.replace."""
    parent = os.path.dirname(os.path.abspath(filepath))
    os.makedirs(parent, exist_ok=True)
    tmp_path = f"{filepath}.tmp.{os.getpid()}"
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, filepath)


def atomic_write_json(filepath: str, data: Any) -> None:
    """Ghi JSON an toàn qua file tạm + fsync + os.replace."""
    text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
    atomic_write_text(filepath, text)


def sha256_file(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def format_hms(seconds: float) -> str:
    total_sec = max(0, int(round(seconds)))
    hrs = total_sec // 3600
    mins = (total_sec % 3600) // 60
    secs = total_sec % 60
    return f"{hrs:02d}:{mins:02d}:{secs:02d}"


def format_vn_int(val: int) -> str:
    """Định dạng số nguyên dùng dấu chấm phân cách hàng nghìn theo chuẩn tiếng Việt."""
    return f"{val:,}".replace(",", ".")


def parse_duration_hours(raw_value: str) -> int:
    """Chuyển đổi lựa chọn thời gian ('1', '1 Hour', '6 Hours', '3 giờ') sang số giờ (1..6)."""
    m = re.search(r"(\d+)", str(raw_value).strip())
    if not m:
        raise ValueError(f"Giá trị thời lượng không hợp lệ: {raw_value!r}")
    hours = int(m.group(1))
    if hours < 1 or hours > 6:
        raise ValueError(f"Thời lượng phải nằm trong khoảng 1 đến 6 giờ (nhận được: {hours}).")
    return hours


def parse_positive_int(raw_value: str, label: str, allowed: Optional[List[int]] = None) -> int:
    m = re.search(r"(\d+)", str(raw_value).strip())
    if not m:
        raise ValueError(f"Giá trị {label} không hợp lệ: {raw_value!r}")
    val = int(m.group(1))
    if allowed and val not in allowed:
        raise ValueError(f"Giá trị {label} ({val}) phải thuộc {allowed}.")
    return val


def compute_stage_plan(duration_hours: int) -> Dict[str, Any]:
    """
    Tính toán kế hoạch chia chặng để xử lý giới hạn 6 giờ của GitHub Actions:
    - Với lựa chọn 1–3 giờ: chỉ chạy 1 chặng (stage1_hours = duration_hours, stage2_hours = 0).
    - Với lựa chọn 4–6 giờ: chia thành 2 chặng (stage1_hours = 3, stage2_hours = duration_hours - 3).
    """
    if duration_hours < 1 or duration_hours > 6:
        raise ValueError(f"duration_hours phải từ 1 đến 6, nhận được {duration_hours}")
    total_seconds = duration_hours * 3600
    if duration_hours <= 3:
        stage1_hours = duration_hours
        stage2_hours = 0
        needs_stage2 = False
    else:
        stage1_hours = 3
        stage2_hours = duration_hours - 3
        needs_stage2 = True
    return {
        "duration_hours": duration_hours,
        "total_seconds": total_seconds,
        "stage1_hours": stage1_hours,
        "stage1_seconds": stage1_hours * 3600,
        "stage2_hours": stage2_hours,
        "stage2_seconds": stage2_hours * 3600,
        "needs_stage2": needs_stage2,
    }


def probe_engine_uci_and_move(binary_path: str, timeout_sec: float = 15.0) -> Dict[str, Any]:
    binary_path = os.path.abspath(binary_path)
    """
    Kiểm tra toàn diện một binary UCI:
      1. Binary tồn tại và có quyền thực thi (executable).
      2. Gửi 'uci' -> nhận 'uciok', trích xuất id name, id author và danh sách UCI options.
      3. Gửi 'isready' -> nhận 'readyok'.
      4. Nếu engine hỗ trợ 'expinfo' (Pro), ghi nhận thông tin Experience.
      5. Gửi 'position startpos' + 'go movetime 100' -> kiểm tra NNUE load thành công
         và nhận nước đi 'bestmove' hợp lệ trên bàn cờ chuẩn.
    """
    if not os.path.isfile(binary_path):
        raise RuntimeError(f"Binary không tồn tại: {binary_path}")
    if not os.access(binary_path, os.X_OK):
        raise RuntimeError(f"Binary không có quyền thực thi (not executable): {binary_path}")

    cmd = [sys.executable, binary_path] if binary_path.endswith(".py") else [binary_path]
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        cwd=os.path.dirname(os.path.abspath(binary_path)),
    )

    id_name = ""
    id_author = ""
    options: Dict[str, Dict[str, Any]] = {}
    uciok_received = False
    readyok_received = False
    nnue_loaded = False
    nnue_info_lines: List[str] = []
    exp_info_lines: List[str] = []
    bestmove_str = ""

    def parse_option_line(line: str) -> None:
        m = re.match(r"^option name (.+?) type (\S+)(?:\s+(.*))?$", line.strip())
        if not m:
            return
        opt_name, opt_type, rest = m.group(1), m.group(2), (m.group(3) or "").strip()
        opt_meta: Dict[str, Any] = {"type": opt_type}
        if rest:
            def_m = re.search(r"\bdefault\s+(.+?)(?=\s+\b(?:min|max|var)\b|$)", rest)
            if def_m:
                opt_meta["default"] = def_m.group(1).strip()
            min_m = re.search(r"\bmin\s+(-?\d+)", rest)
            if min_m:
                opt_meta["min"] = int(min_m.group(1))
            max_m = re.search(r"\bmax\s+(-?\d+)", rest)
            if max_m:
                opt_meta["max"] = int(max_m.group(1))
        options[opt_name] = opt_meta

    try:
        assert proc.stdin is not None and proc.stdout is not None
        proc.stdin.write("uci\n")
        proc.stdin.flush()

        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            line = proc.stdout.readline()
            if not line:
                break
            s = line.strip()
            if s.startswith("id name "):
                id_name = s[len("id name "):].strip()
            elif s.startswith("id author "):
                id_author = s[len("id author "):].strip()
            elif s.startswith("option name "):
                parse_option_line(s)
            elif s == "uciok":
                uciok_received = True
                break

        if not uciok_received:
            raise RuntimeError(f"UCI handshake thất bại (không nhận được uciok) từ {binary_path}")

        proc.stdin.write("isready\n")
        proc.stdin.flush()
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            line = proc.stdout.readline()
            if not line:
                break
            s = line.strip()
            if "Experience" in s:
                exp_info_lines.append(s)
            if s == "readyok":
                readyok_received = True
                break

        if not readyok_received:
            raise RuntimeError(f"Engine không phản hồi readyok: {binary_path}")

        if "Experience Enabled" in options:
            proc.stdin.write("expinfo\nisready\n")
            proc.stdin.flush()
            deadline = time.monotonic() + timeout_sec
            while time.monotonic() < deadline:
                line = proc.stdout.readline()
                if not line:
                    break
                s = line.strip()
                if "Experience" in s:
                    exp_info_lines.append(s)
                if s == "readyok":
                    break

        proc.stdin.write("position startpos\ngo movetime 100\n")
        proc.stdin.flush()
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            line = proc.stdout.readline()
            if not line:
                break
            s = line.strip()
            if "NNUE evaluation" in s or "nn-" in s:
                nnue_loaded = True
                nnue_info_lines.append(s)
            if s.startswith("bestmove "):
                parts = s.split()
                if len(parts) >= 2:
                    bestmove_str = parts[1]
                break

        proc.stdin.write("quit\n")
        proc.stdin.flush()
        proc.wait(timeout=5)
    finally:
        for stream in (proc.stdin, proc.stdout):
            if stream is not None:
                try:
                    stream.close()
                except Exception:
                    pass
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=2)

    if not bestmove_str or bestmove_str in ("(none)", "0000"):
        raise RuntimeError(f"Engine không trả về nước đi hợp lệ ở vị trí xuất phát: {bestmove_str!r}")

    board = chess.Board()
    try:
        move_obj = chess.Move.from_uci(bestmove_str)
    except ValueError as exc:
        raise RuntimeError(f"Cú pháp UCI move không hợp lệ ({bestmove_str!r}): {exc}") from exc
    if move_obj not in board.legal_moves:
        raise RuntimeError(f"Engine trả về nước đi bất hợp lệ ở startpos: {bestmove_str}")

    # Xác nhận thêm thuộc tính EvalFile trong UCI options nếu thông báo NNUE chỉ in lần đầu
    if not nnue_loaded and "EvalFile" in options and options["EvalFile"].get("default", "").endswith(".nnue"):
        nnue_loaded = True

    if not nnue_loaded:
        raise RuntimeError(f"Không xác nhận được trạng thái nạp NNUE cho engine: {binary_path}")

    pro_opts = {k: options[k] for k in PRO_SPECIFIC_OPTION_NAMES if k in options}

    return {
        "binary_path": os.path.abspath(binary_path),
        "binary_sha256": sha256_file(binary_path),
        "binary_size_bytes": os.path.getsize(binary_path),
        "id_name": id_name,
        "id_author": id_author,
        "uciok": uciok_received,
        "readyok": readyok_received,
        "nnue_loaded": nnue_loaded,
        "nnue_info": nnue_info_lines,
        "sample_legal_bestmove": bestmove_str,
        "uci_options": options,
        "pro_specific_options": pro_opts,
        "experience_supported": bool(pro_opts and "Experience Enabled" in pro_opts),
        "experience_info_lines": exp_info_lines,
    }


def generate_build_manifest(
    pro_bin: str,
    uni_bin: str,
    manifest_path: str,
    results_dir: str,
    elf_inspection_path: Optional[str] = None,
    pro_source_origin: str = "Stockfish-19-Pro-Ultimate-V3/src",
    uni_source_origin: str = "stockfish-android-arm64-universal/stockfish/src",
    pro_archive_sha256: str = "",
    uni_archive_sha256: str = "",
    target_arch: str = "",
    dotprod_status: str = "false",
    compiler_info: str = "",
    nnue_sha256: str = "1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2",
) -> Dict[str, Any]:
    """Kiểm định cả hai engine sau build và tạo build-manifest.json."""
    pro_probe = probe_engine_uci_and_move(pro_bin)
    uni_probe = probe_engine_uci_and_move(uni_bin)

    if pro_probe["binary_sha256"] == uni_probe["binary_sha256"]:
        raise RuntimeError(
            "LỖI NGHIÊM TRỌNG: Hai binary sau khi build có cùng SHA256! "
            "Hệ thống từ chối chạy hai bản giống hệt nhau."
        )

    if not pro_probe["experience_supported"]:
        raise RuntimeError(
            "LỖI NGHIÊM TRỌNG: Binary Engine A (Pro) không có các UCI option Experience đặc thù!"
        )
    if uni_probe["experience_supported"]:
        raise RuntimeError(
            "LỖI NGHIÊM TRỌNG: Binary Engine B (Universal) lại chứa UCI option Experience của bản Pro!"
        )

    elf_inspection: Dict[str, Any] = {}
    if elf_inspection_path and os.path.isfile(elf_inspection_path):
        with open(elf_inspection_path, "r", encoding="utf-8") as f:
            elf_inspection = json.load(f)

    exp_bin_path = os.path.join(results_dir, "experience.bin")
    exp_metadata = {
        "supported": True,
        "enabled_default": pro_probe["pro_specific_options"].get("Experience Enabled", {}).get("default", "true"),
        "book_default": pro_probe["pro_specific_options"].get("Experience Book", {}).get("default", "true"),
        "learning_rate_default": pro_probe["pro_specific_options"].get("Experience Learning Rate", {}).get("default", "100"),
        "adaptive_opponent_default": pro_probe["pro_specific_options"].get("Adaptive Opponent Mode", {}).get("default", "true"),
        "experience_file_present": os.path.isfile(exp_bin_path),
        "experience_file_size_bytes": os.path.getsize(exp_bin_path) if os.path.isfile(exp_bin_path) else 0,
        "experience_file_sha256": sha256_file(exp_bin_path) if os.path.isfile(exp_bin_path) else None,
        "engine_expinfo_output": pro_probe["experience_info_lines"],
    }

    manifest = {
        "project": "STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS EDITION",
        "build_timestamp_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "host_environment": {
            "os": platform.system(),
            "kernel_release": platform.release(),
            "uname_machine": platform.machine(),
            "target_arch": target_arch or platform.machine(),
            "dotprod_enabled": str(dotprod_status).lower() == "true",
            "compiler": compiler_info or "g++ (GCC)",
        },
        "nnue": {
            "filename": "nn-1a298aa575a0.nnue",
            "sha256": nnue_sha256,
            "shared_by_both_engines": True,
        },
        "engines": {
            "engine_a_pro": {
                "display_name": ENGINE_PRO_NAME,
                "uci_id_name": pro_probe["id_name"],
                "uci_id_author": pro_probe["id_author"],
                "source_used": pro_source_origin,
                "input_archive_sha256": pro_archive_sha256,
                "source_tree_sha256": elf_inspection.get("pro_tree_sha256"),
                "binary_path": pro_probe["binary_path"],
                "binary_sha256": pro_probe["binary_sha256"],
                "binary_size_bytes": pro_probe["binary_size_bytes"],
                "compiler": compiler_info,
                "architecture": target_arch or platform.machine(),
                "dotprod_status": str(dotprod_status).lower() == "true",
                "nnue_sha256": nnue_sha256,
                "uci_handshake_verified": pro_probe["uciok"] and pro_probe["readyok"],
                "nnue_load_verified": pro_probe["nnue_loaded"],
                "sample_legal_move": pro_probe["sample_legal_bestmove"],
                "pro_specific_options": pro_probe["pro_specific_options"],
                "experience_status": exp_metadata,
                "uci_options": pro_probe["uci_options"],
            },
            "engine_b_universal": {
                "display_name": ENGINE_UNI_NAME,
                "uci_id_name": uni_probe["id_name"],
                "uci_id_author": uni_probe["id_author"],
                "source_used": uni_source_origin,
                "input_archive_sha256": uni_archive_sha256,
                "source_tree_sha256": elf_inspection.get("uni_tree_sha256"),
                "baseline_provenance_verified": elf_inspection.get("baseline_provenance_verified", True),
                "binary_path": uni_probe["binary_path"],
                "binary_sha256": uni_probe["binary_sha256"],
                "binary_size_bytes": uni_probe["binary_size_bytes"],
                "compiler": compiler_info,
                "architecture": target_arch or platform.machine(),
                "dotprod_status": str(dotprod_status).lower() == "true",
                "nnue_sha256": nnue_sha256,
                "uci_handshake_verified": uni_probe["uciok"] and uni_probe["readyok"],
                "nnue_load_verified": uni_probe["nnue_loaded"],
                "sample_legal_move": uni_probe["sample_legal_bestmove"],
                "uci_options": uni_probe["uci_options"],
            },
        },
        "source_provenance_and_elf_audit": elf_inspection,
    }

    atomic_write_json(manifest_path, manifest)
    print(f"[MANIFEST] Đã tạo và lưu {manifest_path} thành công.")
    print(f"  - {ENGINE_PRO_NAME}: SHA256={pro_probe['binary_sha256'][:16]}... | BestMove={pro_probe['sample_legal_bestmove']}")
    print(f"  - {ENGINE_UNI_NAME}: SHA256={uni_probe['binary_sha256'][:16]}... | BestMove={uni_probe['sample_legal_bestmove']}")
    return manifest


def get_opening_for_game(game_id: int, seed: int, openings: Optional[List[Tuple[str, List[str]]]] = None) -> Tuple[str, List[str], bool]:
    """
    Xác định khai cuộc và màu quân cho trận thứ game_id (1-indexed):
      - Mỗi khai cuộc dùng cho 2 trận liên tiếp:
          + Trận lẻ (2k + 1): Pro cầm Trắng, Universal cầm Đen.
          + Trận chẵn (2k + 2): Universal cầm Trắng, Pro cầm Đen.
      - Danh sách khai cuộc được xáo trộn tất định theo (seed, cycle).
    """
    if game_id < 1:
        raise ValueError(f"game_id phải >= 1 (nhận được {game_id})")
    suite = list(openings) if openings is not None else list(STANDARD_OPENINGS)
    pair_index = (game_id - 1) // 2
    cycle = pair_index // len(suite)
    idx_in_cycle = pair_index % len(suite)

    rng = random.Random(f"{seed}:cycle:{cycle}")
    shuffled = list(suite)
    rng.shuffle(shuffled)

    opening_name, opening_moves = shuffled[idx_in_cycle]
    pro_is_white = (game_id % 2 == 1)
    return opening_name, list(opening_moves), pro_is_white


def evaluate_board_termination(board: chess.Board, max_ply: int = 400) -> Optional[Tuple[str, str, bool]]:
    """
    Kiểm tra trạng thái kết thúc ván cờ theo đúng luật cờ vua thực tế:
      Trả về (result_str, termination_reason, is_technical_stop) hoặc None nếu ván chưa kết thúc.
      Thứ tự ưu tiên:
        1. Checkmate
        2. Stalemate
        3. Insufficient material
        4. Fivefold repetition
        5. 75-move rule
        6. Threefold repetition (bao gồm can_claim_threefold_repetition)
        7. 50-move rule (bao gồm can_claim_fifty_moves)
        8. Giới hạn số ply an toàn (Technical stop — KHÔNG tính là hòa theo luật cờ vua)
    """
    if board.is_checkmate():
        # Bên đến lượt đi bị chiếu hết -> đối phương thắng
        res = "0-1" if board.turn == chess.WHITE else "1-0"
        return (res, "Checkmate", False)

    if board.is_stalemate():
        return ("1/2-1/2", "Stalemate", False)

    if board.is_insufficient_material():
        return ("1/2-1/2", "Insufficient material", False)

    if board.is_fivefold_repetition():
        return ("1/2-1/2", "Fivefold repetition", False)

    if board.is_seventyfive_moves():
        return ("1/2-1/2", "75-move rule", False)

    if board.is_repetition(3) or board.can_claim_threefold_repetition():
        return ("1/2-1/2", "Threefold repetition", False)

    if board.is_fifty_moves() or board.can_claim_fifty_moves():
        return ("1/2-1/2", "50-move rule", False)

    if len(board.move_stack) >= max_ply:
        return ("*", f"Technical stop (Max ply {max_ply} reached)", True)

    return None


@dataclass
class MatchRecord:
    Game_ID: int
    Date: str
    White: str
    Black: str
    Result: str
    Winner: str
    Termination: str
    Opening: str
    Ply_Count: int
    Duration: str
    Duration_Seconds: float
    Move_Time_Ms: int
    Hash_MB: int
    Error: str
    Is_Technical_Stop: bool
    Is_Forfeiture: bool
    Moves_UCI: List[str]
    Moves_SAN: List[str]


def format_match_console_log(rec: MatchRecord) -> str:
    """
    Định dạng log tiếng Việt cho từng trận đúng chuẩn Mục 7:
      Trận 000001: HÒA
      Pro (Trắng) vs Universal (Đen)
      Kết quả: 1/2-1/2
      Số nước: 84 ply
      Thời gian: 00:00:21
      Lý do: Threefold repetition
    """
    if rec.Result == "1/2-1/2":
        headline = f"Trận {rec.Game_ID:06d}: HÒA"
    elif rec.Result == "*":
        headline = f"Trận {rec.Game_ID:06d}: DỪNG KỸ THUẬT"
    elif rec.Winner == ENGINE_PRO_NAME:
        headline = f"Trận {rec.Game_ID:06d}: STOCKFISH 19 PRO ULTIMATE V3 THẮNG"
    elif rec.Winner == ENGINE_UNI_NAME:
        headline = f"Trận {rec.Game_ID:06d}: STOCKFISH ANDROID ARM64 UNIVERSAL THẮNG"
    else:
        headline = f"Trận {rec.Game_ID:06d}: KẾT THÚC ({rec.Result})"

    white_short = ENGINE_PRO_SHORT if rec.White == ENGINE_PRO_NAME else ENGINE_UNI_SHORT
    black_short = ENGINE_PRO_SHORT if rec.Black == ENGINE_PRO_NAME else ENGINE_UNI_SHORT

    lines = [
        headline,
        f"{white_short} (Trắng) vs {black_short} (Đen)",
        f"Kết quả: {rec.Result}",
        f"Số nước: {rec.Ply_Count} ply",
        f"Thời gian: {rec.Duration}",
        f"Lý do: {rec.Termination}",
    ]
    if rec.Error:
        lines.append(f"Ghi chú lỗi kỹ thuật: {rec.Error}")
    return "\n".join(lines) + "\n"


def format_heartbeat_line(
    elapsed_sec: float,
    target_sec: float,
    total_games: int,
    pro_wins: int,
    uni_wins: int,
    draws: int,
) -> str:
    decisive = pro_wins + uni_wins
    return (
        f"[TIME] {format_hms(elapsed_sec)} / {format_hms(target_sec)} "
        f"[TOTAL GAMES] {total_games} "
        f"[PRO WINS] {pro_wins} "
        f"[UNIVERSAL WINS] {uni_wins} "
        f"[DRAWS] {draws} "
        f"[DECISIVE GAMES] {decisive}"
    )


def build_pgn_string(rec: MatchRecord) -> str:
    """Tạo chuỗi PGN chuẩn quốc tế cho một ván đấu, mở được bằng mọi phần mềm cờ vua."""
    game = chess.pgn.Game()
    game.headers["Event"] = "Stockfish Ultimate Duel"
    game.headers["Site"] = "GitHub Actions"
    game.headers["Date"] = rec.Date.replace("-", ".")
    game.headers["Round"] = str(rec.Game_ID)
    game.headers["White"] = rec.White
    game.headers["Black"] = rec.Black
    game.headers["Result"] = rec.Result
    game.headers["Opening"] = rec.Opening
    game.headers["Termination"] = rec.Termination
    game.headers["PlyCount"] = str(rec.Ply_Count)
    game.headers["TimeControl"] = f"{rec.Move_Time_Ms / 1000.0:g}/move"
    game.headers["Duration"] = rec.Duration
    if rec.Error:
        game.headers["Annotator"] = f"Arbiter Note: {rec.Error}"

    node = game
    board = chess.Board()
    for uci_mv in rec.Moves_UCI:
        mv = chess.Move.from_uci(uci_mv)
        if mv not in board.legal_moves:
            break
        node = node.add_variation(mv)
        board.push(mv)

    exporter = chess.pgn.StringExporter(headers=True, variations=False, comments=False)
    return game.accept(exporter).strip() + "\n\n"


def parse_pgn_and_verify_stats(pgn_path: str) -> Dict[str, Any]:
    """
    Đọc trực tiếp tệp matches.pgn bằng chess.pgn.read_game để xác thực độc lập
    số trận và thống kê W/D/L từ PGN thực tế.
    """
    total_pgn_games = 0
    pro_wins = 0
    uni_wins = 0
    draws = 0
    technical_stops = 0
    pro_white_games = 0
    pro_black_games = 0
    pro_white_wins = 0
    pro_white_draws = 0
    pro_white_losses = 0
    pro_black_wins = 0
    pro_black_draws = 0
    pro_black_losses = 0

    if not os.path.isfile(pgn_path):
        return {
            "total_games": 0,
            "pro_wins": 0,
            "uni_wins": 0,
            "draws": 0,
            "technical_stops": 0,
            "pro_white_games": 0,
            "pro_black_games": 0,
            "pro_white_wdl": [0, 0, 0],
            "pro_black_wdl": [0, 0, 0],
        }

    with open(pgn_path, "r", encoding="utf-8") as f:
        while True:
            game = chess.pgn.read_game(f)
            if game is None:
                break
            total_pgn_games += 1
            white = game.headers.get("White", "")
            black = game.headers.get("Black", "")
            res = game.headers.get("Result", "*")

            pro_is_white = (white == ENGINE_PRO_NAME)
            if pro_is_white:
                pro_white_games += 1
            elif black == ENGINE_PRO_NAME:
                pro_black_games += 1

            if res == "1/2-1/2":
                draws += 1
                if pro_is_white:
                    pro_white_draws += 1
                else:
                    pro_black_draws += 1
            elif res == "1-0":
                if pro_is_white:
                    pro_wins += 1
                    pro_white_wins += 1
                else:
                    uni_wins += 1
                    pro_black_losses += 1
            elif res == "0-1":
                if not pro_is_white:
                    pro_wins += 1
                    pro_black_wins += 1
                else:
                    uni_wins += 1
                    pro_white_losses += 1
            else:
                technical_stops += 1

    return {
        "total_games": total_pgn_games,
        "pro_wins": pro_wins,
        "uni_wins": uni_wins,
        "draws": draws,
        "technical_stops": technical_stops,
        "pro_white_games": pro_white_games,
        "pro_black_games": pro_black_games,
        "pro_white_wdl": [pro_white_wins, pro_white_draws, pro_white_losses],
        "pro_black_wdl": [pro_black_wins, pro_black_draws, pro_black_losses],
    }


def compute_elo_and_statistics(
    pro_wins: int,
    uni_wins: int,
    draws: int,
    technical_stops: int = 0,
    forfeits_pro: int = 0,
    forfeits_uni: int = 0,
    pro_white_wdl: Optional[List[int]] = None,
    pro_black_wdl: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """
    Tính toán đầy đủ thống kê W/D/L, tỷ lệ điểm, chênh lệch Elo và khoảng tin cậy 95% (95% CI):
      - Pro Score = (Pro Wins + 0.5 * Draws) / Total Scored Games
      - Universal Score = 1 - Pro Score
      - Elo Difference = 400 * log10(Score / (1 - Score))
    """
    scored_games = pro_wins + uni_wins + draws
    total_games = scored_games + technical_stops
    decisive_games = pro_wins + uni_wins

    if scored_games > 0:
        pro_score = (pro_wins + 0.5 * draws) / scored_games
        uni_score = 1.0 - pro_score
    else:
        pro_score = 0.5
        uni_score = 0.5

    def score_to_elo(s: float) -> float:
        s_clamped = min(max(s, 1e-4), 1.0 - 1e-4)
        return 400.0 * math.log10(s_clamped / (1.0 - s_clamped))

    if scored_games == 0:
        elo_diff = 0.0
        elo_ci_low = 0.0
        elo_ci_high = 0.0
        elo_margin_95 = 0.0
        score_se = 0.0
    else:
        elo_diff = score_to_elo(pro_score)
        if scored_games >= 2:
            var_num = (
                pro_wins * ((1.0 - pro_score) ** 2)
                + draws * ((0.5 - pro_score) ** 2)
                + uni_wins * ((0.0 - pro_score) ** 2)
            )
            sample_var = var_num / (scored_games - 1)
            score_se = math.sqrt(max(0.0, sample_var / scored_games))
            s_low = max(1e-4, pro_score - 1.95996 * score_se)
            s_high = min(1.0 - 1e-4, pro_score + 1.95996 * score_se)
            elo_ci_low = score_to_elo(s_low)
            elo_ci_high = score_to_elo(s_high)
            elo_margin_95 = (elo_ci_high - elo_ci_low) / 2.0
        else:
            score_se = 0.0
            elo_ci_low = elo_diff
            elo_ci_high = elo_diff
            elo_margin_95 = 0.0

    small_sample = scored_games < 100
    statistically_significant = (
        scored_games >= 30 and ((elo_ci_low > 0.0 and elo_ci_high > 0.0) or (elo_ci_low < 0.0 and elo_ci_high < 0.0))
    )

    if scored_games == 0:
        conclusion = "Chưa có ván đấu hoàn thành để đưa ra kết luận thống kê."
    elif small_sample:
        conclusion = (
            f"CẢNH BÁO MẪU NHỎ ({scored_games} ván): Cỡ mẫu hiện tại còn nhỏ (dưới 100 ván), "
            f"biên độ sai số 95% CI là ±{elo_margin_95:.1f} Elo ([{elo_ci_low:+.1f}, {elo_ci_high:+.1f}] Elo). "
            f"Chưa đủ cơ sở thống kê để khẳng định chắc chắn một engine mạnh hơn đối thủ."
        )
    elif not statistically_significant:
        conclusion = (
            f"Qua {format_vn_int(scored_games)} ván đấu, chênh lệch Elo ước tính là {elo_diff:+.2f} Elo "
            f"(khoảng tin cậy 95%: [{elo_ci_low:+.2f}, {elo_ci_high:+.2f}] Elo). "
            f"Do khoảng tin cậy 95% vẫn bao hàm mốc 0 Elo, sự chênh lệch hiện tại chưa đạt ngưỡng "
            f"ý nghĩa thống kê ở mức tin cậy 95%."
        )
    else:
        leader = ENGINE_PRO_NAME if elo_diff > 0 else ENGINE_UNI_NAME
        conclusion = (
            f"Qua {format_vn_int(scored_games)} ván đấu, {leader} đạt ưu thế có ý nghĩa thống kê ở mức tin cậy 95% "
            f"với chênh lệch Elo ước tính {elo_diff:+.2f} ± {elo_margin_95:.2f} Elo "
            f"(95% CI: [{elo_ci_low:+.2f}, {elo_ci_high:+.2f}] Elo)."
        )

    pw = pro_white_wdl or [0, 0, 0]
    pb = pro_black_wdl or [0, 0, 0]

    return {
        "total_games": total_games,
        "scored_games": scored_games,
        "technical_stops": technical_stops,
        "decisive_games": decisive_games,
        "pro": {
            "name": ENGINE_PRO_NAME,
            "wins": pro_wins,
            "draws": draws,
            "losses": uni_wins,
            "score_points": pro_wins + 0.5 * draws,
            "score_ratio": round(pro_score, 6),
            "score_percent": round(pro_score * 100.0, 2),
            "white_games": sum(pw),
            "white_wins": pw[0],
            "white_draws": pw[1],
            "white_losses": pw[2],
            "black_games": sum(pb),
            "black_wins": pb[0],
            "black_draws": pb[1],
            "black_losses": pb[2],
            "forfeits_suffered": forfeits_pro,
        },
        "universal": {
            "name": ENGINE_UNI_NAME,
            "wins": uni_wins,
            "draws": draws,
            "losses": pro_wins,
            "score_points": uni_wins + 0.5 * draws,
            "score_ratio": round(uni_score, 6),
            "score_percent": round(uni_score * 100.0, 2),
            "white_games": sum(pb),
            "white_wins": pb[2],
            "white_draws": pb[1],
            "white_losses": pb[0],
            "black_games": sum(pw),
            "black_wins": pw[2],
            "black_draws": pw[1],
            "black_losses": pw[0],
            "forfeits_suffered": forfeits_uni,
        },
        "elo": {
            "pro_minus_universal_elo": round(elo_diff, 2),
            "ci_95_low": round(elo_ci_low, 2),
            "ci_95_high": round(elo_ci_high, 2),
            "margin_95": round(elo_margin_95, 2),
            "standard_error_score": round(score_se, 6),
            "small_sample_warning": small_sample,
            "statistically_significant_95": statistically_significant,
        },
        "conclusion": conclusion,
    }


def generate_summary_markdown(
    stats: Dict[str, Any],
    config: Dict[str, Any],
    elapsed_sec: float,
    target_sec: float,
) -> str:
    """Tạo báo cáo tổng kết tiếng Việt chuẩn Mục 9 (summary.md)."""
    pro = stats["pro"]
    uni = stats["universal"]
    elo = stats["elo"]

    lines = [
        "================================",
        "# STOCKFISH ULTIMATE DUEL REPORT",
        "================================",
        "",
        f"Tổng số trận: {format_vn_int(stats['total_games'])}",
        "",
        f"**{ENGINE_PRO_NAME.upper()}**:",
        f"- Thắng: {format_vn_int(pro['wins'])}",
        f"- Hòa: {format_vn_int(pro['draws'])}",
        f"- Thua: {format_vn_int(pro['losses'])}",
        "",
        f"**{ENGINE_UNI_NAME.upper()}**:",
        f"- Thắng: {format_vn_int(uni['wins'])}",
        f"- Hòa: {format_vn_int(uni['draws'])}",
        f"- Thua: {format_vn_int(uni['losses'])}",
        "",
        f"Tỷ lệ điểm Pro: {pro['score_percent']:.1f}% ({pro['score_points']:.1f} / {stats['scored_games']})",
        f"Tỷ lệ điểm Universal: {uni['score_percent']:.1f}% ({uni['score_points']:.1f} / {stats['scored_games']})",
        "",
        f"Số trận phân thắng bại: {format_vn_int(stats['decisive_games'])}",
        f"Số trận dừng kỹ thuật (Max ply): {format_vn_int(stats['technical_stops'])}",
        f"Số trận xử thua kỹ thuật (Forfeiture): Pro={pro['forfeits_suffered']}, Universal={uni['forfeits_suffered']}",
        "",
        f"Số trận Pro cầm Trắng: {format_vn_int(pro['white_games'])} (Thắng: {pro['white_wins']}, Hòa: {pro['white_draws']}, Thua: {pro['white_losses']})",
        f"Số trận Pro cầm Đen: {format_vn_int(pro['black_games'])} (Thắng: {pro['black_wins']}, Hòa: {pro['black_draws']}, Thua: {pro['black_losses']})",
        "",
        "## Phân Tích Elo & Khoảng Tin Cậy 95%",
        f"- Chênh lệch Elo (Pro so với Universal): **{elo['pro_minus_universal_elo']:+.2f} Elo**",
        f"- Khoảng tin cậy 95% (95% CI): **[{elo['ci_95_low']:+.2f}, {elo['ci_95_high']:+.2f}] Elo** (±{elo['margin_95']:.2f} Elo)",
        f"- Cảnh báo cỡ mẫu nhỏ (< 100 trận): **{'CÓ' if elo['small_sample_warning'] else 'KHÔNG'}**",
        "",
        "## Cấu Hình & Thời Lượng Thực Thi",
        f"- Thời gian đấu thực tế cộng dồn: `{format_hms(elapsed_sec)}` / `{format_hms(target_sec)}`",
        f"- Move Time: `{config.get('move_time_ms', 200)} ms/nước` | Hash: `{config.get('hash_mb', 256)} MB` | Threads: `{config.get('threads', 1)}`",
        f"- Random Seed khai cuộc: `{config.get('random_seed', 20261109)}`",
        "",
        f"**Kết luận**: {stats['conclusion']}",
        "",
    ]
    return "\n".join(lines)


class ManagedUCIEngine:
    """Quản lý tiến trình UCI Engine qua python-chess với cơ chế tự động khởi động lại khi gặp sự cố."""

    def __init__(
        self,
        display_name: str,
        binary_path: str,
        threads: int,
        hash_mb: int,
        is_pro: bool = False,
        experience_file: Optional[str] = None,
    ) -> None:
        self.display_name = display_name
        self.binary_path = os.path.abspath(binary_path)
        self.threads = threads
        self.hash_mb = hash_mb
        self.is_pro = is_pro
        self.experience_file = os.path.abspath(experience_file) if experience_file else None
        self.engine: Optional[chess.engine.SimpleEngine] = None
        self.advertised_options: Dict[str, Any] = {}

    def start(self) -> None:
        self.stop()
        cwd = os.path.dirname(self.binary_path)
        cmd = [sys.executable, self.binary_path] if self.binary_path.endswith(".py") else self.binary_path
        self.engine = chess.engine.SimpleEngine.popen_uci(
            cmd,
            cwd=cwd,
            timeout=15.0,
        )
        self.advertised_options = dict(self.engine.options)

        config_opts: Dict[str, Any] = {}
        if "Threads" in self.advertised_options:
            config_opts["Threads"] = self.threads
        if "Hash" in self.advertised_options:
            config_opts["Hash"] = self.hash_mb
        if "Ponder" in self.advertised_options and not self.advertised_options["Ponder"].is_managed():
            config_opts["Ponder"] = False
        if "UCI_Chess960" in self.advertised_options and not self.advertised_options["UCI_Chess960"].is_managed():
            config_opts["UCI_Chess960"] = False

        # Với Engine Pro, giữ nguyên các giá trị mặc định của tính năng Pro và trỏ Experience File về file lưu trữ bền vững
        if self.is_pro and self.experience_file and "Experience File" in self.advertised_options:
            config_opts["Experience File"] = self.experience_file

        if config_opts:
            self.engine.configure(config_opts)
        self.engine.ping()

    def ensure_alive(self) -> None:
        if self.engine is None:
            self.start()
            return
        try:
            self.engine.ping()
        except Exception:
            self.start()

    def play_move(self, board: chess.Board, move_time_ms: int, new_game: bool = False) -> chess.Move:
        self.ensure_alive()
        assert self.engine is not None
        limit = chess.engine.Limit(time=move_time_ms / 1000.0)
        # Đặt timeout an toàn: tối đa max(10s, 10 * move_time)
        timeout_sec = max(10.0, (move_time_ms / 1000.0) * 15.0)
        res = self.engine.play(board, limit, game=(object() if new_game else None))
        if res.move is None:
            raise RuntimeError(f"{self.display_name} không trả về nước đi (move is None).")
        return res.move

    def stop(self) -> None:
        if self.engine is not None:
            try:
                self.engine.quit()
            except Exception:
                try:
                    self.engine.close()
                except Exception:
                    pass
            self.engine = None


class TournamentRunner:
    """Điều phối giải đấu thực tế, ghi log trực tiếp, lưu checkpoint nguyên tử và hỗ trợ resume đa chặng."""

    CSV_COLUMNS = [
        "Game_ID",
        "Date",
        "White",
        "Black",
        "Result",
        "Winner",
        "Termination",
        "Opening",
        "Ply_Count",
        "Duration",
        "Error",
    ]

    def __init__(
        self,
        pro_bin: str,
        uni_bin: str,
        results_dir: str,
        total_duration_seconds: float,
        stage_max_seconds: Optional[float] = None,
        move_time_ms: int = 200,
        hash_mb: int = 256,
        threads: int = 1,
        random_seed: int = 20261109,
        max_ply: int = 400,
        heartbeat_interval_sec: float = 300.0,
        stage_number: int = 1,
        resume: bool = False,
        max_games: Optional[int] = None,
    ) -> None:
        self.pro_bin = os.path.abspath(pro_bin)
        self.uni_bin = os.path.abspath(uni_bin)
        self.results_dir = os.path.abspath(results_dir)
        os.makedirs(self.results_dir, exist_ok=True)

        self.total_duration_seconds = float(total_duration_seconds)
        self.stage_max_seconds = float(stage_max_seconds) if stage_max_seconds is not None else float(total_duration_seconds)
        self.move_time_ms = int(move_time_ms)
        self.hash_mb = int(hash_mb)
        self.threads = int(threads)
        self.random_seed = int(random_seed)
        self.max_ply = int(max_ply)
        self.heartbeat_interval_sec = float(heartbeat_interval_sec)
        self.stage_number = int(stage_number)
        self.resume = bool(resume)
        self.max_games = max_games

        self.log_path = os.path.join(self.results_dir, "matches.log")
        self.pgn_path = os.path.join(self.results_dir, "matches.pgn")
        self.csv_path = os.path.join(self.results_dir, "matches.csv")
        self.jsonl_path = os.path.join(self.results_dir, "matches.jsonl")
        self.summary_json_path = os.path.join(self.results_dir, "summary.json")
        self.summary_md_path = os.path.join(self.results_dir, "summary.md")
        self.checkpoint_path = os.path.join(self.results_dir, "checkpoint.json")
        self.manifest_path = os.path.join(self.results_dir, "build-manifest.json")
        self.experience_path = os.path.join(self.results_dir, "experience.bin")

        self.records: List[MatchRecord] = []
        self.prior_elapsed_seconds: float = 0.0
        self.stop_requested: bool = False

        self._install_signal_handlers()

    def _install_signal_handlers(self) -> None:
        def _handler(signum: int, _frame: Any) -> None:
            print(f"\n[SIGNAL] Nhận tín hiệu {signum}, sẽ lưu checkpoint và dừng sau khi hoàn tất ván hiện tại...", flush=True)
            self.stop_requested = True

        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, _handler)
            except Exception:
                pass

    def load_or_initialize_state(self) -> None:
        """Khôi phục trạng thái từ checkpoint (khi resume) hoặc khởi tạo mới."""
        if self.resume and os.path.isfile(self.checkpoint_path):
            with open(self.checkpoint_path, "r", encoding="utf-8") as f:
                ckpt = json.load(f)
            self.prior_elapsed_seconds = float(ckpt.get("cumulative_play_seconds", 0.0))
            self.random_seed = int(ckpt.get("random_seed", self.random_seed))
            expected_last_id = int(ckpt.get("last_game_id", 0))

            loaded_by_id: Dict[int, MatchRecord] = {}
            if os.path.isfile(self.jsonl_path):
                with open(self.jsonl_path, "r", encoding="utf-8") as jf:
                    for line in jf:
                        s = line.strip()
                        if not s:
                            continue
                        try:
                            obj = json.loads(s)
                            gid = int(obj["Game_ID"])
                            if 1 <= gid <= expected_last_id or expected_last_id == 0:
                                loaded_by_id[gid] = MatchRecord(**obj)
                        except Exception:
                            continue

            self.records = [loaded_by_id[k] for k in sorted(loaded_by_id.keys())]
            # Đồng bộ hóa lại các tệp PGN, CSV, JSONL từ tập bản ghi chuẩn đã xác thực để loại bỏ bản ghi dở dang
            self._rewrite_all_data_files_atomically()
            print(
                f"[RESUME] Khôi phục thành công từ checkpoint (Chặng {self.stage_number}): "
                f"Đã có {len(self.records)} ván hoàn thành, thời gian đã đấu: {format_hms(self.prior_elapsed_seconds)}.",
                flush=True,
            )
        else:
            self.records = []
            self.prior_elapsed_seconds = 0.0
            if not os.path.isfile(self.log_path):
                atomic_write_text(self.log_path, "")
            self._rewrite_all_data_files_atomically()
            self._save_checkpoint_and_summaries(current_stage_elapsed=0.0)

    def _rewrite_all_data_files_atomically(self) -> None:
        """Đồng bộ hóa matches.jsonl, matches.csv, matches.pgn nguyên tử từ self.records."""
        jsonl_lines = [json.dumps(asdict(r), ensure_ascii=False) for r in self.records]
        atomic_write_text(self.jsonl_path, ("\n".join(jsonl_lines) + "\n") if jsonl_lines else "")

        csv_buf = io.StringIO()
        writer = csv.DictWriter(csv_buf, fieldnames=self.CSV_COLUMNS, lineterminator="\n")
        writer.writeheader()
        for r in self.records:
            writer.writerow({col: getattr(r, col) for col in self.CSV_COLUMNS})
        atomic_write_text(self.csv_path, csv_buf.getvalue())

        pgn_chunks = [build_pgn_string(r) for r in self.records]
        atomic_write_text(self.pgn_path, "".join(pgn_chunks))

    def _append_match_to_files_atomically(self, rec: MatchRecord, log_block: str) -> None:
        """Lưu kết quả ván mới vào tất cả các file bằng cơ chế file tạm + atomic rename."""
        # 1. Cập nhật matches.log
        existing_log = ""
        if os.path.isfile(self.log_path):
            with open(self.log_path, "r", encoding="utf-8") as f:
                existing_log = f.read()
        atomic_write_text(self.log_path, existing_log + log_block + "\n")

        # 2. Cập nhật matches.jsonl, matches.csv, matches.pgn
        self._rewrite_all_data_files_atomically()

    def _append_heartbeat_to_log(self, hb_line: str) -> None:
        existing_log = ""
        if os.path.isfile(self.log_path):
            with open(self.log_path, "r", encoding="utf-8") as f:
                existing_log = f.read()
        atomic_write_text(self.log_path, existing_log + hb_line + "\n\n")

    def _save_checkpoint_and_summaries(self, current_stage_elapsed: float) -> Dict[str, Any]:
        total_elapsed = self.prior_elapsed_seconds + current_stage_elapsed

        pgn_stats = parse_pgn_and_verify_stats(self.pgn_path)
        forfeits_pro = sum(
            1 for r in self.records if r.Is_Forfeiture and r.Winner == ENGINE_UNI_NAME
        )
        forfeits_uni = sum(
            1 for r in self.records if r.Is_Forfeiture and r.Winner == ENGINE_PRO_NAME
        )

        stats = compute_elo_and_statistics(
            pro_wins=pgn_stats["pro_wins"],
            uni_wins=pgn_stats["uni_wins"],
            draws=pgn_stats["draws"],
            technical_stops=pgn_stats["technical_stops"],
            forfeits_pro=forfeits_pro,
            forfeits_uni=forfeits_uni,
            pro_white_wdl=pgn_stats["pro_white_wdl"],
            pro_black_wdl=pgn_stats["pro_black_wdl"],
        )

        config_meta = {
            "move_time_ms": self.move_time_ms,
            "hash_mb": self.hash_mb,
            "threads": self.threads,
            "random_seed": self.random_seed,
            "max_ply": self.max_ply,
            "total_duration_seconds": self.total_duration_seconds,
            "stage_number": self.stage_number,
            "experience_file_exists": os.path.isfile(self.experience_path),
            "experience_file_size_bytes": os.path.getsize(self.experience_path) if os.path.isfile(self.experience_path) else 0,
        }

        last_game_id = self.records[-1].Game_ID if self.records else 0
        checkpoint_data = {
            "last_game_id": last_game_id,
            "total_games_completed": len(self.records),
            "cumulative_play_seconds": round(total_elapsed, 3),
            "total_target_seconds": round(self.total_duration_seconds, 3),
            "remaining_seconds": round(max(0.0, self.total_duration_seconds - total_elapsed), 3),
            "random_seed": self.random_seed,
            "move_time_ms": self.move_time_ms,
            "hash_mb": self.hash_mb,
            "threads": self.threads,
            "stage_number": self.stage_number,
            "updated_at_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "stats_snapshot": stats,
        }
        atomic_write_json(self.checkpoint_path, checkpoint_data)

        summary_data = {
            "project": "STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS EDITION",
            "generated_at_utc": checkpoint_data["updated_at_utc"],
            "configuration": config_meta,
            "timing": {
                "cumulative_play_seconds": round(total_elapsed, 3),
                "cumulative_play_hms": format_hms(total_elapsed),
                "target_duration_seconds": round(self.total_duration_seconds, 3),
                "target_duration_hms": format_hms(self.total_duration_seconds),
            },
            "pgn_verified": True,
            "statistics": stats,
        }
        atomic_write_json(self.summary_json_path, summary_data)

        md_text = generate_summary_markdown(
            stats=stats,
            config=config_meta,
            elapsed_sec=total_elapsed,
            target_sec=self.total_duration_seconds,
        )
        atomic_write_text(self.summary_md_path, md_text)
        return summary_data

    def play_single_game(
        self,
        game_id: int,
        pro_engine: ManagedUCIEngine,
        uni_engine: ManagedUCIEngine,
    ) -> MatchRecord:
        opening_name, opening_uci_moves, pro_is_white = get_opening_for_game(game_id, self.random_seed)

        if pro_is_white:
            white_engine = pro_engine
            black_engine = uni_engine
            white_name = ENGINE_PRO_NAME
            black_name = ENGINE_UNI_NAME
        else:
            white_engine = uni_engine
            black_engine = pro_engine
            white_name = ENGINE_UNI_NAME
            black_name = ENGINE_PRO_NAME

        board = chess.Board()
        moves_uci: List[str] = []
        moves_san: List[str] = []

        for uci_str in opening_uci_moves:
            mv = chess.Move.from_uci(uci_str)
            if mv not in board.legal_moves:
                raise RuntimeError(f"Khai cuộc {opening_name} chứa nước đi không hợp lệ: {uci_str}")
            moves_san.append(board.san(mv))
            moves_uci.append(uci_str)
            board.push(mv)

        start_t = time.monotonic()
        date_str = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")

        result_str = "*"
        winner_name = "None"
        termination_reason = ""
        error_note = ""
        is_tech_stop = False
        is_forfeit = False

        first_white_search = True
        first_black_search = True

        while True:
            term = evaluate_board_termination(board, self.max_ply)
            if term is not None:
                result_str, termination_reason, is_tech_stop = term
                if result_str == "1-0":
                    winner_name = white_name
                elif result_str == "0-1":
                    winner_name = black_name
                elif result_str == "1/2-1/2":
                    winner_name = "Draw"
                else:
                    winner_name = "None (Technical Stop)"
                break

            active_engine = white_engine if board.turn == chess.WHITE else black_engine
            active_name = white_name if board.turn == chess.WHITE else black_name
            opponent_name = black_name if board.turn == chess.WHITE else white_name
            is_new_game_flag = first_white_search if board.turn == chess.WHITE else first_black_search

            if board.turn == chess.WHITE:
                first_white_search = False
            else:
                first_black_search = False

            try:
                chosen_move = active_engine.play_move(
                    board,
                    move_time_ms=self.move_time_ms,
                    new_game=is_new_game_flag,
                )
            except chess.engine.EngineTerminatedError as exc:
                is_forfeit = True
                error_note = f"{active_name} crashed/terminated: {exc}"
                termination_reason = f"Forfeiture ({active_name} crash)"
                result_str = "0-1" if board.turn == chess.WHITE else "1-0"
                winner_name = opponent_name
                active_engine.stop()
                break
            except TimeoutError as exc:
                is_forfeit = True
                error_note = f"{active_name} timeout: {exc}"
                termination_reason = f"Forfeiture ({active_name} timeout)"
                result_str = "0-1" if board.turn == chess.WHITE else "1-0"
                winner_name = opponent_name
                active_engine.stop()
                break
            except Exception as exc:
                is_forfeit = True
                error_note = f"{active_name} error: {exc}"
                termination_reason = f"Forfeiture ({active_name} error)"
                result_str = "0-1" if board.turn == chess.WHITE else "1-0"
                winner_name = opponent_name
                active_engine.stop()
                break

            if chosen_move is None or chosen_move not in board.legal_moves:
                is_forfeit = True
                bad_uci = chosen_move.uci() if chosen_move is not None else "None"
                error_note = f"{active_name} returned illegal move: {bad_uci}"
                termination_reason = f"Forfeiture (Illegal move {bad_uci} by {active_name})"
                result_str = "0-1" if board.turn == chess.WHITE else "1-0"
                winner_name = opponent_name
                break

            moves_san.append(board.san(chosen_move))
            moves_uci.append(chosen_move.uci())
            board.push(chosen_move)

        duration_sec = max(0.001, time.monotonic() - start_t)
        return MatchRecord(
            Game_ID=game_id,
            Date=date_str,
            White=white_name,
            Black=black_name,
            Result=result_str,
            Winner=winner_name,
            Termination=termination_reason,
            Opening=opening_name,
            Ply_Count=len(board.move_stack),
            Duration=format_hms(duration_sec),
            Duration_Seconds=round(duration_sec, 3),
            Move_Time_Ms=self.move_time_ms,
            Hash_MB=self.hash_mb,
            Error=error_note,
            Is_Technical_Stop=is_tech_stop,
            Is_Forfeiture=is_forfeit,
            Moves_UCI=moves_uci,
            Moves_SAN=moves_san,
        )

    def run(self) -> Dict[str, Any]:
        self.load_or_initialize_state()

        remaining_total = max(0.0, self.total_duration_seconds - self.prior_elapsed_seconds)
        stage_budget = min(self.stage_max_seconds, remaining_total)

        print("================================================================================", flush=True)
        print(f" BẮT ĐẦU STOCKFISH ULTIMATE DUEL — CHẶNG {self.stage_number}", flush=True)
        print(f" - Engine A: {ENGINE_PRO_NAME}", flush=True)
        print(f" - Engine B: {ENGINE_UNI_NAME}", flush=True)
        print(f" - Thời lượng mục tiêu tổng: {format_hms(self.total_duration_seconds)} | Đã đấu: {format_hms(self.prior_elapsed_seconds)}", flush=True)
        print(f" - Thời lượng chặng này     : {format_hms(stage_budget)}", flush=True)
        print(f" - Cấu hình: Threads={self.threads}, Hash={self.hash_mb} MB, MoveTime={self.move_time_ms} ms", flush=True)
        print("================================================================================\n", flush=True)

        pro_engine = ManagedUCIEngine(
            display_name=ENGINE_PRO_NAME,
            binary_path=self.pro_bin,
            threads=self.threads,
            hash_mb=self.hash_mb,
            is_pro=True,
            experience_file=self.experience_path,
        )
        uni_engine = ManagedUCIEngine(
            display_name=ENGINE_UNI_NAME,
            binary_path=self.uni_bin,
            threads=self.threads,
            hash_mb=self.hash_mb,
            is_pro=False,
        )

        pro_engine.start()
        uni_engine.start()

        stage_start = time.monotonic()
        last_heartbeat = stage_start

        try:
            while not self.stop_requested:
                stage_elapsed = time.monotonic() - stage_start
                cumulative_elapsed = self.prior_elapsed_seconds + stage_elapsed

                if stage_elapsed >= stage_budget or cumulative_elapsed >= self.total_duration_seconds:
                    break

                if self.max_games is not None and len(self.records) >= self.max_games:
                    break

                next_game_id = (self.records[-1].Game_ID + 1) if self.records else 1
                rec = self.play_single_game(next_game_id, pro_engine, uni_engine)
                self.records.append(rec)

                log_block = format_match_console_log(rec)
                print(log_block, end="", flush=True)
                print(flush=True)

                stage_elapsed = time.monotonic() - stage_start
                self._append_match_to_files_atomically(rec, log_block)
                summary_snapshot = self._save_checkpoint_and_summaries(stage_elapsed)

                now_mono = time.monotonic()
                if (now_mono - last_heartbeat) >= self.heartbeat_interval_sec:
                    st = summary_snapshot["statistics"]
                    hb_line = format_heartbeat_line(
                        elapsed_sec=self.prior_elapsed_seconds + (now_mono - stage_start),
                        target_sec=self.total_duration_seconds,
                        total_games=st["total_games"],
                        pro_wins=st["pro"]["wins"],
                        uni_wins=st["universal"]["wins"],
                        draws=st["pro"]["draws"],
                    )
                    print(hb_line + "\n", flush=True)
                    self._append_heartbeat_to_log(hb_line)
                    last_heartbeat = now_mono
        finally:
            pro_engine.stop()
            uni_engine.stop()

        final_stage_elapsed = time.monotonic() - stage_start
        final_summary = self._save_checkpoint_and_summaries(final_stage_elapsed)

        # In heartbeat cuối chặng và bản báo cáo tổng kết
        st = final_summary["statistics"]
        final_hb = format_heartbeat_line(
            elapsed_sec=self.prior_elapsed_seconds + final_stage_elapsed,
            target_sec=self.total_duration_seconds,
            total_games=st["total_games"],
            pro_wins=st["pro"]["wins"],
            uni_wins=st["universal"]["wins"],
            draws=st["pro"]["draws"],
        )
        print(final_hb + "\n", flush=True)
        self._append_heartbeat_to_log(final_hb)

        with open(self.summary_md_path, "r", encoding="utf-8") as f:
            print(f.read(), flush=True)

        return final_summary


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Stockfish Ultimate Duel — Tournament & Verification CLI")
    parser.add_argument("--verify-only", action="store_true", help="Chỉ kiểm tra hai binary và tạo build-manifest.json")
    parser.add_argument("--plan-stages", action="store_true", help="Tính toán kế hoạch chia chặng (1-3h vs 4-6h)")
    parser.add_argument("--pro-bin", type=str, default="build/bin/stockfish-pro", help="Đường dẫn binary Engine A (Pro)")
    parser.add_argument("--uni-bin", type=str, default="build/bin/stockfish-universal", help="Đường dẫn binary Engine B (Universal)")
    parser.add_argument("--results-dir", type=str, default="results", help="Thư mục xuất kết quả")
    parser.add_argument("--manifest", type=str, default="results/build-manifest.json", help="Đường dẫn build-manifest.json")

    # Tham số metadata cho --verify-only
    parser.add_argument("--elf-inspection", type=str, default="")
    parser.add_argument("--pro-source-origin", type=str, default="Stockfish-19-Pro-Ultimate-V3/src")
    parser.add_argument("--uni-source-origin", type=str, default="stockfish-android-arm64-universal/stockfish/src")
    parser.add_argument("--pro-archive-sha256", type=str, default="")
    parser.add_argument("--uni-archive-sha256", type=str, default="")
    parser.add_argument("--target-arch", type=str, default="")
    parser.add_argument("--dotprod-status", type=str, default="false")
    parser.add_argument("--compiler-info", type=str, default="")
    parser.add_argument("--nnue-sha256", type=str, default="1a298aa575a085434d29027978dc36867fe9c5bcea9376654b7a8eba1e52dfc2")

    # Tham số cấu hình đấu
    parser.add_argument("--duration", type=str, default="1 Hour", help="Thời lượng tổng (1..6 giờ, vd: '1 Hour', '6 Hours')")
    parser.add_argument("--duration-seconds", type=float, default=None, help="Ghi đè tổng thời lượng tính bằng giây (dùng cho kiểm thử)")
    parser.add_argument("--stage-seconds", type=float, default=None, help="Thời lượng tối đa của chặng hiện tại (giây)")
    parser.add_argument("--stage", type=int, default=1, choices=[1, 2], help="Số thứ tự chặng (1 hoặc 2)")
    parser.add_argument("--resume", action="store_true", help="Khôi phục trạng thái giải đấu từ checkpoint.json")
    parser.add_argument("--move-time", type=str, default="200 ms", help="Thời gian suy nghĩ mỗi nước (100 ms, 200 ms, 500 ms)")
    parser.add_argument("--hash", type=str, default="256 MB", help="Dung lượng Hash mỗi engine (128 MB, 256 MB, 512 MB)")
    parser.add_argument("--threads", type=int, default=1, help="Số luồng tìm kiếm mỗi engine (mặc định 1)")
    parser.add_argument("--seed", type=int, default=20261109, help="Random seed xáo trộn khai cuộc")
    parser.add_argument("--max-ply", type=int, default=400, help="Giới hạn ply an toàn mỗi ván")
    parser.add_argument("--heartbeat-interval", type=float, default=300.0, help="Chu kỳ in heartbeat (giây, mặc định 300s = 5 phút)")
    parser.add_argument("--max-games", type=int, default=None, help="Giới hạn số ván tối đa (dùng cho integration test)")

    args = parser.parse_args(argv)

    if args.plan_stages:
        hours = parse_duration_hours(args.duration)
        plan = compute_stage_plan(hours)
        print(json.dumps(plan, indent=2))
        github_output = os.environ.get("GITHUB_OUTPUT")
        if github_output:
            with open(github_output, "a", encoding="utf-8") as out:
                for k, v in plan.items():
                    val_str = str(v).lower() if isinstance(v, bool) else str(v)
                    out.write(f"{k}={val_str}\n")
        return 0

    if args.verify_only:
        generate_build_manifest(
            pro_bin=args.pro_bin,
            uni_bin=args.uni_bin,
            manifest_path=args.manifest,
            results_dir=args.results_dir,
            elf_inspection_path=args.elf_inspection or None,
            pro_source_origin=args.pro_source_origin,
            uni_source_origin=args.uni_source_origin,
            pro_archive_sha256=args.pro_archive_sha256,
            uni_archive_sha256=args.uni_archive_sha256,
            target_arch=args.target_arch,
            dotprod_status=args.dotprod_status,
            compiler_info=args.compiler_info,
            nnue_sha256=args.nnue_sha256,
        )
        return 0

    if args.duration_seconds is not None:
        total_sec = float(args.duration_seconds)
        stage_sec = float(args.stage_seconds) if args.stage_seconds is not None else total_sec
    else:
        hours = parse_duration_hours(args.duration)
        plan = compute_stage_plan(hours)
        total_sec = float(plan["total_seconds"])
        if args.stage_seconds is not None:
            stage_sec = float(args.stage_seconds)
        elif args.stage == 1:
            stage_sec = float(plan["stage1_seconds"])
        else:
            # Stage 2 runs whatever remaining time is left to reach total_seconds
            stage_sec = float(plan["total_seconds"])

    move_time_ms = parse_positive_int(args.move_time, "Move Time")
    hash_mb = parse_positive_int(args.hash, "Hash")

    # Đảm bảo hai engine luôn vượt qua kiểm tra UCI trước khi đấu
    if not os.path.isfile(args.manifest):
        generate_build_manifest(
            pro_bin=args.pro_bin,
            uni_bin=args.uni_bin,
            manifest_path=args.manifest,
            results_dir=args.results_dir,
        )
    else:
        probe_engine_uci_and_move(args.pro_bin)
        probe_engine_uci_and_move(args.uni_bin)

    runner = TournamentRunner(
        pro_bin=args.pro_bin,
        uni_bin=args.uni_bin,
        results_dir=args.results_dir,
        total_duration_seconds=total_sec,
        stage_max_seconds=stage_sec,
        move_time_ms=move_time_ms,
        hash_mb=hash_mb,
        threads=args.threads,
        random_seed=args.seed,
        max_ply=args.max_ply,
        heartbeat_interval_sec=args.heartbeat_interval,
        stage_number=args.stage,
        resume=args.resume,
        max_games=args.max_games,
    )
    runner.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
