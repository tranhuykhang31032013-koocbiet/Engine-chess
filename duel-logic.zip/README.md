# STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS EDITION

Hệ thống tổ chức giải đấu cờ vua tự động (Automated Chess Engine Tournament) trên **GitHub Actions (`ubuntu-24.04-arm`)** giữa hai engine đặt trực tiếp ở thư mục gốc của Repository:

1. **Engine A — `Stockfish 19 Pro Ultimate V3`** (`stockfish-19-pro-ultimate-v3-arm64-dotprod`)
2. **Engine B — `Stockfish Android ARM64 Universal`** (`stockfish-android-arm64-universal.tar.gz`)

## 1. Cách Upload Cực Gọn Lên GitHub Repository (Không Cần Tạo Nhiều Thư Mục Con)

Để việc tải file lên GitHub cực kỳ nhanh và đơn giản, toàn bộ code điều phối giải đấu, trọng tài `python-chess`, bộ kiểm thử, `experience.bin` và mã nguồn C++ đối chứng đã được đóng gói gọn nhẹ vào một tệp nén duy nhất **`duel-logic.zip`** (~1 MB).

Bạn chỉ cần cấu trúc Repository gồm **4 tệp** như sau:

```text
ten-repository-cua-ban/
├── .github/
│   └── workflows/
│       └── stockfish-ultimate-duel.yml              <-- 1. File cấu hình GitHub Actions
├── duel-logic.zip                                   <-- 2. Gói nén chứa toàn bộ logic & scripts
├── stockfish-19-pro-ultimate-v3-arm64-dotprod       <-- 3. Tệp Engine A ở ngay thư mục gốc
└── stockfish-android-arm64-universal.tar.gz         <-- 4. Tệp Engine B ở ngay thư mục gốc
```

### Cơ Chế Tự Động Khi Nhấn "Run workflow" Trên GitHub Actions

1. **Bước 1 — Tự động giải nén `duel-logic.zip`**: Ngay sau khi checkout repository, GitHub Actions tự động tìm `duel-logic.zip` ở thư mục gốc và giải nén ra `scripts/build_engines.sh`, `scripts/tournament.py`, `tests/test_tournament.py`, `requirements.txt` và thư mục mã nguồn đối chứng `engines/`.
2. **Bước 2 — Kiểm định 2 tệp Engine ở thư mục gốc**:
   * Kiểm tra `stockfish-19-pro-ultimate-v3-arm64-dotprod` (`SHA-256: 6ea6746074e5860f78f7aae43532bc1ec9491c1e7055f328c0aeec5990ee62e9`, `99.263.104` bytes): Xác nhận header `ELF64 AArch64 PIE`, dynamic linker `/system/bin/linker64` (Android Termux `RUNPATH=/data/data/com.termux/files/usr/bin/../../usr/lib`, `NEEDED: libc++_shared.so, libc.so`), xác thực đầy đủ chữ ký nhị phân của `Stockfish 19-Pro` (`LearnManager`, `GlobalLearn`, `Optimism Bias`, `Dynamic Aggression`, `Fortress Detection`, `Deep Scaler Mode`, `Experience Enabled`, `Adaptive Opponent Mode`) và **trích xuất trực tiếp mạng `nn-1a298aa575a0.nnue` (98,5 MB) nhúng tại offset `33344`** mà không cần tải lại từ Internet.
   * Kiểm tra `stockfish-android-arm64-universal.tar.gz` (`SHA-256: ebb24051aa4a222b4daaf049b882ecf1163d370c128fe02316602643f4d5e426`): Giải nén, kiểm tra binary `stockfish-android-arm64-universal` (`ELF64 AArch64` liên kết tĩnh với Android NDK r27c Bionic libc), và đối chiếu `stockfish/src/` khớp 100% từng byte (76/76 tệp) với `baseline_src/`.
3. **Bước 3 — Biên dịch đối xứng sang Linux ARM64 (`ubuntu-24.04-arm`)**: Vì cả hai binary đầu vào đều sử dụng Android Bionic runtime (`/system/bin/linker64` và Bionic libc tĩnh), hệ thống tự động biên dịch cả hai engine sang chuẩn Linux native trên runner `ubuntu-24.04-arm` với cùng trình biên dịch (`g++`), cùng mức tối ưu hóa (`-O3`), cùng mạng NNUE (`nn-1a298aa575a0.nnue`) và cùng đích kiến trúc (`ARCH=armv8-dotprod` nếu CPU hỗ trợ DotProd, hoặc `ARCH=armv8`).
4. **Bước 4 — Chạy Solo & Xuất Kết Quả**: Hai engine đấu đối xứng theo cặp khai cuộc (30 khai cuộc Standard Chess, đổi màu quân luân phiên), in log tiếng Việt trực tiếp sau từng ván, tự động chia 2 chặng nếu chọn 4–6 giờ (Chặng 1 chạy 3 giờ + Chặng 2 resume chạy phần còn lại), và đóng gói toàn bộ kết quả vào artifact **`Stockfish-Ultimate-Duel-Results`** (lưu trữ 30 ngày).
