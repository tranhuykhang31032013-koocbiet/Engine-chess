# STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS EDITION (MULTI-CORE TURBO & PRO V3 UPGRADED)

Hệ thống tự động điều phối giải đấu đối kháng thực tế (**Real Chess Engine Tournament**) trên **GitHub Actions (`ubuntu-24.04-arm`)** giữa hai engine:

- **Engine A**: `Stockfish 19 Pro Ultimate V3` *(Bản nâng cấp 3 đột phá kiến trúc + Multi-Branch Depth-16 Experience Book 356 vị trí)*
- **Engine B**: `Stockfish Android ARM64 Universal`

---

## 1. Nâng Cấp Mới Nhất (Pro V3 Upgraded + Tùy Chọn Phút `10p -> 300p` + Đấu Đa Nhân Song Song)

### 1.1. Tích Hợp Bản Cập Nhật `Stockfish 19 Pro Ultimate V3` Mới Nhất (Không Dùng Cơ Chế Dự Phòng)
- **Google Drive Engine A (Bản nâng cấp Pro V3)**:
  - Link: `https://drive.google.com/file/d/1kzvxgVBl4xjdRztMApj66f3CPaAQbwGX/view?usp=drivesdk` (`File ID: 1kzvxgVBl4xjdRztMApj66f3CPaAQbwGX`, kích thước `99,263,064 bytes`, quyền truy cập: `anyoneWithLink / reader`)
- **Google Drive Engine B (Universal)**:
  - Link: `https://drive.google.com/file/d/1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l/view?usp=drivesdk` (`File ID: 1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l`, kích thước `80,233,187 bytes`, quyền truy cập: `anyoneWithLink / reader`)
- **Chính sách Fail-Fast (Không dùng fallback)**: Hệ thống chỉ tải trực tiếp từ đúng 2 tệp Google Drive trên. Nếu việc tải tệp hoặc kiểm tra chữ ký nhị phân ELF / SHA-256 / NNUE thất bại, workflow sẽ lập tức dừng (`exit 1`) và in thông báo lỗi chi tiết ra Console.
- **Cây mã nguồn C++ và `experience.bin` bản nâng cấp của Pro V3** đã được tích hợp trực tiếp trong `duel-logic.zip`:
  - Khắc phục triệt để lỗi đảo dấu `optimism[~us] = -optimism[us]` và đặt mặc định `Adaptive Opponent Mode = false`.
  - Loại bỏ việc ghi đè `ttData.move` khi `!ttHit` ở các nút nội bộ và bỏ ghi đè `bestmove` hậu tìm kiếm.
  - Bổ sung **Asymmetric Color-Aware Experience Gating** (`minExpScore = +5 cp` cho Trắng, `-8 cp` cho Đen) kết hợp **3-Ply Transient Horizon Seeding** (`lowPlyHistory[0..2]`).
  - Tối ưu đường chạy nhanh trong `Eval::evaluate()` và `contHist` 1 phần tử trong `qsearch()`.
  - Kèm theo **`experience/experience.bin` mới (`8,560 bytes`, SHA-256: `b5274fb915c156c63f3ffcb53492ca7f9ed90c1693ed5fed25eb5e1ed4eb0a9b`)** gồm **356 vị trí khai cuộc Depth-16** có khóa bảo vệ (`gamesCount >= 5`).

### 1.2. Tùy Chọn Thời Gian Đấu Theo Phút (`10p` -> `300p`)
Giao diện `workflow_dispatch` trên GitHub Actions cho phép chọn chính xác theo **phút** từ **10 phút (`10p`) đến 300 phút (`300p`)**:
- **Từ `10p` đến `180p` (10 phút – 3 giờ)**: Chạy trong **1 chặng duy nhất** (`Stage 1`).
- **Từ `210p` đến `300p` (3.5 giờ – 5 giờ)**: Tự động chia thành **2 chặng** (`Stage 1` chạy tối đa `180p` [3 giờ] + `Stage 2` tự động khôi phục từ `checkpoint.json` và chạy nốt số phút còn lại `duration_minutes - 180`).
- *Lưu ý*: Chia chặng có thể phát sinh khoảng nghỉ ngắn (vài chục giây) giữa hai job để bàn giao artifact, nhưng tổng thời gian thi đấu thực tế cộng dồn luôn bằng đúng số phút đã chọn.

### 1.3. Thi Đấu Đa Nhân / Đa Bàn Song Song (`Concurrency 1x -> 4x`) — Giữ Nguyên 100% Tài Nguyên Mỗi Engine
Trên runner `ubuntu-24.04-arm` (4 nhân vCPU ARM64 Neoverse, 16 GB RAM), trong một ván cờ tại mỗi thời điểm chỉ có **1 bên (Trắng hoặc Đen)** đang tính toán nước đi (`go movetime ...`), còn engine bên kia ở trạng thái chờ lượt.
- Hệ thống bổ sung cơ chế **Multi-Core Parallel Duel (`--concurrency`)** cho phép chạy đồng thời **1, 2, 3 hoặc 4 bàn cờ song song** (mặc định **`4 Boards (Parallel 4x - Multi-Core Turbo)`**).
- **CAM KẾT KHÔNG GIẢM TÀI NGUYÊN HAY SỨC MẠNH**:
  - Mỗi bàn cờ song song khởi chạy cặp tiến trình `stockfish-pro` và `stockfish-universal` độc lập.
  - **Mỗi engine trên từng bàn đều được cấp ĐỦ 100% cấu hình đã chọn**: đủ `Hash` (ví dụ `256 MB` hoặc `512 MB` cho **từng** engine), đủ `Threads` (ví dụ `1 Thread` cho **từng** engine), và đủ `Move Time` (`100 ms`, `200 ms`, hoặc `500 ms`/nước).
  - Với 4 bàn song song trên 4 nhân vCPU (`Threads=1`, `Hash=256 MB`), tại mọi thời điểm có đúng 4 tiến trình engine đang tính toán trên 4 nhân vật lý riêng biệt (tổng RAM chỉ ~2 GB / 16 GB RAM của runner), giúp **tăng tốc độ thu thập số ván lên ~4 lần** và thu hẹp khoảng tin cậy 95% CI nhanh gấp đôi để đánh giá Elo khách quan nhất!

---

## 2. Cách Upload & Chạy Giải Đấu Trên GitHub (Chỉ Cần 2 File Nhỏ < 2 MB)

Bạn chỉ cần upload **2 tệp nhỏ** lên repository GitHub:
1. **`duel-logic.zip`** (~1 MB) đặt ở **thư mục gốc (root)** của repository.
2. **`.github/workflows/stockfish-ultimate-duel.yml`** đặt vào đường dẫn `.github/workflows/stockfish-ultimate-duel.yml`.

---

## 3. Các Tệp Kết Quả Trong Artifact `Stockfish-Ultimate-Duel-Results`

Sau khi workflow hoàn tất (hoặc kể cả khi bị dừng sớm nhờ `if: always()`), tải gói **`Stockfish-Ultimate-Duel-Results`** gồm:
- `matches.log`: Log tiếng Việt trực tiếp của từng trận và các dòng heartbeat.
- `matches.pgn`: Toàn bộ biên bản ván đấu chuẩn PGN quốc tế.
- `matches.csv`: Bảng dữ liệu chi tiết từng ván đấu.
- `matches.jsonl`: Dữ liệu JSON Lines từng ván đấu.
- `summary.json`: Thống kê tổng hợp W/D/L, tỷ lệ điểm, Elo Difference, 95% CI, tốc độ tăng tốc đa nhân (`effective_parallel_speedup`).
- `summary.md`: Báo cáo tổng kết đầy đủ bằng tiếng Việt.
- `build-manifest.json`: Hồ sơ kiểm định biên dịch, SHA-256, cờ CPU DotProd, UCI options và trạng thái Experience.
