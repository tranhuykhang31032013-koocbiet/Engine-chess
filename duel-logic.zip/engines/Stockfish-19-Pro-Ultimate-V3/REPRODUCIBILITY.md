# REPRODUCIBILITY GUIDE — Stockfish 19-Pro Ultimate V3

Tài liệu này cung cấp quy trình từng bước để bất kỳ kỹ sư độc lập nào cũng có thể giải nén, biên dịch lại từ mã nguồn, chạy bộ kiểm thử tự động, chạy lại benchmark và kiểm định tính toàn vẹn của gói `Stockfish-19-Pro-Ultimate-V3.tar.gz` trên một môi trường sạch.

## 1. Yêu Cầu Môi Trường Tối Thiểu

1. **Cho Build, Test & Benchmark trên Linux `x86-64`**:
   - Hệ điều hành Linux `x86_64` với CPU hỗ trợ `AVX2` (hoặc chỉnh `ARCH=x86-64-sse41-popcnt` nếu CPU cũ hơn).
   - `g++` (GCC 10+ hỗ trợ `-std=c++17`, khuyến nghị GCC 12+) hoặc `clang++`.
   - GNU `make`, `python3` (3.9+), `sha256sum`, POSIX `/bin/sh`.
2. **Cho Cross-Build Android ARM64 (Tùy chọn trên máy có NDK)**:
   - Bộ công cụ **Android NDK r26+** (chứa `aarch64-linux-android29-clang++` và `llvm-strip`).

## 2. Quy Trình 5 Bước Tái Lập Trên Môi Trường Sạch (Clean-Room Verification)

```sh
# Bước 1: Giải nén gói sản phẩm vào thư mục mới
mkdir -p /tmp/sf_v3_cleanroom
tar -xzf Stockfish-19-Pro-Ultimate-V3.tar.gz -C /tmp/sf_v3_cleanroom
cd /tmp/sf_v3_cleanroom/Stockfish-19-Pro-Ultimate-V3

# Bước 2: Kiểm tra tính toàn vẹn của gói và bảng mã băm SHA256SUMS.txt
./verify_package.sh
echo "Exit code verify_package.sh: $?"

# Bước 3: Biên dịch toàn bộ binary từ mã nguồn C++17
# (Bao gồm: src/stockfish, src/stockfish_asan, và benchmark/stockfish_19_baseline_x86)
JOBS=2 ./build.sh
echo "Exit code build.sh: $?"

# Bước 4: Chạy bộ kiểm thử hồi quy & chống giả mạo 10 hạng mục
./test.sh
echo "Exit code test.sh: $?"

# Bước 5: (Tùy chọn) Chạy lại giải đấu thực nghiệm 80 ván (khoảng 6-7 phút trên 2 vCPU)
./benchmark.sh
echo "Exit code benchmark.sh: $?"
```

## 3. Kiểm Tra Các Chốt Chặn Fail-Closed (Fault-Injection Verification)

Người kiểm toán có thể trực tiếp xác minh rằng các script của V3 **không bao giờ trả về exit code `0` giả tạo khi có lỗi**:

```sh
# 1. Kiểm tra build.sh trả về mã lỗi khác 0 khi quá trình build gặp sự cố:
./build.sh --inject-fault ; echo "Exit code: $?"   # Kỳ vọng: 42 (khác 0)

# 2. Kiểm tra test.sh trả về mã lỗi khác 0 khi kiểm thử gặp sự cố:
./test.sh --inject-fault  ; echo "Exit code: $?"   # Kỳ vọng: 43 (khác 0)

# 3. Kiểm tra benchmark.sh trả về mã lỗi khác 0 khi gặp sự cố:
./benchmark.sh --inject-fault ; echo "Exit code: $?" # Kỳ vọng: 44 (khác 0)

# 4. Kiểm tra benchmark/run_benchmark.py chặn đứng hành vi tự đấu (FINDING-02):
python3 benchmark/run_benchmark.py --pro-bin src/stockfish --baseline-bin src/stockfish
echo "Exit code: $?"                               # Kỳ vọng: 2 (khác 0)
```

## 4. Kết Quả Thực Thi Clean-Room Đã Xác Thực

Trên máy chủ kiểm định độc lập (`/usr/local/share/sf_v3_cleanroom_verify`), chuỗi lệnh:

```sh
JOBS=2 ./build.sh && ./test.sh && ./verify_package.sh
```

hoàn tất với:
- `build.sh`: Exit code `0` (`src/stockfish` SHA-256 != `benchmark/stockfish_19_baseline_x86` SHA-256).
- `test.sh`: Exit code `0` (`PASS=8 | FAIL=0 | SKIPPED=0 | NOT_AVAILABLE=2`).
- `verify_package.sh`: Exit code `0` (`FAIL=0`, toàn bộ `SHA256SUMS.txt` và đối chiếu JSON/PGN hợp lệ 100%).
