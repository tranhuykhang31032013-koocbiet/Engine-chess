# STOCKFISH ULTIMATE DUEL — GITHUB ACTIONS EDITION (V3.5 LEAPFROG SMP & MAX HARDWARE EDITION)

Hệ thống tự động điều phối giải đấu đối kháng thực tế (**Real Chess Engine Tournament**) khai thác 100% sức mạnh phần cứng trên **GitHub Actions (`ubuntu-24.04-arm`: 4 nhân vCPU ARMv8.2+ DotProd, 16 GB RAM)** giữa hai engine:

- **Engine A**: `Stockfish 19 Pro Ultimate V3` *(Bản nâng cấp V3.5: Leapfrog SMP + Quadratic Depth-Weighted Voting + Contention-Resilient Grandmaster Book Guard + 5-State Chameleon + TD-Lambda Bandit + 708-Entry `experience.bin`)*
- **Engine B**: `Stockfish Android ARM64 Universal`

---

## 1. Nâng Cấp Bản Stockfish Pro Mới & Khai Thác Tối Đa Phần Cứng (Max Hardware Acceleration)

### 1.1. Tích Hợp Bản Cập Nhật `Stockfish 19 Pro Ultimate V3.5` Mới Nhất
- **Google Drive Engine A (Bản nâng cấp Pro V3.5)**:
  - Link: `https://drive.google.com/file/d/175UoW9tysczbbrZYW9B3d17oFULjOoxb/view?usp=drivesdk` (`File ID: 175UoW9tysczbbrZYW9B3d17oFULjOoxb`, kích thước `99,266,760 bytes`)
- **Google Drive Engine B (Universal)**:
  - Link: `https://drive.google.com/file/d/1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l/view?usp=drivesdk` (`File ID: 1vbj9fK4iCrBFWzGACOMNJFBWBpaHHL7l`, kích thước `80,233,187 bytes`)
- **Chính sách Fail-Fast (Không dùng fallback)**: Hệ thống chỉ tải trực tiếp từ đúng 2 tệp Google Drive trên; nếu tải lỗi hoặc sai chữ ký nhị phân ELF / SHA-256 / NNUE, workflow dừng ngay lập tức (`exit 1`) và báo lỗi rõ ràng.
- **Đột phá kiến trúc trong mã nguồn C++ Pro V3.5 (`duel-logic.zip`)**:
  - **Leapfrog SMP (`search.cpp`)**: Các luồng tìm kiếm phụ (helper threads) tự động nhảy vọt qua các độ sâu đã hoàn thành (`maxCompleted + (threadIdx & 1)`) và tận dụng bảng băm TT để vươn tới độ sâu lớn hơn thay vì tìm kiếm trùng lặp.
  - **Quadratic Depth-Weighted Thread Voting (`thread.cpp`)**: Bầu chọn nước đi tốt nhất giữa các luồng SMP theo trọng số bậc hai của độ sâu hoàn thành (`depthWeight^2`), lọc bỏ luồng bị kẹt độ sâu và phạt điểm `inexactUpper` (fail-low).
  - **Contention-Resilient Grandmaster Book Guard (`search.cpp`)**: Bảo vệ nước đi sách đại kiện tướng (`Depth >= 16..20`, `winPerf >= 108`) trong 34 ply đầu tiên ngay cả khi chạy đa bàn song song.
  - **708-Entry Multi-Branch TD-Lambda Bandit Experience Book (`experience/experience.bin`)**: Dung lượng `17,008 bytes` (`SHA-256: 7cd8bd2971b56c0951e99879c6f209128ec862b0a4bd5a2a864d536d2721a219`), bao phủ toàn bộ 30 khai cuộc của giải đấu ở độ sâu Depth-20.

### 1.2. 5 Tầng Tối Ưu Hóa Phần Cứng Tối Đa (Unleashing 100% Runner Hardware)
1. **Biên dịch Profile-Guided Optimization (`profile-build` / PGO) + Full LTO + Native CPU Tuning (`-mcpu=native -mtune=native` + `armv8-dotprod`)**:
   - Cả hai engine đều được biên dịch bằng chế độ `profile-build` (chạy thu thập hồ sơ dự đoán nhánh thực tế rồi tái biên dịch tối ưu hóa PGO + LTO) kết hợp cờ vi kiến trúc phần cứng bản địa của chip ARM64 Neoverse, giúp tăng tốc độ tính toán thêm **+8% đến +15% NPS (Nodes/giây)**.
2. **Kích hoạt Linux Kernel 2MB HugePages & Transparent Huge Pages (`THP = always`)**:
   - Tự động cấu hình kernel Linux trên runner cấp phát trang nhớ lớn 2MB (`MADV_HUGEPAGE`) cho bảng băm Transposition Table (`Hash` lên tới `2048 MB`/engine) và mạng NNUE (`98.5 MB`), giảm tới 500 lần lỗi trượt bộ đệm địa chỉ TLB (TLB misses).
3. **Ghim Nhân CPU Vật Lý Độc Lập (`Hardware CPU Core Affinity Pinning` qua `os.sched_setaffinity`)**:
   - Tự động chia và ghim cố định từng bàn đấu vào các nhân CPU vật lý riêng biệt (ví dụ với `2 Boards` × `2 Threads/Engine` trên 4 nhân vCPU: Bàn 1 ghim chặt vào `Cores [0, 1]`, Bàn 2 ghim chặt vào `Cores [2, 3]`; hoặc với `4 Boards` × `1 Thread/Engine`: mỗi bàn độc chiếm 1 nhân `Core [0]..[3]`), giữ nóng 100% bộ đệm L1/L2/L3 cache và triệt tiêu hoàn toàn độ trễ nhảy nhân.
4. **Mở rộng cấu hình phần cứng cao cấp (Khai thác trọn vẹn 16 GB RAM & 4 nhân vCPU)**:
   - **Threads**: `1 Thread`, **`2 Threads per Engine (Leapfrog SMP 2-Core)`** (Mặc định tối ưu), hoặc `4 Threads per Engine (Max 4-Core Leapfrog SMP)`.
   - **Hash**: `128 MB`, `256 MB`, **`512 MB`** (Mặc định), `1024 MB (1 GB/Engine)`, đến **`2048 MB (2 GB/Engine)`**.
   - **Move Time**: `100 ms`, `200 ms`, **`500 ms`** (Mặc định), `1000 ms (1s/nước)`, đến **`2000 ms (2s/nước)`**.
   - **Concurrency**: **`Auto-Optimal`** (tự động chia số bàn = `4 vCPU / Threads` để mỗi luồng tìm kiếm độc chiếm 1 nhân vật lý) hoặc chọn cố định `1..4 Boards`.
5. **Hợp nhất cơ sở dữ liệu học tăng cường nhị phân `SF19EXP2` đa bàn (`merge_experience_files`)**:
   - Toàn bộ các thế cờ sâu (`depth >= 22`) mà các bàn đấu song song học được trong suốt giải đấu đều được hợp nhất nhị phân trực tiếp về tệp `results/experience.bin`.

---

## 2. Cách Upload & Chạy Giải Đấu Trên GitHub

1. **Bật quyền chia sẻ công khai trên Google Drive cho bản Pro mới**: Hãy đảm bảo tệp [stockfish-19-pro-ultimate-v3-arm64-dotprod (File ID: 175UoW9tysczbbrZYW9B3d17oFULjOoxb)](https://drive.google.com/file/d/175UoW9tysczbbrZYW9B3d17oFULjOoxb/view?usp=drivesdk) được đặt ở chế độ **"Bất kỳ ai có đường liên kết" (`Anyone with the link`)**.
2. **Upload 2 tệp nhỏ lên GitHub**:
   - **`duel-logic.zip`** đặt ở **thư mục gốc (root)** của repository.
   - **`stockfish-ultimate-duel.yml`** đặt vào `.github/workflows/stockfish-ultimate-duel.yml`.
