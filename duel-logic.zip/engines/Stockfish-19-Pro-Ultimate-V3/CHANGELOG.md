# CHANGELOG — Stockfish 19-Pro Ultimate V3

## [V3.0.0] — 2026-11-08 (Critical Audit Repair & Scientific Verification Release)

### 1. Sửa Lỗi Nghiêm Trọng Từ Kiểm Toán V2 (`FINDING-01` .. `FINDING-04`)
- **[FINDING-01] Loại bỏ binary Android giả mạo & Xây dựng hệ thống kiểm định Android Fail-Closed**:
  - Xóa bỏ file `stockfish-19-pro-ultimate-v2-arm64` (vốn là bản copy nguyên trạng của Stockfish 19 Android gốc với SHA-256 `ffd8fc2004d3d19f9fdab95d84c92709aea92e8d3af405eda0b281b23cf1daf8`).
  - Thêm `android/build_android_v3.sh` hỗ trợ biên dịch từ mã nguồn V3 cho cả `armv8` (`stockfish-19-pro-ultimate-v3-arm64`) và `armv8-dotprod` (`stockfish-19-pro-ultimate-v3-arm64-dotprod`) với cờ `-fPIE -pie -static-libstdc++ -Wl,-z,max-page-size=16384`.
  - Thêm `android/verify_android_v3.py` kiểm tra header ELF64 AArch64, chặn cứng mã băm `ffd8fc20...`, và kiểm tra sự hiện diện của toàn bộ 7 tùy chọn UCI Pro trong binary.
  - Phân loại trung thực `NOT_AVAILABLE` khi môi trường host không có Android NDK `aarch64-linux-android29-clang++`.
- **[FINDING-02] Khắc phục lỗi tự đấu trong Benchmark (`base_bin = pro_bin`)**:
  - Bổ sung thư mục mã nguồn gốc độc lập `baseline_src/` (Upstream Stockfish 19) và biên dịch ra `benchmark/stockfish_19_baseline_x86` (`SHA-256: e8b3e5d6a5f6...`).
  - Viết lại `benchmark/run_benchmark.py` theo cơ chế **Fail-Closed**: bắt buộc đối chiếu SHA-256 và danh sách tùy chọn UCI của hai đối thủ trước khi thi đấu; tự động hủy bỏ với `exit code 2` nếu hai bên trùng đường dẫn hoặc trùng SHA-256.
- **[FINDING-03] Khắc phục lỗi nhân hai lần `Dynamic Aggression` (Double-Scaling)**:
  - Xóa bỏ phép nhân `dynamicAggression / 100` tại `src/search.cpp:441`.
  - Đóng gói phép nhân một lần duy nhất vào hàm `Eval::scale_optimism_by_aggression(int optimism, int aggressionPct)` trong `src/evaluate.cpp:57-63` với phép kẹp biên 64-bit `std::clamp<i64>(aggressionPct, 50, 150)`.
  - Mở rộng `Eval::trace()` trong `src/evaluate.cpp` và `src/engine.cpp` để xuất trực tiếp thông số `Dynamic Aggression` và `adjusted optimism` khi gọi lệnh `eval`.
- **[FINDING-04] Khắc phục lỗi mất Exit Code do `| tee` trong các script POSIX**:
  - Thay thế toàn bộ cấu trúc `| tee` trong `build.sh`, `test.sh`, `benchmark.sh` bằng khối subshell lưu và trả về chính xác mã thoát `EXIT_CODE`.
  - Bổ sung tham số `--inject-fault` trên cả 3 script để kiểm chứng tự động việc trả về mã lỗi khác 0.

### 2. Tinh Chỉnh Thuật Toán Tìm Kiếm & Hệ Thống Kinh Nghiệm (`src/search.cpp`)
- Khôi phục điều kiện gốc `!ttData.move` tại `src/search.cpp:1069` (Futility pruning) và `src/search.cpp:1124` (Internal Iterative Reductions) để ngăn việc giảm độ sâu `depth--` ngoài ý muốn tại nút gốc (`rootNode`) khi chưa có TT hit.
- Giới hạn phạm vi tác động của `Deep Scaler Mode` tại `src/search.cpp:1394` chỉ áp dụng trên nhánh không phải PV ở độ sâu lớn (`!PvNode && depth >= 16 && moveCount >= 12`).
- Bổ sung điều kiện đối chiếu độ sâu Transposition Table (`std::max(Depth(12), Depth(ttData.depth + 1))`) trước khi đôn nước đi từ `Experience Book` lên đầu danh sách `rootMoves` tại `src/search.cpp:361`, đảm bảo nước đi từ `experience.bin` chỉ được ưu tiên khi có độ sâu phân tích vượt trội hơn TT hiện tại.

### 3. Kiểm Thử, Benchmark 4 Nhóm & Đóng Gói (`tests/`, `benchmark/`, `verify_package.sh`)
- Mở rộng `tests/run_test_suite.py` lên 10 hạng mục với phân loại trạng thái rõ ràng (`PASS=8 | FAIL=0 | SKIPPED=0 | NOT_AVAILABLE=2`).
- Thực thi đầy đủ 4 nhóm trận đấu trong `benchmark/run_benchmark.py` (80 ván, đối chiếu 1-1 giữa `benchmark_results.json` và `tournament_games.pgn`).
- Bổ sung `verify_package.sh` và `SHA256SUMS.txt` để kiểm chứng toàn vẹn toàn bộ gói sản phẩm.
