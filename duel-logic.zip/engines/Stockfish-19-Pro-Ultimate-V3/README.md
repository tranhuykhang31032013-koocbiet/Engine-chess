# Stockfish 19-Pro Ultimate V3

**Forensic Repair — Fail-Closed Build & Benchmark Architecture — Single-Scaling Optimism — Reproducible Verification**

## 1. Tổng Quan Dự Án (Overview)

`Stockfish-19-Pro-Ultimate-V3` là bản nâng cấp kỹ thuật trực tiếp từ `Stockfish-19-Pro-Ultimate-V2`, giải quyết triệt để **4 phát hiện kiểm toán độc lập (`FINDING-01` đến `FINDING-04`)** và tuân thủ nghiêm ngặt nguyên tắc phân tách trạng thái kiểm chứng:

- **`BUILD SUCCESS` != `ANDROID RUNTIME SUCCESS` != `ELO IMPROVEMENT`**
- **`PASS` != `FAIL` != `SKIPPED` != `NOT AVAILABLE`**

### Tóm Tắt Xử Lý 4 Phát Hiện Từ Kiểm Toán V2

| Mã Phát Hiện | Nội Dung Kiểm Toán V2 | Giải Pháp Kỹ Thuật Trong V3 | Trạng Thái V3 |
| :--- | :--- | :--- | :--- |
| **FINDING-01** | Binary Android trong V2 (`stockfish-19-pro-ultimate-v2-arm64`, SHA-256 `ffd8fc20...`) trùng khớp 100% với Stockfish 19 Android gốc và thiếu toàn bộ chuỗi UCI Pro. | Xóa bỏ hoàn toàn binary Android giả mạo; xây dựng `android/build_android_v3.sh` (biên dịch trực tiếp từ `src/` cho `armv8` và `armv8-dotprod`) và `android/verify_android_v3.py` (chặn cứng SHA-256 `ffd8fc20...` và kiểm tra đầy đủ 7 UCI options Pro). Trên máy chủ `x86_64` offline không có Android NDK, báo cáo trung thực `NOT AVAILABLE` (exit code `2`), tuyệt đối không copy hay hex-patch binary gốc. | **RESOLVED (Anti-Spoof Enforced / Cross-Build `NOT AVAILABLE` on Offline Host)** |
| **FINDING-02** | `benchmark/run_benchmark.py` trong V2 có cơ chế fallback `base_bin = pro_bin` khiến engine tự đấu với chính mình (cùng SHA-256 `3a6f835551cf...`). | Đóng gói mã nguồn Stockfish 19 gốc độc lập trong `baseline_src/`, biên dịch ra `benchmark/stockfish_19_baseline_x86` (SHA-256 `e8b3e5d6a5f6...` != `c24cb011b288...`), và áp dụng chốt chặn **Fail-Closed SHA-256 & UCI Identity Guard** trong `benchmark/run_benchmark.py` (dừng ngay với exit code `2` nếu thiếu baseline hoặc trùng SHA-256). | **RESOLVED & VERIFIED (`PASS`)** |
| **FINDING-03** | `Dynamic Aggression` bị nhân hai lần (`search.cpp` nhân `dynamicAggression / 100` rồi `evaluate.cpp` tiếp tục nhân `std::clamp(aggressionPct, 50, 150) / 100`), gây biến dạng bậc hai (`50% -> 25%`, `150% -> 225%`). | Loại bỏ phép nhân trùng lặp tại `src/search.cpp:441-443`; giữ **một điểm nhân duy nhất** tại `Eval::scale_optimism_by_aggression()` trong `src/evaluate.cpp:57-63` với phép kẹp biên 64-bit `[50, 150]`. | **RESOLVED & VERIFIED (`PASS`)** |
| **FINDING-04** | Các script `build.sh`, `test.sh`, `benchmark.sh` trong V2 dùng pipeline `\| tee` trên `/bin/sh` (không có `pipefail`), làm mất mã lỗi khác `0` khi lệnh bên trái thất bại. | Thay thế toàn bộ `\| tee` bằng khối thực thi subshell POSIX `( set -eu; ... ) > "${LOG_FILE}" 2>&1; EXIT_CODE="$?"; cat "${LOG_FILE}"; exit "${EXIT_CODE}"` và kiểm chứng bằng bài test tiêm lỗi (`--inject-fault`). | **RESOLVED & VERIFIED (`PASS`)** |

## 2. Cấu Trúc Thư Mục Đóng Gói (`Stockfish-19-Pro-Ultimate-V3/`)

- `src/` — Mã nguồn C++17 của **Stockfish 19-Pro Ultimate V3** (`evaluate.h/cpp`, `search.h/cpp`, `learn.h/cpp`, `engine.h/cpp`, `Makefile`).
- `baseline_src/` — Mã nguồn C++17 của **Stockfish 19 gốc (Upstream Baseline)** dùng để biên dịch đối thủ chuẩn độc lập `benchmark/stockfish_19_baseline_x86`.
- `scripts/` — Chứa `scripts/net.sh` có kiểm tra SHA-256 (`1a298aa575a0...`) cho mạng NNUE `nn-1a298aa575a0.nnue`.
- `nnue/` — Chứa mạng NNUE chuẩn `nn-1a298aa575a0.nnue` (95,050,608 bytes).
- `experience/` — Chứa cơ sở dữ liệu kinh nghiệm `experience.bin` định dạng `SF19EXP2` (24 bytes/bản ghi, có checksum FNV-1a).
- `android/` — Chứa `build_android_v3.sh` (script cross-compile Android NDK cho `armv8` và `armv8-dotprod`) và `verify_android_v3.py` (trình kiểm định ELF64 AArch64, chống giả mạo SHA-256 và kiểm tra bảng chuỗi UCI Pro).
- `tests/` — Chứa `run_test_suite.py` và kết quả kiểm thử `test_suite_results.json` cùng các file log kiểm thử.
- `benchmark/` — Chứa `run_benchmark.py` (Fail-Closed 4-Group Benchmark Harness), `benchmark_results.json` và `tournament_games.pgn` (80 ván đấu đầy đủ).
- `build.sh`, `test.sh`, `benchmark.sh`, `verify_package.sh` — Bộ script POSIX bảo toàn mã thoát (`exit code`).
- Hồ sơ báo cáo kỹ thuật: `README.md`, `BUILD_REPORT.md`, `BUGFIX_REPORT.md`, `ANDROID_REPORT.md`, `STRENGTH_REPORT.md`, `REPRODUCIBILITY.md`, `CHANGELOG.md`, `SHA256SUMS.txt`.

## 3. Hướng Dẫn Sử Dụng Nhanh (Quick Start)

```sh
# 1. Giải nén gói sản phẩm
tar -xzf Stockfish-19-Pro-Ultimate-V3.tar.gz
cd Stockfish-19-Pro-Ultimate-V3

# 2. Biên dịch lại toàn bộ binary x86-64 (Release Candidate, ASan+UBSan, và Baseline độc lập)
JOBS=2 ./build.sh

# 3. Chạy bộ kiểm thử tự động 10 hạng mục (Perft, UCI, Dynamic Aggression, Fortress, Experience, ASan, Exit-Code)
./test.sh

# 4. Chạy giải đấu thực nghiệm 4 nhóm có kiểm tra SHA-256 đối thủ độc lập (Fail-Closed)
./benchmark.sh

# 5. Kiểm định tính toàn vẹn của gói sản phẩm và manifest SHA-256
./verify_package.sh
```

Để biên dịch binary Android ARM64 thực thụ trên máy có cài đặt **Android NDK r26+**:

```sh
export ANDROID_NDK_HOME=/path/to/android-ndk-r26d
JOBS=4 ./build.sh android-all
```
