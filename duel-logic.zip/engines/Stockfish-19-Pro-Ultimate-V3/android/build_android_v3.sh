#!/bin/sh
# ==============================================================================
# Stockfish 19-Pro Ultimate V3 — Android ARM64 Native Build Script (Fail-Closed)
# Builds two distinct CPU targets from V3 C++ source:
#   Target A (Compatibility): stockfish-19-pro-ultimate-v3-arm64         (ARCH=armv8)
#   Target B (DotProd):       stockfish-19-pro-ultimate-v3-arm64-dotprod (ARCH=armv8-dotprod)
# Never copies or renames pre-existing binaries. Fails closed (exit != 0) if
# the Android NDK / AArch64 C++ cross-compiler is not installed.
# ==============================================================================
set -eu

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SRC_DIR="${ROOT_DIR}/src"
TARGET_MODE="${1:-all}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"

# Detect Android NDK clang++, Termux native clang++ (on aarch64), or AArch64 cross-compiler
NDK_CXX="${CXX:-${COMPCXX:-}}"
if [ -z "${NDK_CXX}" ]; then
    for cand in \
        aarch64-linux-android29-clang++ \
        aarch64-linux-android28-clang++ \
        aarch64-linux-android30-clang++ \
        aarch64-linux-android31-clang++ \
        aarch64-linux-android33-clang++ \
        aarch64-linux-android34-clang++ \
        aarch64-linux-android-clang++ \
        aarch64-linux-gnu-g++; do
        if command -v "${cand}" >/dev/null 2>&1; then
            NDK_CXX="${cand}"
            break
        fi
    done
fi

# If running natively on an ARM64 Android/Termux device, use native clang++ or g++
HOST_ARCH_UNAME="$(uname -m 2>/dev/null || echo unknown)"
if [ -z "${NDK_CXX}" ] && { [ "${HOST_ARCH_UNAME}" = "aarch64" ] || [ "${HOST_ARCH_UNAME}" = "arm64" ]; }; then
    for cand in clang++ g++; do
        if command -v "${cand}" >/dev/null 2>&1; then
            NDK_CXX="${cand}"
            break
        fi
    done
fi

if [ -z "${NDK_CXX}" ] || ! command -v "${NDK_CXX}" >/dev/null 2>&1; then
    echo "[FAIL-CLOSED] Android ARM64 C++ cross-compiler (aarch64-linux-android29-clang++) not found in PATH." >&2
    echo "Host environment ($(uname -s) $(uname -m)) only has host x86_64 compiler and linker." >&2
    echo "Refusing to copy or rename any baseline binary (FINDING-01 guard)." >&2
    echo "To build on a machine with Android NDK r26+ installed:" >&2
    echo "  export PATH=\"\$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin:\$PATH\"" >&2
    echo "  JOBS=${JOBS} ./build.sh android-arm64" >&2
    exit 2
fi

COMP_TYPE="ndk"
case "${NDK_CXX}" in
    *gnu-g++*) COMP_TYPE="gcc" ;;
esac

build_one_target() {
    _sf_arch="$1"
    _out_bin="$2"
    echo "[ANDROID BUILD] Compiling ${_out_bin} from V3 source (ARCH=${_sf_arch}, COMP=${COMP_TYPE}, CXX=${NDK_CXX})..."
    make -C "${SRC_DIR}" clean
    COMPCXX="${NDK_CXX}" make -C "${SRC_DIR}" -j"${JOBS}" build ARCH="${_sf_arch}" COMP="${COMP_TYPE}" CXX="${NDK_CXX}" COMPCXX="${NDK_CXX}"
    cp -f "${SRC_DIR}/stockfish" "${ROOT_DIR}/${_out_bin}"
    chmod +x "${ROOT_DIR}/${_out_bin}"
    rm -f "${SRC_DIR}"/*.o
    python3 "${ROOT_DIR}/android/verify_android_v3.py" "${ROOT_DIR}/${_out_bin}"
}

if [ "${TARGET_MODE}" = "arm64" ] || [ "${TARGET_MODE}" = "android-arm64" ]; then
    build_one_target "armv8" "stockfish-19-pro-ultimate-v3-arm64"
elif [ "${TARGET_MODE}" = "dotprod" ] || [ "${TARGET_MODE}" = "android-arm64-dotprod" ]; then
    build_one_target "armv8-dotprod" "stockfish-19-pro-ultimate-v3-arm64-dotprod"
else
    build_one_target "armv8" "stockfish-19-pro-ultimate-v3-arm64"
    build_one_target "armv8-dotprod" "stockfish-19-pro-ultimate-v3-arm64-dotprod"
fi
