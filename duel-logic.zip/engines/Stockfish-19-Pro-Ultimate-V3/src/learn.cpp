/*
  Stockfish, a UCI chess playing engine derived from Glaurung 2.1
  Copyright (C) 2004-2026 The Stockfish developers (see AUTHORS file)

  Stockfish 19-Pro Ultimate V2 — Persistent Experience & Self-Learning System
*/

#include "learn.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <mutex>
#include <sstream>
#include <system_error>

#include "movegen.h"
#include "position.h"
#include "uci.h"

#if !defined(_WIN32)
    #include <unistd.h>
#endif

namespace Stockfish {

namespace {

constexpr char MagicHeaderV2[8] = {'S', 'F', '1', '9', 'E', 'X', 'P', '2'};
constexpr char MagicHeaderV1[8] = {'S', 'F', '1', '9', 'E', 'X', 'P', '1'};

inline u16 le16(u16 v) noexcept {
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return __builtin_bswap16(v);
#else
    return v;
#endif
}

inline i16 le16s(i16 v) noexcept {
    return static_cast<i16>(le16(static_cast<u16>(v)));
}

inline u32 le32(u32 v) noexcept {
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return __builtin_bswap32(v);
#else
    return v;
#endif
}

inline u64 le64(u64 v) noexcept {
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return __builtin_bswap64(v);
#else
    return v;
#endif
}

bool is_dir_writable(const std::filesystem::path& dir) noexcept {
    std::error_code       ec;
    std::filesystem::path d = dir.empty() ? std::filesystem::current_path(ec) : dir;
    if (ec || d.empty() || !std::filesystem::exists(d, ec) || !std::filesystem::is_directory(d, ec))
        return false;
#if !defined(_WIN32)
    return ::access(d.c_str(), W_OK) == 0;
#else
    return true;
#endif
}

// Match a PGN move token (either UCI like "e2e4"/"e7e8q" or SAN like "Nf3"/"exd5"/"O-O"/"b8=Q+")
Move parse_pgn_move_token(const Position& pos, std::string tok) noexcept {
    while (!tok.empty() && (tok.back() == '+' || tok.back() == '#' || tok.back() == '!' || tok.back() == '?'))
        tok.pop_back();
    if (tok.empty())
        return Move::none();

    // 1. Try direct UCI coordinate move first
    if (tok.size() >= 4 && tok.size() <= 5 && tok[0] >= 'a' && tok[0] <= 'h' && tok[1] >= '1'
        && tok[1] <= '8' && tok[2] >= 'a' && tok[2] <= 'h' && tok[3] >= '1' && tok[3] <= '8')
    {
        Move m = UCIEngine::to_move(pos, tok);
        if (m != Move::none())
            return m;
    }

    // 2. Handle castling SAN (O-O, 0-0, O-O-O, 0-0-0)
    if (tok == "O-O" || tok == "0-0" || tok == "O-O-O" || tok == "0-0-0")
    {
        const bool kingSide = (tok.size() == 3);
        for (const auto& m : MoveList<LEGAL>(pos))
        {
            if (m.type_of() == CASTLING)
            {
                const bool mKingSide = (file_of(m.to_sq()) > file_of(m.from_sq()));
                if (kingSide == mKingSide)
                    return m;
            }
        }
        return Move::none();
    }

    // 3. Parse standard SAN move
    PieceType promoPt = NO_PIECE_TYPE;
    if (auto eqPos = tok.find('='); eqPos != std::string::npos && eqPos + 1 < tok.size())
    {
        char pc = static_cast<char>(std::toupper(static_cast<unsigned char>(tok[eqPos + 1])));
        if (pc == 'Q')
            promoPt = QUEEN;
        else if (pc == 'R')
            promoPt = ROOK;
        else if (pc == 'B')
            promoPt = BISHOP;
        else if (pc == 'N')
            promoPt = KNIGHT;
        tok = tok.substr(0, eqPos);
    }

    if (tok.size() < 2)
        return Move::none();

    const char destFileChar = tok[tok.size() - 2];
    const char destRankChar = tok[tok.size() - 1];
    if (destFileChar < 'a' || destFileChar > 'h' || destRankChar < '1' || destRankChar > '8')
        return Move::none();

    const Square destSq = make_square(File(destFileChar - 'a'), Rank(destRankChar - '1'));
    std::string  prefix = tok.substr(0, tok.size() - 2);
    if (!prefix.empty() && prefix.back() == 'x')
        prefix.pop_back();

    PieceType movingPt = PAWN;
    if (!prefix.empty() && std::isupper(static_cast<unsigned char>(prefix[0])))
    {
        switch (prefix[0])
        {
        case 'N' :
            movingPt = KNIGHT;
            break;
        case 'B' :
            movingPt = BISHOP;
            break;
        case 'R' :
            movingPt = ROOK;
            break;
        case 'Q' :
            movingPt = QUEEN;
            break;
        case 'K' :
            movingPt = KING;
            break;
        default :
            return Move::none();
        }
        prefix.erase(prefix.begin());
    }

    int disambigFile = -1;
    int disambigRank = -1;
    for (char c : prefix)
    {
        if (c >= 'a' && c <= 'h')
            disambigFile = c - 'a';
        else if (c >= '1' && c <= '8')
            disambigRank = c - '1';
    }

    for (const auto& m : MoveList<LEGAL>(pos))
    {
        if (m.to_sq() != destSq)
            continue;
        if (type_of(pos.piece_on(m.from_sq())) != movingPt)
            continue;
        if (promoPt != NO_PIECE_TYPE)
        {
            if (m.type_of() != PROMOTION || m.promotion_type() != promoPt)
                continue;
        }
        else if (m.type_of() == PROMOTION)
            continue;

        if (disambigFile != -1 && int(file_of(m.from_sq())) != disambigFile)
            continue;
        if (disambigRank != -1 && int(rank_of(m.from_sq())) != disambigRank)
            continue;

        return m;
    }

    return Move::none();
}

}  // namespace

LearnManager GlobalLearn;

u32 LearnManager::compute_checksum(const ExpDiskEntry& e) noexcept {
    ExpDiskEntry canonical{};
    canonical.posKey     = le64(e.posKey);
    canonical.moveRaw    = le16(e.moveRaw);
    canonical.score      = le16s(e.score);
    canonical.tdScore    = le16s(e.tdScore);
    canonical.depth      = e.depth;
    canonical.winPerf    = e.winPerf;
    canonical.gamesCount = le32(e.gamesCount);
    canonical.checksum   = 0;

    const auto* bytes = reinterpret_cast<const unsigned char*>(&canonical);
    u32         hash  = 2166136261u;
    for (std::size_t i = 0; i < 20; ++i)
    {
        hash ^= static_cast<u32>(bytes[i]);
        hash *= 16777619u;
    }
    return hash == 0 ? 1u : hash;
}

bool LearnManager::validate_entry(const ExpDiskEntry& e, bool requireChecksum) noexcept {
    if (e.posKey == 0)
        return false;
    if (e.moveRaw == 0 || e.moveRaw == 65)  // Move::none() or Move::null()
        return false;
    Move m(e.moveRaw);
    if (!m.is_ok() || m.from_sq() == m.to_sq())
        return false;
    if (e.depth < 1 || e.depth > MAX_PLY)
        return false;
    if (e.score < -30000 || e.score > 30000)
        return false;
    if (e.tdScore < -30000 || e.tdScore > 30000)
        return false;
    if (e.winPerf > 200)
        return false;
    if (e.gamesCount == 0 || e.gamesCount > 10000000u)
        return false;
    if (requireChecksum && e.checksum == 0)
        return false;
    if (e.checksum != 0 && e.checksum != compute_checksum(e))
        return false;
    return true;
}

std::filesystem::path LearnManager::resolve_writable_path(const std::filesystem::path& requested,
                                                          const std::filesystem::path& binDir) noexcept {
    std::error_code ec;
    if (requested.empty())
        return {};

    const std::filesystem::path baseName = requested.filename().empty()
                                             ? std::filesystem::path("experience.bin")
                                             : requested.filename();

    if (requested.is_absolute())
    {
        if (std::filesystem::exists(requested, ec) || is_dir_writable(requested.parent_path()))
            return requested;
    }
    else
    {
        std::filesystem::path cwd = std::filesystem::current_path(ec);
        if (!ec && !cwd.empty() && std::filesystem::exists(cwd / requested, ec))
            return cwd / requested;

        if (!binDir.empty())
        {
            std::filesystem::path candidate = binDir / requested;
            if (std::filesystem::exists(candidate, ec) || is_dir_writable(candidate.parent_path()))
                return candidate;
        }

        if (!ec && !cwd.empty() && is_dir_writable((cwd / requested).parent_path()))
            return cwd / requested;
    }

    for (const char* envVar : {"STOCKFISH_EXP_DIR", "HOME", "TMPDIR"})
    {
        if (const char* val = std::getenv(envVar); val && *val)
        {
            std::filesystem::path dir(val);
            if (is_dir_writable(dir))
                return dir / baseName;
        }
    }

    return !binDir.empty() ? (binDir / requested) : requested;
}

LearnManager::~LearnManager() noexcept {
    if (isEnabled.load(std::memory_order_relaxed))
        finalize_game(100);
}

void LearnManager::init(const std::filesystem::path& expPath,
                        const std::filesystem::path& binDir,
                        bool                         enabledFlag) noexcept {
    isEnabled.store(enabledFlag, std::memory_order_relaxed);
    binaryDir = binDir;
    if (!expPath.empty())
        load_from_disk(expPath, binDir);
}

void LearnManager::clear() noexcept {
    std::unique_lock<std::shared_mutex> lk(mtx);
    table.clear();
    bloom_clear();
    trajectory.clear();
    hasEntries.store(false, std::memory_order_relaxed);
    adaptiveBonus[WHITE].store(0, std::memory_order_relaxed);
    adaptiveBonus[BLACK].store(0, std::memory_order_relaxed);
    corruptedSkipped = 0;
    dirty            = false;
}

bool LearnManager::load_from_disk(const std::filesystem::path& expPath,
                                  const std::filesystem::path& binDir) noexcept {
    std::unique_lock<std::shared_mutex> lk(mtx);
    if (!binDir.empty())
        binaryDir = binDir;

    currentPath      = resolve_writable_path(expPath, binaryDir);
    corruptedSkipped = 0;

    std::error_code ec;
    if (currentPath.empty() || !std::filesystem::exists(currentPath, ec)
        || !std::filesystem::is_regular_file(currentPath, ec))
    {
        table.clear();
    bloom_clear();
        hasEntries.store(false, std::memory_order_relaxed);
        dirty = false;
        return false;
    }

    const auto fileSize = std::filesystem::file_size(currentPath, ec);
    if (ec || fileSize < 16)
    {
        corruptedSkipped++;
        table.clear();
    bloom_clear();
        hasEntries.store(false, std::memory_order_relaxed);
        dirty = false;
        return false;
    }

    std::ifstream in(currentPath, std::ios::binary);
    if (!in.is_open())
        return false;

    char magic[8]{};
    if (!in.read(magic, 8))
    {
        corruptedSkipped++;
        table.clear();
    bloom_clear();
        hasEntries.store(false, std::memory_order_relaxed);
        dirty = false;
        return false;
    }

    const bool isV2 = (std::memcmp(magic, MagicHeaderV2, 8) == 0);
    const bool isV1 = (std::memcmp(magic, MagicHeaderV1, 8) == 0);
    if (!isV2 && !isV1)
    {
        corruptedSkipped++;
        table.clear();
    bloom_clear();
        hasEntries.store(false, std::memory_order_relaxed);
        dirty = false;
        return false;
    }

    u64 rawCount = 0;
    if (!in.read(reinterpret_cast<char*>(&rawCount), sizeof(u64)))
    {
        corruptedSkipped++;
        table.clear();
    bloom_clear();
        hasEntries.store(false, std::memory_order_relaxed);
        dirty = false;
        return false;
    }
    const u64 count         = le64(rawCount);
    const u64 maxByFileSize = (fileSize - 16) / sizeof(ExpDiskEntry);

    if ((fileSize - 16) % sizeof(ExpDiskEntry) != 0 || count != maxByFileSize)
        corruptedSkipped++;

    const u64 safeCount = std::min<u64>({count, maxByFileSize, u64(MAX_EXPERIENCE_ENTRIES)});

    table.clear();
    bloom_clear();
    table.reserve(static_cast<std::size_t>(std::min<u64>(safeCount, 65536ULL)));

    std::size_t loadedEntries = 0;
    for (u64 i = 0; i < safeCount; ++i)
    {
        ExpDiskEntry raw{};
        if (!in.read(reinterpret_cast<char*>(&raw), sizeof(ExpDiskEntry)))
        {
            corruptedSkipped++;
            break;
        }

        ExpDiskEntry e{};
        e.posKey     = le64(raw.posKey);
        e.moveRaw    = le16(raw.moveRaw);
        e.score      = le16s(raw.score);
        e.tdScore    = le16s(raw.tdScore);
        e.depth      = raw.depth;
        e.winPerf    = raw.winPerf;
        e.gamesCount = le32(raw.gamesCount);
        e.checksum   = le32(raw.checksum);

        if (!validate_entry(e, isV2))
        {
            corruptedSkipped++;
            continue;
        }

        e.checksum = compute_checksum(e);

        auto& vec   = table[e.posKey];
        bool  found = false;
        for (auto& existing : vec)
        {
            if (existing.moveRaw == e.moveRaw)
            {
                if (e.depth >= existing.depth)
                {
                    existing.score   = e.score;
                    existing.tdScore = e.tdScore;
                    existing.depth   = e.depth;
                    existing.winPerf = e.winPerf;
                }
                existing.gamesCount = std::min<u32>(10000000u, existing.gamesCount + e.gamesCount);
                existing.checksum   = compute_checksum(existing);
                found               = true;
                break;
            }
        }
        if (!found && loadedEntries < MAX_EXPERIENCE_ENTRIES)
        {
            vec.push_back(e);
            bloom_insert(e.posKey);
            loadedEntries++;
        }
    }

    hasEntries.store(!table.empty(), std::memory_order_relaxed);
    dirty = false;
    return true;
}

bool LearnManager::save_to_disk_locked() const noexcept {
    if (currentPath.empty())
        return false;

    std::error_code ec;
    const auto      parentDir = currentPath.parent_path();
    if (!parentDir.empty() && !is_dir_writable(parentDir))
        return false;

#if !defined(_WIN32)
    const std::string suffix = ".tmp." + std::to_string(::getpid());
#else
    const std::string suffix = ".tmp";
#endif
    const std::filesystem::path tmpPath = std::filesystem::path(currentPath.string() + suffix);

    {
        std::ofstream out(tmpPath, std::ios::binary | std::ios::trunc);
        if (!out.is_open())
            return false;

        out.write(MagicHeaderV2, 8);

        u64 totalEntries = 0;
        for (const auto& [k, vec] : table)
            totalEntries += vec.size();

        const u64 rawTotal = le64(totalEntries);
        out.write(reinterpret_cast<const char*>(&rawTotal), sizeof(u64));

        for (const auto& [k, vec] : table)
        {
            for (const auto& e : vec)
            {
                ExpDiskEntry raw{};
                raw.posKey     = le64(e.posKey);
                raw.moveRaw    = le16(e.moveRaw);
                raw.score      = le16s(e.score);
                raw.tdScore    = le16s(e.tdScore);
                raw.depth      = e.depth;
                raw.winPerf    = e.winPerf;
                raw.gamesCount = le32(e.gamesCount);
                raw.checksum   = le32(compute_checksum(e));
                out.write(reinterpret_cast<const char*>(&raw), sizeof(ExpDiskEntry));
            }
        }

        out.flush();
        if (!out.good())
        {
            out.close();
            std::filesystem::remove(tmpPath, ec);
            return false;
        }
    }

    std::filesystem::rename(tmpPath, currentPath, ec);
    if (ec)
    {
        std::filesystem::remove(tmpPath, ec);
        return false;
    }

    dirty = false;
    return true;
}

bool LearnManager::save_to_disk() const noexcept {
    std::unique_lock<std::shared_mutex> lk(mtx);
    return save_to_disk_locked();
}

std::optional<ExpDiskEntry> LearnManager::probe_move(Key posKey, Move m) const noexcept {
    if (!isEnabled.load(std::memory_order_relaxed) || !hasEntries.load(std::memory_order_relaxed)
        || !m.is_ok())
        return std::nullopt;

    std::shared_lock<std::shared_mutex> lk(mtx);
    auto                                it = table.find(posKey);
    if (it == table.end())
        return std::nullopt;

    const u16 raw = m.raw();
    for (const auto& e : it->second)
        if (e.moveRaw == raw)
            return e;

    return std::nullopt;
}

std::optional<ExpDiskEntry> LearnManager::probe_best(Key posKey, Depth minDepth) const noexcept {
    if (!isEnabled.load(std::memory_order_relaxed) || !hasEntries.load(std::memory_order_relaxed))
        return std::nullopt;

    std::shared_lock<std::shared_mutex> lk(mtx);
    auto                                it = table.find(posKey);
    if (it == table.end() || it->second.empty())
        return std::nullopt;

    std::optional<ExpDiskEntry> best          = std::nullopt;
    int                         bestComposite = -320000;
    for (const auto& e : it->second)
    {
        // Only select moves with proven high performance (winPerf >= 140) so drawn lines never lock in
        if (int(e.depth) < minDepth || e.tdScore < -155 || e.score < -155 || e.winPerf < 140)
            continue;
        int composite = int(e.score) + int(e.tdScore) + (int(e.winPerf) - 100) * 10 + int(e.depth) * 6;
        if (e.winPerf >= 180 && e.depth >= 24)
            composite += 5000;
        if (composite > bestComposite)
        {
            bestComposite = composite;
            best          = e;
        }
    }
    return best;
}

std::vector<ExpDiskEntry> LearnManager::probe_all(Key posKey) const noexcept {
    if (!isEnabled.load(std::memory_order_relaxed) || !hasEntries.load(std::memory_order_relaxed))
        return {};

    std::shared_lock<std::shared_mutex> lk(mtx);
    auto                                it = table.find(posKey);
    if (it == table.end())
        return {};
    return it->second;
}

void LearnManager::record_pv_line(const std::string&       rootFen,
                                  bool                     isChess960,
                                  int                      rootPly,
                                  const std::vector<Move>& pvMoves,
                                  Value                    rootScore,
                                  Depth                    completedDepth,
                                  int                      learningRatePct) noexcept {
    if (!isEnabled.load(std::memory_order_relaxed) || pvMoves.empty() || completedDepth < 12
        || rootPly > 120 || std::abs(int(rootScore)) >= 2000)
        return;

    Position              pos;
    std::deque<StateInfo> states(1);
    if (pos.set(rootFen, isChess960, &states.back()).has_value())
        return;

    std::unique_lock<std::shared_mutex> lk(mtx);
    const std::size_t maxSteps = std::min<std::size_t>(pvMoves.size(), 4);
    for (std::size_t k = 0; k < maxSteps; ++k)
    {
        const Depth stepDepth = Depth(int(completedDepth) - int(k));
        if (stepDepth < 10)
            break;
        const Move m = pvMoves[k];
        if (!m.is_ok() || m == Move::none() || m == Move::null() || !MoveList<LEGAL>(pos).contains(m))
            break;
        const Value stepScore = (k % 2 == 0) ? rootScore : -rootScore;
        update_entry_locked(pos.key(), m, stepScore, stepScore, stepDepth, learningRatePct, false);
        states.emplace_back();
        pos.do_move(m, states.back());
    }
}

void LearnManager::update_entry_locked(Key   posKey,
                                       Move  m,
                                       Value score,
                                       Value tdTarget,
                                       Depth depth,
                                       int   lrPct,
                                       bool  incrementGame) noexcept {
    if (posKey == 0 || !m.is_ok() || m == Move::none() || m == Move::null()
        || m.from_sq() == m.to_sq() || depth < 1)
        return;

    const i16 clampedScore = static_cast<i16>(std::clamp(int(score), -30000, 30000));
    const i16 clampedTD    = static_cast<i16>(std::clamp(int(tdTarget), -30000, 30000));
    const u8  clampedDepth = static_cast<u8>(std::clamp(int(depth), 1, int(MAX_PLY)));
    const int alpha        = std::clamp(lrPct * 32 / 100, 8, 96);  // out of 128

    auto& vec = table[posKey];
    for (auto& e : vec)
    {
        if (e.moveRaw == m.raw())
        {
            if (incrementGame && e.gamesCount < 10000000u)
                e.gamesCount++;
            // Protect verified Killer/Fortress Book entries (winPerf >= 180 && depth >= 24)
            // from being diluted by shallow in-game search updates; only downgrade if refuted (clampedTD <= -220).
            if (e.winPerf >= 180 && e.depth >= 24)
            {
                if (clampedTD <= -220 && incrementGame)
                {
                    e.winPerf = 35;
                    e.tdScore = clampedTD;
                }
                e.checksum = compute_checksum(e);
                dirty      = true;
                hasEntries.store(true, std::memory_order_relaxed);
                return;
            }
            const int decayedOldTD = int(e.tdScore) * 31 / 32;
            if (clampedDepth >= e.depth)
            {
                e.score   = clampedScore;
                e.depth   = clampedDepth;
                e.tdScore = static_cast<i16>(
                  std::clamp((decayedOldTD * (128 - alpha) + int(clampedTD) * alpha) / 128, -30000, 30000));
            }
            else if (incrementGame)
            {
                const int softAlpha = std::max(16, alpha / 2);
                e.tdScore = static_cast<i16>(
                  std::clamp((decayedOldTD * (128 - softAlpha) + int(clampedTD) * softAlpha) / 128, -30000, 30000));
            }
            if (incrementGame)
            {
                if (clampedTD >= 280)
                {
                    e.winPerf = static_cast<u8>(std::max<int>(e.winPerf, 192));
                    e.depth   = static_cast<u8>(std::max<int>(e.depth, 26));
                }
                else if (clampedTD <= -220)
                {
                    e.winPerf = static_cast<u8>(std::min<int>(e.winPerf, 25));
                }
                else
                {
                    int perfTarget = std::clamp(108 + int(e.tdScore) / 12, 45, 165);
                    e.winPerf      = static_cast<u8>((int(e.winPerf) * 3 + perfTarget) / 4);
                }
            }
            e.checksum     = compute_checksum(e);
            dirty          = true;
            hasEntries.store(true, std::memory_order_relaxed);
            return;
        }
    }

    u8 maxExistingDepth = 0;
    for (const auto& existing : vec)
        maxExistingDepth = std::max(maxExistingDepth, existing.depth);
    if (maxExistingDepth >= 20 && clampedDepth + 2 < maxExistingDepth)
        return;

    if (table.size() >= MAX_EXPERIENCE_ENTRIES)
        return;

    int          perfInit = std::clamp(100 + int(clampedTD) / 15, 5, 195);
    ExpDiskEntry newEntry{posKey, m.raw(), clampedScore, clampedTD, clampedDepth,
                          static_cast<u8>(perfInit), 1u, 0u};
    newEntry.checksum = compute_checksum(newEntry);
    vec.push_back(newEntry);
    bloom_insert(posKey);
    dirty = true;
    hasEntries.store(true, std::memory_order_relaxed);
}

void LearnManager::flush_trajectory_locked(int                lrPct,
                                           std::optional<int> whiteOutcome) noexcept {
    if (trajectory.empty())
        return;

    if (!whiteOutcome.has_value())
    {
        // True TD-Lambda Trajectory Bootstrapping on standard UCI games:
        // Propagate the terminal middlegame/endgame evaluation backward to opening choices,
        // applying an anti-stagnation exploration penalty (-6 cp) when a trajectory fizzles into a flat draw
        // so the engine dynamically rotates opening branches across consecutive games.
        const auto& lastStep      = trajectory.back();
        Value       runningTarget = lastStep.score;
        if (trajectory.size() >= 6 && std::abs(int(runningTarget)) <= 12)
            runningTarget = Value(-6);  // Nudge sterile draw lines down so alternative branches get explored
        Color runningSide = lastStep.side;

        for (int i = int(trajectory.size()) - 1; i >= 0; --i)
        {
            const auto& step    = trajectory[std::size_t(i)];
            Value       aligned = (step.side == runningSide) ? runningTarget : -runningTarget;
            Value       blended = std::clamp(Value((int(aligned) * 55 + int(step.score) * 45) / 100), Value(-200), Value(200));
            if (step.ply <= 120)
                update_entry_locked(step.posKey, step.move, step.score, blended, step.depth, lrPct, true);
            runningTarget = Value(int(blended) * 94 / 100);
            runningSide   = step.side;
        }
        trajectory.clear();
        return;
    }

    const int res = std::clamp(*whiteOutcome, -1, 1);
    int rewardMag = 320;

    for (int i = int(trajectory.size()) - 1; i >= 0; --i)
    {
        const auto& step        = trajectory[std::size_t(i)];
        const int   sideOutcome = (step.side == WHITE) ? res : -res;
        Value       tdTarget    = step.score;
        if (sideOutcome > 0)
            tdTarget = Value(std::max<int>(int(step.score), rewardMag));
        else if (sideOutcome < 0)
            tdTarget = Value(std::min<int>(int(step.score), -rewardMag));
        else
            tdTarget = Value(-18);  // Draw penalty nudges next cycle to explore sharper winning alternatives
        update_entry_locked(step.posKey, step.move, step.score, tdTarget, step.depth, lrPct, true);
        rewardMag = std::max(230, rewardMag * 98 / 100);
    }

    trajectory.clear();
}

void LearnManager::record_step(Key   posKey,
                               Color side,
                               int   ply,
                               Move  bestMove,
                               Value score,
                               Depth depth,
                               int   learningRatePct) noexcept {
    if (!isEnabled.load(std::memory_order_relaxed) || !bestMove.is_ok()
        || bestMove == Move::none() || bestMove == Move::null() || depth < 6 || ply > 150
        || std::abs(int(score)) >= VALUE_TB_WIN_IN_MAX_PLY)
        return;

    std::unique_lock<std::shared_mutex> lk(mtx);

    if (!trajectory.empty())
    {
        const auto& last = trajectory.back();
        if (last.posKey == posKey && last.ply == ply && last.side == side)
        {
            if (depth >= last.depth)
                trajectory.back() = TrajectoryStep{posKey, side, ply, bestMove, score, depth};
            return;
        }

        if (ply < last.ply)
        {
            flush_trajectory_locked(learningRatePct, std::nullopt);
            adaptiveBonus[WHITE].store(0, std::memory_order_relaxed);
            adaptiveBonus[BLACK].store(0, std::memory_order_relaxed);
        }
    }

    for (int i = int(trajectory.size()) - 1; i >= 0; --i)
    {
        if (trajectory[std::size_t(i)].side == side)
        {
            int gain = int(score) - int(trajectory[std::size_t(i)].score);
            int cur  = adaptiveBonus[side].load(std::memory_order_relaxed);
            if (gain > 60)
                adaptiveBonus[side].store(std::clamp(cur + 3, -8, 8), std::memory_order_relaxed);
            else if (gain < -60)
                adaptiveBonus[side].store(std::clamp(cur - 3, -8, 8), std::memory_order_relaxed);
            break;
        }
    }

    trajectory.push_back(TrajectoryStep{posKey, side, ply, bestMove, score, depth});
}

void LearnManager::finalize_game(int learningRatePct, std::optional<int> whiteOutcome) noexcept {
    std::unique_lock<std::shared_mutex> lk(mtx);

    flush_trajectory_locked(learningRatePct, whiteOutcome);

    adaptiveBonus[WHITE].store(0, std::memory_order_relaxed);
    adaptiveBonus[BLACK].store(0, std::memory_order_relaxed);
    reset_time_bank(800);

    if (dirty)
        save_to_disk_locked();
}


std::size_t LearnManager::inject_uci_line(char                            targetColor,
                                          Depth                           depth,
                                          u8                              winPerf,
                                          Value                           score,
                                          u32                             gamesCount,
                                          const std::vector<std::string>& uciMoves,
                                          int                             startPly,
                                          int                             endPly) noexcept {
    if (uciMoves.empty())
        return 0;

    Position              pos;
    std::deque<StateInfo> states(1);
    pos.set("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", false, &states.back());

    std::unique_lock<std::shared_mutex> lk(mtx);
    std::size_t                         injected = 0;

    for (int ply = 0; ply < int(uciMoves.size()) && ply <= endPly; ++ply)
    {
        const std::string& uci = uciMoves[std::size_t(ply)];
        Move               matched = Move::none();
        for (const auto& m : MoveList<LEGAL>(pos))
        {
            if (UCIEngine::move(m, false) == uci)
            {
                matched = m;
                break;
            }
        }
        if (matched == Move::none())
            break;

        const Color side = pos.side_to_move();
        const bool  want = (targetColor == 'A') || (targetColor == 'W' && side == WHITE)
                        || (targetColor == 'B' && side == BLACK);
        if (want && ply >= startPly)
        {
            const Key posKey       = pos.key();
            const i16 clampedScore = static_cast<i16>(std::clamp(int(score), -30000, 30000));
            const u8  clampedDepth = static_cast<u8>(std::clamp(int(depth), 1, int(MAX_PLY)));
            const u8  clampedPerf  = static_cast<u8>(std::clamp(int(winPerf), 0, 200));
            const u32 clampedGames = std::max<u32>(1u, gamesCount);

            auto& vec   = table[posKey];
            bool  found = false;
            for (auto& e : vec)
            {
                if (e.moveRaw == matched.raw())
                {
                    e.score      = clampedScore;
                    e.tdScore    = clampedScore;
                    e.depth      = clampedDepth;
                    e.winPerf    = clampedPerf;
                    e.gamesCount = std::max(e.gamesCount, clampedGames);
                    e.checksum   = compute_checksum(e);
                    found        = true;
                    break;
                }
            }
            if (!found && table.size() < MAX_EXPERIENCE_ENTRIES)
            {
                ExpDiskEntry ne{posKey, matched.raw(), clampedScore, clampedScore,
                                clampedDepth, clampedPerf, clampedGames, 0u};
                ne.checksum = compute_checksum(ne);
                vec.push_back(ne);
                bloom_insert(posKey);
            }
            dirty = true;
            hasEntries.store(true, std::memory_order_relaxed);
            injected++;
        }

        states.emplace_back();
        pos.do_move(matched, states.back());
    }

    if (dirty)
        save_to_disk_locked();
    return injected;
}

void LearnManager::record_outcome(int whiteOutcome, int learningRatePct) noexcept {
    finalize_game(learningRatePct, whiteOutcome);
}

std::size_t LearnManager::ingest_pgn_file(const std::filesystem::path& pgnPath,
                                          bool                         isChess960,
                                          int                          learningRatePct) noexcept {
    std::ifstream in(pgnPath);
    if (!in.is_open())
        return 0;

    std::unique_lock<std::shared_mutex> lk(mtx);
    std::size_t                         gamesIngested = 0;

    std::string              line;
    std::string              fenStr;
    int                      whiteOutcome = 0;
    bool                     hasResult    = false;
    std::vector<std::string> moveTokens;

    auto process_game = [&]() {
        if (moveTokens.empty() || !hasResult)
            return;

        Position                  pos;
        std::deque<StateInfo>     states(1);
        const std::string         startFen = fenStr.empty()
                                               ? "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
                                               : fenStr;
        if (pos.set(startFen, isChess960, &states.back()).has_value())
            return;

        struct PgnStep {
            Key   posKey;
            Color side;
            Move  move;
            int   ply;
        };
        std::vector<PgnStep> steps;
        int                  ply = 0;

        for (const auto& tok : moveTokens)
        {
            if (ply >= 18)
                break;
            Move m = parse_pgn_move_token(pos, tok);
            if (m == Move::none())
                break;
            steps.push_back(PgnStep{pos.key(), pos.side_to_move(), m, ply});
            states.emplace_back();
            pos.do_move(m, states.back());
            ply++;
        }

        if (steps.empty())
            return;

        // Backward outcome-based RL pass from game result with perspective handling
        for (int i = int(steps.size()) - 1; i >= 0; --i)
        {
            const auto& st         = steps[std::size_t(i)];
            const int   sideSign   = (st.side == WHITE) ? 1 : -1;
            const int   rawReward  = whiteOutcome * sideSign * 180;
            // Discount gently from ply 32 back toward opening
            const int   discounted = rawReward * (40 - std::min(st.ply, 32)) / 40;
            update_entry_locked(st.posKey, st.move, Value(discounted), Value(discounted), Depth(6),
                                learningRatePct, true);
        }
        gamesIngested++;
    };

    bool inComment = false;
    while (std::getline(in, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();

        if (!inComment && !line.empty() && line[0] == '[')
        {
            if (!moveTokens.empty())
            {
                process_game();
                moveTokens.clear();
                fenStr.clear();
                whiteOutcome = 0;
                hasResult    = false;
            }
            if (line.rfind("[Result \"", 0) == 0)
            {
                if (line.find("1-0") != std::string::npos)
                {
                    whiteOutcome = 1;
                    hasResult    = true;
                }
                else if (line.find("0-1") != std::string::npos)
                {
                    whiteOutcome = -1;
                    hasResult    = true;
                }
                else if (line.find("1/2-1/2") != std::string::npos)
                {
                    whiteOutcome = 0;
                    hasResult    = true;
                }
            }
            else if (line.rfind("[FEN \"", 0) == 0)
            {
                auto q1 = line.find('"');
                auto q2 = line.rfind('"');
                if (q1 != std::string::npos && q2 != std::string::npos && q2 > q1 + 1)
                    fenStr = line.substr(q1 + 1, q2 - q1 - 1);
            }
            continue;
        }

        // Strip {...} comments and ; end-of-line comments
        std::string cleaned;
        for (std::size_t i = 0; i < line.size(); ++i)
        {
            if (inComment)
            {
                if (line[i] == '}')
                    inComment = false;
            }
            else if (line[i] == '{')
            {
                inComment = true;
            }
            else if (line[i] == ';')
            {
                break;
            }
            else
            {
                cleaned.push_back(line[i]);
            }
        }

        std::istringstream iss(cleaned);
        std::string        tok;
        while (iss >> tok)
        {
            if (tok == "1-0")
            {
                whiteOutcome = 1;
                hasResult    = true;
                continue;
            }
            if (tok == "0-1")
            {
                whiteOutcome = -1;
                hasResult    = true;
                continue;
            }
            if (tok == "1/2-1/2")
            {
                whiteOutcome = 0;
                hasResult    = true;
                continue;
            }
            if (tok == "*")
                continue;

            // Strip leading move numbers like "1." or "12..."
            if (auto dotPos = tok.rfind('.'); dotPos != std::string::npos)
            {
                if (dotPos + 1 < tok.size())
                    tok = tok.substr(dotPos + 1);
                else
                    continue;
            }
            if (!tok.empty() && tok[0] != '$')
                moveTokens.push_back(tok);
        }
    }

    if (!moveTokens.empty())
        process_game();

    if (dirty)
        save_to_disk_locked();

    return gamesIngested;
}

int LearnManager::get_adaptive_optimism_bonus(Color us) const noexcept {
    if (!isEnabled.load(std::memory_order_relaxed))
        return 0;
    return adaptiveBonus[us].load(std::memory_order_relaxed);
}

std::string LearnManager::summary_info() const {
    std::shared_lock<std::shared_mutex> lk(mtx);
    u64                                 totalMoves = 0;
    for (const auto& [k, vec] : table)
        totalMoves += vec.size();
    std::ostringstream oss;
    oss << "Experience database (" << currentPath.string() << "): " << table.size()
        << " positions, " << totalMoves << " learned moves (corrupted skipped: "
        << corruptedSkipped << ").";
    return oss.str();
}

}  // namespace Stockfish
