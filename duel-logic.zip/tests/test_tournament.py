#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BỘ KIỂM THỬ TỰ ĐỘNG TOÀN DIỆN — STOCKFISH ULTIMATE DUEL
=======================================================
Bao phủ toàn bộ 14 hạng mục kiểm thử bắt buộc tại Mục 13:
  1. Kiểm tra cú pháp Python (AST / py_compile).
  2. Kiểm tra cú pháp YAML (.github/workflows/stockfish-ultimate-duel.yml).
  3. Kiểm tra cấu hình workflow_dispatch (inputs, defaults, ubuntu-24.04-arm, artifact, if: always()).
  4. Kiểm tra lựa chọn thời gian 1–6 giờ.
  5. Kiểm tra logic chia chặng 3 giờ + phần còn lại (1-3h: 1 chặng; 4-6h: 2 chặng).
  6. Kiểm tra resume giữa 2 chặng bằng engine UCI thực tế / mock UCI.
  7. Kiểm tra không đếm trùng trận khi resume (khử bản ghi dở dang).
  8. Kiểm tra luân phiên màu và tính đối xứng khai cuộc (30 khai cuộc Standard Chess hợp lệ).
  9. Kiểm tra công thức tính điểm, Elo Difference, 95% CI và cảnh báo mẫu nhỏ.
  10. Kiểm tra PGN builder và PGN parser (chess.pgn.read_game).
  11. Kiểm tra định dạng CSV và JSONL.
  12. Kiểm tra xử lý engine crash, timeout, illegal move (Forfeiture) và giới hạn Max Ply (Technical Stop).
  13. Kiểm tra định dạng log tiếng Việt và heartbeat bằng dữ liệu fixture.
  14. Kiểm tra lưu checkpoint nguyên tử.
"""

from __future__ import annotations

import csv
import json
import os
import py_compile
import shutil
import stat
import sys
import tempfile
import textwrap
import unittest

import chess
import chess.pgn
import yaml

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SCRIPTS_DIR = os.path.join(REPO_ROOT, "scripts")
if SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)

import tournament  # noqa: E402


class TestStockfishUltimateDuel(unittest.TestCase):
    """Kiểm thử Unit Tests & Integration Tests cho hệ thống Stockfish Ultimate Duel."""

    def test_01_python_syntax_validation(self) -> None:
        """1. Kiểm tra cú pháp Python của toàn bộ các tệp .py trong dự án."""
        py_files = [
            os.path.join(REPO_ROOT, "scripts", "tournament.py"),
            os.path.join(REPO_ROOT, "tests", "test_tournament.py"),
        ]
        for path in py_files:
            self.assertTrue(os.path.isfile(path), f"Thiếu tệp Python: {path}")
            py_compile.compile(path, doraise=True)

    def test_02_yaml_syntax_and_workflow_dispatch(self) -> None:
        """2 & 3. Kiểm tra cú pháp YAML, workflow_dispatch, dropdown 1-6h, runner ubuntu-24.04-arm và artifact."""
        wf_path = os.path.join(REPO_ROOT, ".github", "workflows", "stockfish-ultimate-duel.yml")
        self.assertTrue(os.path.isfile(wf_path), f"Thiếu tệp workflow: {wf_path}")
        with open(wf_path, "r", encoding="utf-8") as f:
            wf = yaml.safe_load(f)

        self.assertEqual(wf.get("name"), "Stockfish Ultimate Duel")
        # Trong PyYAML, khóa 'on' có thể được parse thành True hoặc 'on'
        on_block = wf.get("on") or wf.get(True)
        self.assertIsNotNone(on_block, "Thiếu khối trigger 'on' trong workflow")
        self.assertIn("workflow_dispatch", on_block)

        inputs = on_block["workflow_dispatch"]["inputs"]
        self.assertIn("duration", inputs)
        self.assertIn("move_time", inputs)
        self.assertIn("hash", inputs)

        self.assertEqual(inputs["duration"]["type"], "choice")
        self.assertEqual(inputs["duration"]["default"], "1 Hour")
        self.assertEqual(
            inputs["duration"]["options"],
            ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "6 Hours"],
        )

        self.assertEqual(inputs["move_time"]["type"], "choice")
        self.assertEqual(inputs["move_time"]["default"], "200 ms")
        self.assertEqual(inputs["move_time"]["options"], ["100 ms", "200 ms", "500 ms"])

        self.assertEqual(inputs["hash"]["type"], "choice")
        self.assertEqual(inputs["hash"]["default"], "256 MB")
        self.assertEqual(inputs["hash"]["options"], ["128 MB", "256 MB", "512 MB"])

        jobs = wf["jobs"]
        self.assertIn("stage1_tournament", jobs)
        self.assertIn("stage2_tournament", jobs)
        self.assertEqual(jobs["stage1_tournament"]["runs-on"], "ubuntu-24.04-arm")
        self.assertEqual(jobs["stage2_tournament"]["runs-on"], "ubuntu-24.04-arm")

        # Kiểm tra artifact Stockfish-Ultimate-Duel-Results và retention-days: 30
        s2_steps = jobs["stage2_tournament"]["steps"]
        upload_steps = [s for s in s2_steps if s.get("uses", "").startswith("actions/upload-artifact")]
        self.assertTrue(upload_steps, "Thiếu bước upload-artifact ở Stage 2")
        self.assertEqual(upload_steps[0]["with"]["name"], "Stockfish-Ultimate-Duel-Results")
        self.assertEqual(upload_steps[0]["with"]["retention-days"], 30)
        self.assertIn("always()", str(upload_steps[0].get("if", "")))

    def test_03_duration_choices_and_stage_split_logic(self) -> None:
        """4 & 5. Kiểm tra lựa chọn 1–6 giờ và logic chia chặng (1-3h: 1 chặng; 4-6h: 3h + phần còn lại)."""
        for h in range(1, 7):
            label = f"{h} Hour" if h == 1 else f"{h} Hours"
            self.assertEqual(tournament.parse_duration_hours(label), h)
            self.assertEqual(tournament.parse_duration_hours(str(h)), h)
            plan = tournament.compute_stage_plan(h)
            self.assertEqual(plan["total_seconds"], h * 3600)
            if h <= 3:
                self.assertFalse(plan["needs_stage2"])
                self.assertEqual(plan["stage1_hours"], h)
                self.assertEqual(plan["stage2_hours"], 0)
            else:
                self.assertTrue(plan["needs_stage2"])
                self.assertEqual(plan["stage1_hours"], 3)
                self.assertEqual(plan["stage2_hours"], h - 3)
                self.assertEqual(plan["stage1_seconds"] + plan["stage2_seconds"], h * 3600)

        with self.assertRaises(ValueError):
            tournament.parse_duration_hours("0 Hours")
        with self.assertRaises(ValueError):
            tournament.parse_duration_hours("7 Hours")

    def test_04_opening_book_validity_and_color_alternation(self) -> None:
        """8. Kiểm tra toàn bộ 30 khai cuộc hợp lệ và luân phiên màu đối xứng theo cặp."""
        self.assertGreaterEqual(len(tournament.STANDARD_OPENINGS), 20)
        for name, uci_moves in tournament.STANDARD_OPENINGS:
            board = chess.Board()
            for mv_str in uci_moves:
                mv = chess.Move.from_uci(mv_str)
                self.assertIn(mv, board.legal_moves, f"Nước đi {mv_str} trong khai cuộc {name} không hợp lệ")
                board.push(mv)

        seed = 20261109
        for pair_idx in range(15):
            g1 = pair_idx * 2 + 1
            g2 = pair_idx * 2 + 2
            op1, moves1, pro_white1 = tournament.get_opening_for_game(g1, seed)
            op2, moves2, pro_white2 = tournament.get_opening_for_game(g2, seed)
            self.assertEqual(op1, op2, "Hai ván trong cùng một cặp phải dùng chung khai cuộc")
            self.assertEqual(moves1, moves2)
            self.assertTrue(pro_white1, "Ván lẻ Pro phải cầm Trắng")
            self.assertFalse(pro_white2, "Ván chẵn Pro phải cầm Đen (Universal cầm Trắng)")

    def test_05_chess_terminations_and_max_ply_safety(self) -> None:
        """Kiểm tra nhận diện Checkmate, Stalemate, Insufficient material, 50-move, Threefold và Max Ply."""
        # Fool's Mate -> Checkmate
        board = chess.Board()
        for uci in ["f2f3", "e7e5", "g2g4", "d8h4"]:
            board.push_uci(uci)
        term = tournament.evaluate_board_termination(board, max_ply=400)
        self.assertEqual(term, ("0-1", "Checkmate", False))

        # Stalemate
        stale_board = chess.Board("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")
        self.assertEqual(
            tournament.evaluate_board_termination(stale_board, max_ply=400),
            ("1/2-1/2", "Stalemate", False),
        )

        # Insufficient material (K vs K)
        insuff_board = chess.Board("8/8/4k3/8/8/4K3/8/8 w - - 0 1")
        self.assertEqual(
            tournament.evaluate_board_termination(insuff_board, max_ply=400),
            ("1/2-1/2", "Insufficient material", False),
        )

        # Threefold repetition
        rep_board = chess.Board()
        for _ in range(2):
            for uci in ["g1f3", "g8f6", "f3g1", "f6g8"]:
                rep_board.push_uci(uci)
        self.assertEqual(
            tournament.evaluate_board_termination(rep_board, max_ply=400),
            ("1/2-1/2", "Threefold repetition", False),
        )

        # Safety Max Ply -> Technical Stop (không được giả vờ là hòa theo luật)
        ply_board = chess.Board()
        for uci in ["e2e4", "e7e5", "g1f3", "b8c6"]:
            ply_board.push_uci(uci)
        tech_term = tournament.evaluate_board_termination(ply_board, max_ply=4)
        self.assertIsNotNone(tech_term)
        assert tech_term is not None
        self.assertEqual(tech_term[0], "*")
        self.assertTrue(tech_term[2], "Max ply phải được đánh dấu là Technical Stop")

    def test_06_scoring_elo_and_small_sample_warning(self) -> None:
        """9. Kiểm tra tính điểm, Elo Difference và cảnh báo mẫu nhỏ."""
        stats_example = tournament.compute_elo_and_statistics(
            pro_wins=120,
            uni_wins=100,
            draws=1030,
            technical_stops=0,
            pro_white_wdl=[70, 510, 45],
            pro_black_wdl=[50, 520, 55],
        )
        self.assertEqual(stats_example["total_games"], 1250)
        self.assertAlmostEqual(stats_example["pro"]["score_percent"], 50.8, places=2)
        self.assertAlmostEqual(stats_example["universal"]["score_percent"], 49.2, places=2)
        self.assertEqual(stats_example["decisive_games"], 220)
        self.assertFalse(stats_example["elo"]["small_sample_warning"])
        self.assertAlmostEqual(stats_example["elo"]["pro_minus_universal_elo"], 5.56, places=1)

        # Mẫu nhỏ (10 ván) -> bắt buộc bật cảnh báo small_sample_warning
        small_stats = tournament.compute_elo_and_statistics(pro_wins=4, uni_wins=2, draws=4)
        self.assertTrue(small_stats["elo"]["small_sample_warning"])
        self.assertIn("CẢNH BÁO MẪU NHỎ", small_stats["conclusion"])

    def test_07_fixture_log_pgn_csv_jsonl_formatting(self) -> None:
        """10, 11 & 13. Kiểm tra log tiếng Việt, heartbeat, PGN parser bằng dữ liệu fixture."""
        rec_draw = tournament.MatchRecord(
            Game_ID=1,
            Date="2026-11-09",
            White=tournament.ENGINE_PRO_NAME,
            Black=tournament.ENGINE_UNI_NAME,
            Result="1/2-1/2",
            Winner="Draw",
            Termination="Threefold repetition",
            Opening="Italian Game: Giuoco Piano",
            Ply_Count=8,
            Duration="00:00:02",
            Duration_Seconds=2.0,
            Move_Time_Ms=100,
            Hash_MB=128,
            Error="",
            Is_Technical_Stop=False,
            Is_Forfeiture=False,
            Moves_UCI=["e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "f8c5", "c2c3", "g8f6"],
            Moves_SAN=["e4", "e5", "Nf3", "Nc6", "Bc4", "Bc5", "c3", "Nf6"],
        )
        log_text = tournament.format_match_console_log(rec_draw)
        self.assertIn("Trận 000001: HÒA", log_text)
        self.assertIn("Pro (Trắng) vs Universal (Đen)", log_text)
        self.assertIn("Kết quả: 1/2-1/2", log_text)
        self.assertIn("Số nước: 8 ply", log_text)
        self.assertIn("Lý do: Threefold repetition", log_text)

        hb = tournament.format_heartbeat_line(5130, 7200, 347, 24, 19, 304)
        self.assertEqual(
            hb,
            "[TIME] 01:25:30 / 02:00:00 [TOTAL GAMES] 347 [PRO WINS] 24 [UNIVERSAL WINS] 19 [DRAWS] 304 [DECISIVE GAMES] 43",
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            pgn_path = os.path.join(tmpdir, "test.pgn")
            pgn_str = tournament.build_pgn_string(rec_draw)
            tournament.atomic_write_text(pgn_path, pgn_str)
            parsed = tournament.parse_pgn_and_verify_stats(pgn_path)
            self.assertEqual(parsed["total_games"], 1)
            self.assertEqual(parsed["draws"], 1)

    def _create_mock_uci_engine(self, directory: str, filename: str, mode: str = "normal", is_pro: bool = False) -> str:
        """Tạo một UCI engine script giả lập để kiểm thử crash, illegal move và resume."""
        path = os.path.join(directory, filename)
        pro_options_block = ""
        if is_pro:
            pro_options_block = textwrap.dedent("""\
                print("option name Optimism Bias type spin default 0 min -100 max 100", flush=True)
                print("option name Dynamic Aggression type spin default 100 min 50 max 200", flush=True)
                print("option name Fortress Detection type check default false", flush=True)
                print("option name Deep Scaler Mode type check default false", flush=True)
                print("option name Experience Enabled type check default true", flush=True)
                print("option name Experience File type string default experience.bin", flush=True)
                print("option name Experience Book type check default true", flush=True)
                print("option name Experience Learning Rate type spin default 100 min 10 max 300", flush=True)
                print("option name Adaptive Opponent Mode type check default true", flush=True)
            """)
        script = f"""#!/usr/bin/env python3
import sys
import chess

board = chess.Board()
mode = {mode!r}
is_pro = {is_pro!r}
move_calls = 0

for raw in sys.stdin:
    line = raw.strip()
    if line == "uci":
        print("id name " + ("Stockfish 19-Pro" if is_pro else "Stockfish 19"), flush=True)
        print("id author Mock Author", flush=True)
        print("option name Threads type spin default 1 min 1 max 1024", flush=True)
        print("option name Hash type spin default 16 min 1 max 33554432", flush=True)
        print("option name Ponder type check default false", flush=True)
        print("option name UCI_Chess960 type check default false", flush=True)
        print("option name EvalFile type string default nn-1a298aa575a0.nnue", flush=True)
{textwrap.indent(pro_options_block, '        ')}
        print("uciok", flush=True)
    elif line == "isready":
        print("readyok", flush=True)
    elif line == "expinfo":
        print("info string Experience entries: 128", flush=True)
    elif line.startswith("position "):
        board = chess.Board()
        if " moves " in line:
            moves_part = line.split(" moves ", 1)[1].strip().split()
            for mv in moves_part:
                board.push_uci(mv)
    elif line.startswith("go"):
        move_calls += 1
        print("info string NNUE evaluation using nn-1a298aa575a0.nnue", flush=True)
        if mode == "crash" and move_calls >= 1:
            sys.exit(139)
        if mode == "illegal" and move_calls >= 1:
            print("bestmove e2e9", flush=True)
            continue
        legal = list(board.legal_moves)
        chosen = legal[0].uci() if legal else "0000"
        print(f"bestmove {{chosen}}", flush=True)
    elif line == "quit":
        break
"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(script)
        os.chmod(path, os.stat(path).st_mode | stat.S_IEXEC)
        return path

    def test_08_crash_and_illegal_move_forfeiture_handling(self) -> None:
        """12. Kiểm tra xử lý engine crash và illegal move (xử thua kỹ thuật Forfeiture, không nhầm với Checkmate)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            pro_bin = self._create_mock_uci_engine(tmpdir, "mock_pro.py", mode="normal", is_pro=True)
            crash_uni_bin = self._create_mock_uci_engine(tmpdir, "mock_uni_crash.py", mode="crash", is_pro=False)
            results_dir = os.path.join(tmpdir, "results_crash")

            runner = tournament.TournamentRunner(
                pro_bin=pro_bin,
                uni_bin=crash_uni_bin,
                results_dir=results_dir,
                total_duration_seconds=30.0,
                stage_max_seconds=30.0,
                move_time_ms=50,
                hash_mb=16,
                threads=1,
                max_games=2,
            )
            summary = runner.run()
            self.assertEqual(summary["statistics"]["total_games"], 2)
            self.assertEqual(summary["statistics"]["pro"]["wins"], 2)
            self.assertEqual(summary["statistics"]["universal"]["forfeits_suffered"], 2)

            with open(os.path.join(results_dir, "matches.csv"), "r", encoding="utf-8") as cf:
                rows = list(csv.DictReader(cf))
            self.assertEqual(len(rows), 2)
            for r in rows:
                self.assertIn("Forfeiture", r["Termination"])
                self.assertTrue(r["Error"], "Cột Error trong CSV phải ghi rõ nguyên nhân lỗi")

            # Kiểm tra xử lý nước đi bất hợp lệ (illegal move -> Forfeiture)
            illegal_uni_bin = self._create_mock_uci_engine(tmpdir, "mock_uni_illegal.py", mode="illegal", is_pro=False)
            results_illegal = os.path.join(tmpdir, "results_illegal")
            runner_ill = tournament.TournamentRunner(
                pro_bin=pro_bin,
                uni_bin=illegal_uni_bin,
                results_dir=results_illegal,
                total_duration_seconds=30.0,
                stage_max_seconds=30.0,
                move_time_ms=50,
                hash_mb=16,
                threads=1,
                max_games=1,
            )
            sum_ill = runner_ill.run()
            self.assertEqual(sum_ill["statistics"]["pro"]["wins"], 1)
            self.assertEqual(sum_ill["statistics"]["universal"]["forfeits_suffered"], 1)


    def test_09_two_stage_resume_and_no_duplicate_games(self) -> None:
        """6, 7 & 14. Kiểm tra lưu checkpoint nguyên tử, resume Chặng 2 và chống trùng trận."""
        with tempfile.TemporaryDirectory() as tmpdir:
            pro_bin = self._create_mock_uci_engine(tmpdir, "mock_pro.py", mode="normal", is_pro=True)
            uni_bin = self._create_mock_uci_engine(tmpdir, "mock_uni.py", mode="normal", is_pro=False)
            results_dir = os.path.join(tmpdir, "results_resume")

            # Chặng 1: Đấu 2 ván
            runner_s1 = tournament.TournamentRunner(
                pro_bin=pro_bin,
                uni_bin=uni_bin,
                results_dir=results_dir,
                total_duration_seconds=120.0,
                stage_max_seconds=60.0,
                move_time_ms=20,
                hash_mb=16,
                threads=1,
                stage_number=1,
                resume=False,
                max_games=2,
            )
            runner_s1.run()

            # Giả lập một dòng JSONL thứ 3 bị ghi dở dang (chưa cập nhật vào checkpoint.json)
            jsonl_path = os.path.join(results_dir, "matches.jsonl")
            with open(jsonl_path, "a", encoding="utf-8") as jf:
                jf.write('{"Game_ID": 999, "corrupted_uncommitted": true}\n')

            # Chặng 2: Resume và đấu tiếp đến tổng 4 ván
            runner_s2 = tournament.TournamentRunner(
                pro_bin=pro_bin,
                uni_bin=uni_bin,
                results_dir=results_dir,
                total_duration_seconds=120.0,
                stage_max_seconds=60.0,
                move_time_ms=20,
                hash_mb=16,
                threads=1,
                stage_number=2,
                resume=True,
                max_games=4,
            )
            summary_s2 = runner_s2.run()

            self.assertEqual(summary_s2["statistics"]["total_games"], 4)
            with open(jsonl_path, "r", encoding="utf-8") as jf:
                objs = [json.loads(line) for line in jf if line.strip()]
            game_ids = [o["Game_ID"] for o in objs]
            self.assertEqual(game_ids, [1, 2, 3, 4], "Game_ID phải liên tục từ 1 đến 4, không trùng lặp")


    def test_10_real_compiled_engines_integration(self) -> None:
        """Kiểm thử tích hợp thực tế (Integration Test) với 2 binary C++ đã biên dịch."""
        pro_bin = os.path.join(REPO_ROOT, "build", "bin", "stockfish-pro")
        uni_bin = os.path.join(REPO_ROOT, "build", "bin", "stockfish-universal")
        if not (os.path.isfile(pro_bin) and os.path.isfile(uni_bin)):
            self.skipTest("Chưa biên dịch binary thực tế trong build/bin/")
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_path = os.path.join(tmpdir, "build-manifest.json")
            manifest = tournament.generate_build_manifest(
                pro_bin=pro_bin,
                uni_bin=uni_bin,
                manifest_path=manifest_path,
                results_dir=tmpdir,
            )
            self.assertTrue(os.path.isfile(manifest_path))
            self.assertNotEqual(
                manifest["engines"]["engine_a_pro"]["binary_sha256"],
                manifest["engines"]["engine_b_universal"]["binary_sha256"],
            )
            runner = tournament.TournamentRunner(
                pro_bin=pro_bin,
                uni_bin=uni_bin,
                results_dir=tmpdir,
                total_duration_seconds=60.0,
                stage_max_seconds=60.0,
                move_time_ms=30,
                hash_mb=64,
                threads=1,
                max_games=2,
            )
            summary = runner.run()
            self.assertEqual(summary["statistics"]["total_games"], 2)
            for fname in ["matches.log", "matches.pgn", "matches.csv", "matches.jsonl", "summary.json", "summary.md", "build-manifest.json"]:
                self.assertTrue(os.path.isfile(os.path.join(tmpdir, fname)), f"Thiếu file output: {fname}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
